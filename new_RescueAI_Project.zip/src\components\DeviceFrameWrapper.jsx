import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, RotateCcw } from 'lucide-react';

/**
 * DeviceFrameWrapper:
 * Allows user on Windows / Desktop to seamlessly switch between
 * full Desktop View and a realistic Mobile Phone View (iPhone/Pixel style)
 * with one click.
 */
export default function DeviceFrameWrapper({ children }) {
  const [isMobileView, setIsMobileView] = useState(() => {
    // Check URL param ?view=mobile or localStorage
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('view') === 'mobile' || params.get('mobile') === '1') {
        return true;
      }
      return localStorage.getItem('rescueai_device_view') === 'mobile';
    }
    return false;
  });

  const [isRealMobile, setIsRealMobile] = useState(false);

  useEffect(() => {
    const checkWidth = () => {
      setIsRealMobile(window.innerWidth < 768);
    };
    checkWidth();
    window.addEventListener('resize', checkWidth);
    return () => window.removeEventListener('resize', checkWidth);
  }, []);

  const setViewMode = (mode) => {
    const isMob = mode === 'mobile';
    setIsMobileView(isMob);
    localStorage.setItem('rescueai_device_view', isMob ? 'mobile' : 'desktop');
  };

  // If already on an actual physical phone, render natively without device frame
  if (isRealMobile) {
    return (
      <>
        {children}
      </>
    );
  }

  return (
    <div className={`device-mode-root ${isMobileView ? 'mode-mobile-active' : 'mode-desktop-active'}`}>
      {/* Floating Device Mode Switcher (Desktop ↔ Mobile) */}
      <div
        className="fixed bottom-5 right-5 z-[99999] flex items-center gap-1 p-1 bg-slate-900/90 text-white rounded-full shadow-2xl backdrop-blur-md border border-slate-700/60 select-none transition-all duration-300 hover:scale-105"
        role="group"
        aria-label="View Mode Switcher"
      >
        <button
          type="button"
          onClick={() => setViewMode('desktop')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
            !isMobileView
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Switch to full Desktop View"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Desktop</span>
        </button>

        <button
          type="button"
          onClick={() => setViewMode('mobile')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
            isMobileView
              ? 'bg-rose-500 text-white shadow-md'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Switch to smartphone Mobile View"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Mobile View</span>
        </button>
      </div>

      {/* When Mobile View is selected, wrap in realistic smartphone mockup */}
      {isMobileView ? (
        <div className="min-h-screen w-full bg-slate-950/95 flex flex-col items-center justify-center p-4 sm:p-6 overflow-hidden">
          {/* Header indicator */}
          <div className="mb-3 flex items-center gap-3 text-xs text-slate-400 font-mono tracking-wide">
            <span className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/50">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Mobile Simulator: 393 × 852
            </span>
            <span className="text-slate-500 hidden sm:inline">Use mouse to scroll and test touch interactions</span>
          </div>

          {/* Smartphone Frame */}
          <div
            className="relative bg-black rounded-[50px] p-[10px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_0_1px_rgba(255,255,255,0.12),0_0_0_8px_#1e293b] transition-all duration-300"
            style={{
              width: '400px',
              maxWidth: '96vw',
              height: '860px',
              maxHeight: '88vh'
            }}
          >
            {/* Dynamic Island / Notch */}
            <div className="absolute top-[14px] left-1/2 -translate-x-1/2 w-[110px] h-[26px] bg-black rounded-full z-50 flex items-center justify-between px-3.5 pointer-events-none shadow-md">
              <div className="w-2.5 h-2.5 rounded-full bg-[#111] border border-slate-800 flex items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-blue-900/60" />
              </div>
              <div className="w-3 h-3 rounded-full bg-[#0a0a0a] border border-slate-800" />
            </div>

            {/* Inner Phone Screen */}
            <div className="w-full h-full rounded-[40px] overflow-y-auto overflow-x-hidden bg-white relative scrollbar-none">
              {children}

              {/* Bottom Home Indicator Bar */}
              <div className="sticky bottom-1.5 left-0 right-0 flex justify-center pointer-events-none z-50 py-1">
                <div className="w-32 h-1 bg-slate-800/40 rounded-full backdrop-blur-sm" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Standard Full Desktop View */
        children
      )}
    </div>
  );
}
