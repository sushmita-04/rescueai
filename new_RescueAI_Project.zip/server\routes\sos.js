import express from 'express';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { z } from 'zod';
import { query, queryOne, newId } from '../db.js';
import { requireStaff, requireAdmin } from '../auth.js';

const router = express.Router();

const uploadsDir = path.resolve(process.cwd(), 'server', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer storage for SOS photos
const photoStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    const id = crypto.randomBytes(10).toString('hex');
    cb(null, `photo_${Date.now()}_${id}${ext}`);
  }
});

const uploadPhotos = multer({
  storage: photoStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB per photo
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/') || file.originalname.match(/\.(jpg|jpeg|png|webp|gif|heic)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Images only'));
    }
  }
});

// SSE Subscribers
const teamSubscribers = new Set();
const senderSubscribers = new Map(); // reference_id -> Set(res)

export function broadcastTeamEvent(eventType, data) {
  const payload = `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of teamSubscribers) {
    try {
      res.write(payload);
    } catch {
      teamSubscribers.delete(res);
    }
  }
}

export function broadcastSenderEvent(referenceId, data) {
  const subs = senderSubscribers.get(referenceId);
  if (!subs) return;
  const payload = `event: track_update\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of subs) {
    try {
      res.write(payload);
    } catch {
      subs.delete(res);
    }
  }
}

// In-memory rate limiting for public POST /api/sos: 5 per 10 minutes per IP
const sosSubmissions = new Map(); // ip -> [timestamps]
const SOS_MAX_SUBMISSIONS = 5;
const SOS_WINDOW_MS = 10 * 60 * 1000;

function checkSosRateLimit(ip) {
  const now = Date.now();
  const history = (sosSubmissions.get(ip) || []).filter((t) => now - t < SOS_WINDOW_MS);
  if (history.length >= SOS_MAX_SUBMISSIONS) {
    return false;
  }
  history.push(now);
  sosSubmissions.set(ip, history);
  return true;
}

export function calculateSeverityFromText(text = '', situation = 'other', peopleCount = 0) {
  const lower = (text || '').toLowerCase().trim();
  const count = Number(peopleCount) || 0;

  // Emergency keywords: immediate life-threatening situations
  const emergencyKeywords = [
    'trapped', 'cannot breathe', "can't breathe", 'suffocating', 'choking', 'drowning',
    'bleeding heavily', 'heavy bleeding', 'severe bleeding', 'unconscious', 'heart attack',
    'cardiac', 'chest pain', 'fire', 'burning', 'flames', 'smoke inhalation',
    'building collapse', 'collapse', 'collapsed', 'crushed', 'under rubble', 'dying',
    'critical', 'urgent', 'water rising fast', 'water at neck', 'fast current', 'swept away',
    'children trapped', 'child trapped', 'baby trapped', 'infant', 'elderly trapped',
    'electric shock', 'electrocution', 'gas leak', 'explosion', 'emergency',
    'life threatening', 'need rescue now', 'send help immediately', 'severe'
  ];

  // Medium keywords: moderate distress, injuries, isolated or requiring medical attention
  const mediumKeywords = [
    'injured', 'injury', 'hurt', 'fracture', 'broken bone', 'broken leg', 'broken arm',
    'wound', 'cuts', 'fever', 'high fever', 'pain', 'severe pain', 'water entering',
    'water in house', 'stuck', 'stranded', 'cut off', 'need help', 'food finished',
    'no food', 'drinking water', 'clean water', 'medicine', 'diabetic', 'insulin',
    'power out', 'no power', 'hypothermia', 'freezing', 'cold', 'on roof', 'on the roof',
    'structural damage', 'moderate', 'isolated'
  ];

  const hasEmergency = emergencyKeywords.some((kw) => lower.includes(kw));
  const hasMedium = mediumKeywords.some((kw) => lower.includes(kw));

  if (hasEmergency || situation === 'trapped' || (situation === 'injured' && count >= 2) || count >= 5) {
    return 'emergency';
  }

  if (hasMedium || situation === 'injured' || situation === 'medical' || situation === 'fire' || count >= 2) {
    return 'medium';
  }

  return 'low';
}

function computePriority(situation, peopleCount, text = '') {
  return calculateSeverityFromText(text, situation, peopleCount);
}

export function generateReferenceId() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(8);
  let out = '';
  for (let i = 0; i < 8; i++) {
    out += alphabet[bytes[i] % alphabet.length];
  }
  return out;
}

function sanitizeText(str, maxLength = 500) {
  if (typeof str !== 'string') return '';
  return str.trim().slice(0, maxLength);
}

// Helper: Constant-time string equality
function safeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

// Helper: Format public tracking response
function formatTrackResponse(sos) {
  let parsedPhotos = [];
  try {
    if (sos.photo_urls) {
      const p = typeof sos.photo_urls === 'string' ? JSON.parse(sos.photo_urls) : sos.photo_urls;
      if (Array.isArray(p)) parsedPhotos = p;
      else if (typeof p === 'string' && p) parsedPhotos = [p];
    }
  } catch {
    if (typeof sos.photo_urls === 'string' && sos.photo_urls.trim()) {
      parsedPhotos = [sos.photo_urls.trim()];
    }
  }

  return {
    reference_id: sos.reference_id,
    status: sos.status,
    priority: sos.priority,
    timestamps: {
      created_at: sos.created_date,
      first_seen_at: sos.first_seen_at || null,
      acknowledged_at: sos.acknowledged_at || null,
      dispatched_at: sos.dispatched_at || null,
      resolved_at: sos.resolved_at || null
    },
    team: sos.handled_by || sos.acknowledged_by || null,
    eta_minutes: sos.eta_minutes ?? null,
    latest_message: sos.latest_message || null,
    outcome: sos.outcome || null,
    photos: parsedPhotos,
    has_audio: Boolean(sos.audio_url)
  };
}

// POST /api/sos/upload-photo (Public photo upload for SOS)
router.post('/sos/upload-photo', uploadPhotos.array('photos', 5), (req, res) => {
  try {
    const files = req.files || [];
    if (req.file) files.push(req.file);

    if (files.length === 0) {
      return res.status(400).json({ error: 'No photo files uploaded' });
    }

    const urls = files.map((file) => `/api/files/${file.filename}`);
    return res.json({ urls });
  } catch (err) {
    console.error('Error uploading SOS photo:', err);
    return res.status(500).json({ error: 'Photo upload failed' });
  }
});

// GET /api/files/:filename (Serve uploaded emergency audio & photos safely)
router.get('/files/:filename', (req, res) => {
  const safeFilename = path.basename(req.params.filename);
  const fullPath = path.join(uploadsDir, safeFilename);

  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({ error: 'File not found' });
  }

  const ext = path.extname(fullPath).toLowerCase();
  const mimeTypes = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.heic': 'image/heic',
    '.webm': 'audio/webm',
    '.ogg': 'audio/ogg',
    '.wav': 'audio/wav',
    '.mp3': 'audio/mpeg',
    '.m4a': 'audio/mp4',
    '.mp4': 'audio/mp4'
  };

  res.setHeader('Content-Type', mimeTypes[ext] || 'application/octet-stream');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  fs.createReadStream(fullPath).pipe(res);
});

// POST /api/sos (Public SOS creation)
router.post('/sos', async (req, res) => {
  const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
  if (!checkSosRateLimit(clientIp)) {
    return res.status(429).json({ error: 'Too many SOS submissions from your device. Please try again shortly or call emergency services.' });
  }

  const {
    name,
    phone,
    situation,
    location_text,
    lat,
    lng,
    people_count,
    note,
    audio_url,
    audio_duration,
    transcript,
    photos,
    photo_urls
  } = req.body || {};

  const cleanNote = sanitizeText(note, 500);
  const cleanTranscript = sanitizeText(transcript, 1000);
  const cleanSituation = ['trapped', 'injured', 'medical', 'fire', 'lost', 'other'].includes(situation)
    ? situation
    : 'other';
  const cleanPeople = Math.max(0, parseInt(people_count, 10) || 0);
  const cleanPhone = sanitizeText(phone, 30);
  const cleanName = sanitizeText(name, 100);
  const cleanLocation = sanitizeText(location_text, 250);

  const cleanLat = typeof lat === 'number' && Number.isFinite(lat) ? lat : null;
  const cleanLng = typeof lng === 'number' && Number.isFinite(lng) ? lng : null;

  // Process photos
  let cleanPhotoUrls = [];
  const rawPhotos = photos || photo_urls;
  if (Array.isArray(rawPhotos)) {
    cleanPhotoUrls = rawPhotos.filter((p) => typeof p === 'string' && p.trim().length > 0).slice(0, 8);
  } else if (typeof rawPhotos === 'string' && rawPhotos.trim()) {
    try {
      const parsed = JSON.parse(rawPhotos);
      if (Array.isArray(parsed)) cleanPhotoUrls = parsed.slice(0, 8);
      else cleanPhotoUrls = [rawPhotos.trim()];
    } catch {
      cleanPhotoUrls = [rawPhotos.trim()];
    }
  }
  const photoUrlsJson = cleanPhotoUrls.length > 0 ? JSON.stringify(cleanPhotoUrls) : null;

  const id = newId('sos');
  const reference_id = generateReferenceId();
  const tracking_token = crypto.randomBytes(16).toString('hex');
  const combinedText = [cleanTranscript, cleanNote, cleanSituation].filter(Boolean).join(' ');
  const priority = calculateSeverityFromText(combinedText, cleanSituation, cleanPeople);
  const now = new Date().toISOString();

  try {
    await query(
      `INSERT INTO sos_requests (
        id, reference_id, tracking_token, name, phone, situation, location_text,
        lat, lng, people_count, note, audio_url, audio_duration, priority, transcript, photo_urls, status,
        created_date, updated_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, ?)`,
      [
        id, reference_id, tracking_token, cleanName, cleanPhone, cleanSituation, cleanLocation,
        cleanLat, cleanLng, cleanPeople, cleanNote, audio_url || '', Number(audio_duration) || 0,
        priority, cleanTranscript, photoUrlsJson, now, now
      ]
    );

    // Audit event: created
    const eventId = newId('event');
    await query(
      `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
       VALUES (?, ?, 'created', NULL, 'new', NULL, 'Citizen', 'SOS submitted', ?)`,
      [eventId, id, now]
    );

    const createdRecord = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [id]);

    // Broadcast to rescue team SSE
    broadcastTeamEvent('sos_created', createdRecord);

    return res.status(201).json({
      id,
      reference_id,
      tracking_token,
      priority,
      status: 'new',
      photos: cleanPhotoUrls
    });
  } catch (err) {
    console.error('Error creating SOS:', err);
    return res.status(500).json({ error: 'Could not submit your SOS. Please try again.' });
  }
});

// GET /api/sos/track/:reference_id (Public tracking endpoint)
router.get('/sos/track/:reference_id', async (req, res) => {
  const reference_id = String(req.params.reference_id || '').trim().toUpperCase();
  const token = String(req.query.token || '').trim();

  if (!/^[A-Z0-9]{8}$/.test(reference_id)) {
    return res.status(400).json({ error: 'Invalid reference ID' });
  }

  try {
    const sos = await queryOne('SELECT * FROM sos_requests WHERE reference_id = ?', [reference_id]);
    if (!sos) {
      return res.status(404).json({ error: 'SOS request not found' });
    }

    // Verify token or phone last 4 digits (fallback verification)
    const phoneLast4 = String(req.query.phone_last4 || '').trim();
    let isAuthorized = false;

    if (token && safeCompare(token, sos.tracking_token)) {
      isAuthorized = true;
    } else if (phoneLast4 && phoneLast4.length === 4 && sos.phone && sos.phone.endsWith(phoneLast4)) {
      isAuthorized = true;
    }

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Invalid or missing tracking token' });
    }

    const trackData = formatTrackResponse(sos);

    // Check if client requested SSE stream
    if (req.headers.accept === 'text/event-stream') {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      res.write(`event: track_init\ndata: ${JSON.stringify(trackData)}\n\n`);

      if (!senderSubscribers.has(reference_id)) {
        senderSubscribers.set(reference_id, new Set());
      }
      const set = senderSubscribers.get(reference_id);
      set.add(res);

      req.on('close', () => {
        set.delete(res);
        if (set.size === 0) senderSubscribers.delete(reference_id);
      });
      return;
    }

    return res.json(trackData);
  } catch (err) {
    console.error('Track error:', err);
    return res.status(500).json({ error: 'Could not track SOS request' });
  }
});

// GET /api/team/stream (Real-time SSE for staff)
router.get('/team/stream', requireStaff, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  res.write(': connected\n\n');
  teamSubscribers.add(res);

  const keepAlive = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(keepAlive);
      teamSubscribers.delete(res);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(keepAlive);
    teamSubscribers.delete(res);
  });
});

// GET /api/team/sos (Staff list of all SOS)
router.get('/team/sos', requireStaff, async (req, res) => {
  try {
    const rows = await query('SELECT * FROM sos_requests ORDER BY created_date DESC LIMIT 150');
    return res.json({ items: rows });
  } catch (err) {
    console.error('List team sos error:', err);
    return res.status(500).json({ error: 'Could not fetch SOS queue' });
  }
});

// POST /api/team/sos/:id/seen (First seen by staff)
router.post('/team/sos/:id/seen', requireStaff, async (req, res) => {
  const sosId = req.params.id;
  try {
    const sos = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    if (!sos) return res.status(404).json({ error: 'Not found' });

    if (!sos.first_seen_at) {
      const now = new Date().toISOString();
      const userName = req.user.full_name || req.user.email;
      await query(
        'UPDATE sos_requests SET first_seen_at = ?, first_seen_by = ?, first_seen_by_id = ?, updated_date = ? WHERE id = ?',
        [now, userName, req.user.id, now, sosId]
      );

      const eventId = newId('event');
      await query(
        `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
         VALUES (?, ?, 'first_seen', ?, ?, ?, ?, 'Card viewed in dashboard', ?)`,
        [eventId, sosId, sos.status, sos.status, req.user.id, userName, now]
      );

      const updated = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
      broadcastTeamEvent('sos_updated', updated);
      broadcastSenderEvent(sos.reference_id, formatTrackResponse(updated));
      return res.json({ ok: true, first_seen_at: now });
    }

    return res.json({ ok: true, first_seen_at: sos.first_seen_at });
  } catch (err) {
    console.error('Seen error:', err);
    return res.status(500).json({ error: 'Could not update seen status' });
  }
});

// POST /api/team/sos/:id/status (Workflow state changes)
router.post('/team/sos/:id/status', requireStaff, async (req, res) => {
  const sosId = req.params.id;
  const { status, handled_by, eta_minutes, outcome, note, override } = req.body || {};

  try {
    const sos = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    if (!sos) return res.status(404).json({ error: 'Not found' });

    const validTransitions = {
      new: ['acknowledged'],
      acknowledged: ['dispatched'],
      dispatched: ['resolved'],
      resolved: ['new', 'acknowledged'] // staff can reopen
    };

    if (!validTransitions[sos.status]?.includes(status)) {
      return res.status(400).json({
        error: `Cannot transition SOS from status '${sos.status}' to '${status}'. Valid next step: ${validTransitions[sos.status]?.join(', ') || 'none'}`
      });
    }

    const now = new Date().toISOString();
    const actorName = req.user.full_name || req.user.email;
    const actorId = req.user.id;

    // Workflow: Acknowledge
    if (status === 'acknowledged') {
      if (sos.acknowledged_by && sos.acknowledged_by_id !== actorId && !override) {
        return res.status(409).json({
          conflict: true,
          already_taken: true,
          taken_by: sos.acknowledged_by,
          message: `This SOS is already acknowledged by ${sos.acknowledged_by}. Confirm takeover?`
        });
      }

      const teamName = (handled_by || actorName).trim();
      await query(
        `UPDATE sos_requests SET
          status = 'acknowledged',
          handled_by = ?,
          acknowledged_by = ?,
          acknowledged_by_id = ?,
          acknowledged_at = ?,
          updated_date = ?
         WHERE id = ?`,
        [teamName, teamName, actorId, now, now, sosId]
      );

      const eventId = newId('event');
      await query(
        `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
         VALUES (?, ?, 'acknowledged', ?, 'acknowledged', ?, ?, ?, ?)`,
        [eventId, sosId, sos.status, actorId, actorName, `Claimed by ${teamName}`, now]
      );
    }

    // Workflow: Dispatch
    else if (status === 'dispatched') {
      const teamName = (handled_by || sos.handled_by || actorName).trim();
      const eta = typeof eta_minutes === 'number' && eta_minutes >= 0 ? Math.round(eta_minutes) : null;

      await query(
        `UPDATE sos_requests SET
          status = 'dispatched',
          handled_by = ?,
          dispatched_at = ?,
          eta_minutes = ?,
          updated_date = ?
         WHERE id = ?`,
        [teamName, now, eta, now, sosId]
      );

      const eventId = newId('event');
      const etaDesc = eta ? ` (ETA: ${eta} min)` : '';
      await query(
        `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
         VALUES (?, ?, 'dispatched', 'acknowledged', 'dispatched', ?, ?, ?, ?)`,
        [eventId, sosId, actorId, actorName, `Dispatched ${teamName}${etaDesc}`, now]
      );
    }

    // Workflow: Resolve
    else if (status === 'resolved') {
      const cleanOutcome = ['rescued', 'false alarm', 'referred to hospital', 'other'].includes(outcome)
        ? outcome
        : 'rescued';
      const cleanNote = sanitizeText(note, 300);

      await query(
        `UPDATE sos_requests SET
          status = 'resolved',
          resolved_at = ?,
          outcome = ?,
          resolution_note = ?,
          updated_date = ?
         WHERE id = ?`,
        [now, cleanOutcome, cleanNote, now, sosId]
      );

      const eventId = newId('event');
      await query(
        `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
         VALUES (?, ?, 'resolved', 'dispatched', 'resolved', ?, ?, ?, ?)`,
        [eventId, sosId, actorId, actorName, `Resolved: ${cleanOutcome}${cleanNote ? ` - ${cleanNote}` : ''}`, now]
      );
    }

    // Workflow: Reopen
    else if (sos.status === 'resolved' && (status === 'new' || status === 'acknowledged')) {
      await query(
        `UPDATE sos_requests SET
          status = ?,
          resolved_at = NULL,
          outcome = NULL,
          resolution_note = NULL,
          updated_date = ?
         WHERE id = ?`,
        [status, now, sosId]
      );

      const eventId = newId('event');
      await query(
        `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
         VALUES (?, ?, 'reopened', 'resolved', ?, ?, ?, 'Case reopened by staff', ?)`,
        [eventId, sosId, status, actorId, actorName, now]
      );
    }

    const updated = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    broadcastTeamEvent('sos_updated', updated);
    broadcastSenderEvent(sos.reference_id, formatTrackResponse(updated));

    return res.json({ ok: true, item: updated });
  } catch (err) {
    console.error('Status transition error:', err);
    return res.status(500).json({ error: 'Could not update status' });
  }
});

// POST /api/team/sos/:id/message (Team sends message to sender)
router.post('/team/sos/:id/message', requireStaff, async (req, res) => {
  const sosId = req.params.id;
  const message = sanitizeText(req.body?.message, 200);

  if (!message) {
    return res.status(400).json({ error: 'Message text cannot be empty' });
  }

  try {
    const sos = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    if (!sos) return res.status(404).json({ error: 'Not found' });

    const now = new Date().toISOString();
    const actorName = req.user.full_name || req.user.email;

    await query('UPDATE sos_requests SET latest_message = ?, updated_date = ? WHERE id = ?', [message, now, sosId]);

    const eventId = newId('event');
    await query(
      `INSERT INTO sos_events (id, sos_id, type, status_from, status_to, actor_user_id, actor_name, note, created_at)
       VALUES (?, ?, 'message_sent', ?, ?, ?, ?, ?, ?)`,
      [eventId, sosId, sos.status, sos.status, req.user.id, actorName, `Sent: "${message}"`, now]
    );

    const updated = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    broadcastTeamEvent('sos_updated', updated);
    broadcastSenderEvent(sos.reference_id, formatTrackResponse(updated));

    return res.json({ ok: true, message });
  } catch (err) {
    console.error('Send message error:', err);
    return res.status(500).json({ error: 'Could not send message' });
  }
});

// GET /api/team/sos/:id/events (Audit trail for one SOS)
router.get('/team/sos/:id/events', requireStaff, async (req, res) => {
  const sosId = req.params.id;
  try {
    const events = await query('SELECT * FROM sos_events WHERE sos_id = ? ORDER BY created_at ASC', [sosId]);
    return res.json({ items: events });
  } catch (err) {
    console.error('Get events error:', err);
    return res.status(500).json({ error: 'Could not fetch history' });
  }
});

// GET /api/team/events (Admin Activity tab across all SOS)
router.get('/team/events', requireAdmin, async (req, res) => {
  try {
    const events = await query(
      `SELECT e.*, s.reference_id, s.situation, s.name as citizen_name
       FROM sos_events e
       LEFT JOIN sos_requests s ON e.sos_id = s.id
       ORDER BY e.created_at DESC LIMIT 100`
    );
    return res.json({ items: events });
  } catch (err) {
    console.error('All events error:', err);
    return res.status(500).json({ error: 'Could not load activity log' });
  }
});

export default router;
