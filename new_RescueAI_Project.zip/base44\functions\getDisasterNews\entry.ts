import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cached, cacheKey, fetchWithTimeout, sleep } from '../../shared/live.ts';

const KEYWORDS: Record<string, string> = {
  flood: 'flood',
  earthquake: 'earthquake',
  fire: 'fire',
  cyclone: 'cyclone'
};

function decodeEntities(text: string) {
  return text
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

function stripTags(text: string) {
  return decodeEntities(String(text || '').replace(/<[^>]*>/g, '')).trim();
}

function mapGdelt(rows: any[]) {
  return rows
    .map((row: any) => ({
      title: String(row?.title || '').trim(),
      url: String(row?.url || ''),
      domain: String(row?.domain || ''),
      seendate: String(row?.seendate || ''),
      language: String(row?.language || '')
    }))
    .filter((row: any) => row.title && row.url)
    .slice(0, 15);
}

async function fromGdelt(query: string) {
  const url =
    `https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(query)}` +
    '&mode=ArtList&format=json&maxrecords=15&timespan=3d&sort=DateDesc';
  let response = await fetchWithTimeout(url, {}, 4000);
  if (response.status === 429) {
    // GDELT rate-limits bursts: pause briefly and retry once before falling back
    await sleep(1500);
    response = await fetchWithTimeout(url, {}, 6000);
  }
  if (!response.ok) throw new Error(`GDELT responded ${response.status}`);
  const text = await response.text();
  const payload = JSON.parse(text);
  return Array.isArray(payload?.articles) ? payload.articles : [];
}

function domainOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

async function fromBingNews(query: string) {
  const url = `https://www.bing.com/news/search?q=${encodeURIComponent(query)}&format=RSS`;
  const response = await fetchWithTimeout(url, {}, 12000);
  if (!response.ok) throw new Error(`News provider responded ${response.status}`);
  const xml = await response.text();

  const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => match[1]);
  return items
    .map((block) => {
      const title = stripTags(block.match(/<title>([\s\S]*?)<\/title>/)?.[1] || '');
      const rawLink = decodeEntities(block.match(/<link>([\s\S]*?)<\/link>/)?.[1] || '').trim();
      const forwarded = rawLink.match(/[?&]url=([^&]+)/);
      const link = forwarded ? decodeURIComponent(forwarded[1]) : rawLink;
      const published = stripTags(block.match(/<pubDate>([\s\S]*?)<\/pubDate>/)?.[1] || '');
      return {
        title: title.replace(/\s+-\s+[^-]+$/, '').trim(),
        url: link,
        domain: domainOf(link),
        seendate: published,
        language: 'en'
      };
    })
    .filter((row) => row.title && row.url.startsWith('http'))
    .slice(0, 15);
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const disasterType = String(body?.disaster_type || 'flood').toLowerCase();
    const keyword = KEYWORDS[disasterType] || 'disaster';
    const placeName = String(body?.place_name || '').trim().slice(0, 120);

    if (!placeName) {
      return Response.json({ articles: [], error: 'A place name is required.' }, { status: 400 });
    }

    const data = await cached(base44, cacheKey(['news', disasterType, placeName]), async () => {
      const query = `${keyword} ${placeName}`;
      try {
        const articles = mapGdelt(await fromGdelt(query));
        if (articles.length > 0) return { articles, query, source: 'GDELT' };
      } catch {
        // fall through to the secondary provider
      }

      try {
        const articles = await fromBingNews(query);
        return { articles, query, source: 'Bing News' };
      } catch (error: any) {
        throw new Error(error?.message || 'No news provider responded.');
      }
    });

    return Response.json(data);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'News service did not respond.' }, { status: 502 });
  }
}
