import TopNav from '@/components/TopNav';
import Footer from '@/components/Footer';
import SosFab from '@/components/SosFab';
import { useAuth } from '@/lib/AuthContext';

export default function AppShell({ children, showSosFab = true }) {
  const { user } = useAuth();
  const isStaff = user?.role === 'admin' || user?.role === 'rescue_team' || user?.staff_type === 'rescue_team';

  return (
    <div className="flex min-h-screen flex-col bg-canvas text-ink">
      <TopNav />
      <main className="flex-1">{children}</main>
      <Footer />
      {showSosFab && !isStaff ? <SosFab /> : null}
    </div>
  );
}
