import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Activity, ChevronDown, KeyRound, LayoutDashboard, Loader2, Lock, LogOut, Mic, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const linkClass = (active) =>
  cn(
    'rounded-full px-3 py-1.5 text-xs font-medium transition-colors sm:text-sm',
    active ? 'bg-white/10 text-white' : 'text-white/65 hover:text-white'
  );

export default function TopNav() {
  const { pathname } = useLocation();
  const { user, isAuthenticated, isLoadingAuth, logout } = useAuth();
  const { toast } = useToast();

  const [changePwdOpen, setChangePwdOpen] = useState(false);
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdError, setPwdError] = useState('');

  const isAdmin = user?.role === 'admin';
  const isStaff = user?.role === 'admin' || user?.role === 'rescue_team' || user?.staff_type === 'rescue_team';
  const isCommon = Boolean(isAuthenticated && !isStaff);
  const displayName = user?.full_name?.trim() || (user?.email ? user.email.split('@')[0] : '');

  const handleLogout = () => {
    logout(false);
    window.location.replace('/login');
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPwdError('');
    if (newPwd.length < 8) {
      setPwdError('New password must be at least 8 characters long');
      return;
    }

    setPwdLoading(true);
    try {
      await base44.auth.changePassword(currentPwd, newPwd);
      toast({ title: 'Password updated successfully' });
      setChangePwdOpen(false);
      setCurrentPwd('');
      setNewPwd('');
    } catch (err) {
      setPwdError(err.message || 'Could not change password');
    } finally {
      setPwdLoading(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-navy/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2.5" aria-label="RescueAI home">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-coral text-white shadow-sm">
            <Activity className="h-5 w-5" aria-hidden="true" />
          </span>
          <span className="font-heading text-lg text-white sm:text-xl">RescueAI</span>
        </Link>

        <nav className="flex items-center gap-1.5" aria-label="Main">
          {isLoadingAuth ? null : !isAuthenticated ? (
            <>
              <Link
                to="/landing"
                className={cn(linkClass(pathname === '/landing'), 'inline-flex items-center gap-1 text-xs')}
              >
                Overview
              </Link>
              <Link
                to="/sos"
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full bg-coral px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-[#D9614A] sm:text-sm',
                  pathname === '/sos' && 'ring-2 ring-white/40'
                )}
              >
                <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                SOS
              </Link>
              <Link
                to="/login"
                className={cn(linkClass(pathname === '/login'), 'inline-flex items-center gap-1')}
              >
                SOS Login
              </Link>
              <Link
                to="/team-login"
                className={cn(linkClass(pathname === '/team-login'), 'inline-flex items-center gap-1.5')}
              >
                <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                Team Login
              </Link>
            </>
          ) : isCommon ? (
            <>
              <Link
                to="/landing"
                className={cn(linkClass(pathname === '/landing' || pathname === '/rescue-landing'), 'inline-flex items-center gap-1 text-xs')}
              >
                Overview
              </Link>
              <Link
                to="/sos"
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full bg-coral px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-[#D9614A] sm:text-sm',
                  pathname === '/sos' && 'ring-2 ring-white/40'
                )}
              >
                <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                SOS
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger
                  className={cn(
                    'inline-flex max-w-[150px] items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-white/15 sm:text-sm',
                    pathname === '/sos' && 'bg-white/20'
                  )}
                >
                  <span className="truncate">{displayName || 'Citizen'}</span>
                  <ChevronDown className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="rounded-xl">
                  <DropdownMenuItem asChild>
                    <Link to="/sos" className="flex items-center gap-2">
                      <Mic className="h-4 w-4" aria-hidden="true" />
                      Emergency SOS
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setChangePwdOpen(true)} className="flex items-center gap-2">
                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                    Change password
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-sev-critical">
                    <LogOut className="h-4 w-4" aria-hidden="true" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Link
                to="/landing"
                className={cn(linkClass(pathname === '/landing' || pathname === '/rescue-landing'), 'inline-flex items-center gap-1 text-xs')}
              >
                Overview
              </Link>
              <Link to="/" className={linkClass(pathname === '/')}>
                Assess
              </Link>
              <Link to="/team" className={linkClass(pathname === '/team')}>
                Rescue Team
              </Link>

              <DropdownMenu>
                <DropdownMenuTrigger
                  className={cn(
                    'inline-flex max-w-[150px] items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-white/15 sm:text-sm',
                    (pathname === '/team' || pathname === '/admin' || pathname === '/') && 'bg-white/20'
                  )}
                >
                  <span className="truncate">{displayName || 'Responder'}</span>
                  <ChevronDown className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="rounded-xl">
                  <DropdownMenuItem asChild>
                    <Link to="/" className="flex items-center gap-2">
                      <Activity className="h-4 w-4" aria-hidden="true" />
                      Assess
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/team" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" aria-hidden="true" />
                      Rescue Team Dashboard
                    </Link>
                  </DropdownMenuItem>
                  {isAdmin ? (
                    <DropdownMenuItem asChild>
                      <Link to="/admin" className="flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                        Admin
                      </Link>
                    </DropdownMenuItem>
                  ) : null}
                  <DropdownMenuItem onClick={() => setChangePwdOpen(true)} className="flex items-center gap-2">
                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                    Change password
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-sev-critical">
                    <LogOut className="h-4 w-4" aria-hidden="true" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
        </nav>
      </div>

      {/* Change Password Dialog */}
      <Dialog open={changePwdOpen} onOpenChange={setChangePwdOpen}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Change password</DialogTitle>
            <DialogDescription>
              Enter your current password and choose a new one (min 8 characters).
            </DialogDescription>
          </DialogHeader>

          {pwdError && (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-xs" role="alert">
              {pwdError}
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-3 mt-2">
            <div>
              <Label htmlFor="cur-pwd" className="text-xs">Current password</Label>
              <Input
                id="cur-pwd"
                type="password"
                required
                value={currentPwd}
                onChange={(e) => setCurrentPwd(e.target.value)}
                className="mt-1 h-11 rounded-xl"
              />
            </div>
            <div>
              <Label htmlFor="new-pwd" className="text-xs">New password (min 8 chars)</Label>
              <Input
                id="new-pwd"
                type="password"
                required
                value={newPwd}
                onChange={(e) => setNewPwd(e.target.value)}
                className="mt-1 h-11 rounded-xl"
              />
            </div>

            <DialogFooter className="mt-4 gap-2">
              <Button type="button" variant="outline" onClick={() => setChangePwdOpen(false)} className="rounded-xl">
                Cancel
              </Button>
              <Button type="submit" disabled={pwdLoading} className="rounded-xl bg-coral text-white hover:bg-[#D9614A]">
                {pwdLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update password'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </header>
  );
}
