import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { SEVERITY_META, SEVERITY_ORDER } from '@/lib/severity';

export default function ProbabilityBars({ probabilities = {} }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 60);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-3">
      {SEVERITY_ORDER.map((key) => {
        const meta = SEVERITY_META[key];
        const value = Number(probabilities[key]) || 0;
        return (
          <div key={key}>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-ink">{meta.label}</span>
              <span className="font-mono text-graphite">{value}%</span>
            </div>
            <div
              className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-ink/5"
              role="meter"
              aria-valuenow={value}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`${meta.label} probability`}
            >
              <div
                className={cn('h-full rounded-full transition-[width] duration-1000 ease-out', meta.bar)}
                style={{ width: ready ? `${value}%` : '0%' }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
