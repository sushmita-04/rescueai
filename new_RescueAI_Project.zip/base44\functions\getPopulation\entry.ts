import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cached, cacheKey, fetchJson, haversineKm, reversePlace, roundCoord } from '../../shared/live.ts';

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const lat = Number(body?.lat);
    const lng = Number(body?.lng);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return Response.json({ error: 'Valid coordinates are required.' }, { status: 400 });
    }

    const place = await reversePlace(base44, lat, lng).catch(() => null);
    if (place?.population) {
      return Response.json({
        population: place.population,
        place_name: place.name || place.display_name,
        source: 'OpenStreetMap',
        updated_at: place.updated_at || new Date().toISOString()
      });
    }

    const data = await cached(base44, cacheKey(['population', roundCoord(lat), roundCoord(lng)]), async () => {
      const searchName = String(body?.place_name || place?.name || place?.city || '').trim();
      if (!searchName) return { population: null, place_name: '', source: 'OpenStreetMap' };

      const url =
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchName)}` +
        '&format=jsonv2&limit=7&extratags=1&addressdetails=1';

      const rows = await fetchJson(url);
      const candidates = (Array.isArray(rows) ? rows : [])
        .map((row: any) => {
          const population = Number(String(row?.extratags?.population || '').replace(/[^0-9]/g, ''));
          const pLat = Number(row?.lat);
          const pLng = Number(row?.lon);
          if (!Number.isFinite(population) || population <= 0) return null;
          if (!Number.isFinite(pLat) || !Number.isFinite(pLng)) return null;
          return {
            population,
            place_name: String(row?.name || String(row?.display_name || '').split(',')[0] || ''),
            place_type: String(row?.addresstype || row?.type || ''),
            distance_km: haversineKm(lat, lng, pLat, pLng)
          };
        })
        .filter(Boolean)
        .sort((a: any, b: any) => a.distance_km - b.distance_km);

      const best =
        candidates.find((row: any) => ['city', 'town', 'administrative', 'state_district'].includes(row.place_type)) ||
        candidates[0];

      if (!best) return { population: null, place_name: searchName, source: 'OpenStreetMap' };

      return {
        population: best.population,
        place_name: best.place_name || searchName,
        place_type: best.place_type,
        source: 'OpenStreetMap'
      };
    });

    return Response.json(data);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Population lookup failed.' }, { status: 502 });
  }
}
