import { useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import AppShell from '@/components/AppShell';
import SosSuccess from '@/components/sos/SosSuccess';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { KeyRound, ShieldAlert } from 'lucide-react';

export default function Track() {
  const { reference_id } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const ref = (reference_id || '').toUpperCase();
  const tokenFromUrl = searchParams.get('token') || '';
  const storedToken = localStorage.getItem(`sos_token_${ref}`) || '';

  const [inputToken, setInputToken] = useState(tokenFromUrl || storedToken || '');
  const [phoneLast4, setPhoneLast4] = useState('');
  const [activeToken, setActiveToken] = useState(tokenFromUrl || storedToken || '');
  const [submittedAuth, setSubmittedAuth] = useState(Boolean(tokenFromUrl || storedToken));

  const handleVerify = (e) => {
    e.preventDefault();
    if (inputToken.trim()) {
      setActiveToken(inputToken.trim());
      localStorage.setItem(`sos_token_${ref}`, inputToken.trim());
      setSearchParams({ token: inputToken.trim() });
      setSubmittedAuth(true);
    } else if (phoneLast4.trim().length === 4) {
      setSearchParams({ phone_last4: phoneLast4.trim() });
      setSubmittedAuth(true);
    }
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
        {!submittedAuth ? (
          <div className="mx-auto max-w-md rounded-[16px] bg-white p-6 shadow-soft ring-1 ring-black/5 sm:p-8">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-coral/10 text-coral">
              <KeyRound className="h-6 w-6" />
            </span>
            <h1 className="mt-4 text-center font-heading text-2xl text-ink">Track SOS {ref}</h1>
            <p className="mt-2 text-center text-xs text-graphite">
              To protect sender privacy, enter the tracking token from your link or the last 4 digits of the phone number on the SOS.
            </p>

            <form onSubmit={handleVerify} className="mt-6 space-y-4">
              <div>
                <Label htmlFor="track-token" className="text-xs">Tracking token</Label>
                <Input
                  id="track-token"
                  placeholder="Secret token from your link"
                  value={inputToken}
                  onChange={(e) => setInputToken(e.target.value)}
                  className="mt-1 h-11 rounded-xl font-mono text-sm"
                />
              </div>

              <div className="relative flex items-center justify-center text-xs text-graphite uppercase">
                <span className="w-full border-t border-ink/10" />
                <span className="bg-white px-2">or</span>
                <span className="w-full border-t border-ink/10" />
              </div>

              <div>
                <Label htmlFor="track-phone" className="text-xs">Phone last 4 digits</Label>
                <Input
                  id="track-phone"
                  placeholder="e.g. 1234"
                  maxLength={4}
                  value={phoneLast4}
                  onChange={(e) => setPhoneLast4(e.target.value.replace(/\D/g, ''))}
                  className="mt-1 h-11 rounded-xl text-sm"
                />
              </div>

              <Button
                type="submit"
                className="h-11 w-full rounded-xl bg-coral font-semibold text-white hover:bg-[#D9614A]"
              >
                Open tracker
              </Button>
            </form>
          </div>
        ) : (
          <SosSuccess
            referenceId={ref}
            trackingToken={activeToken}
            onAnother={() => navigate('/sos')}
          />
        )}
      </div>
    </AppShell>
  );
}
