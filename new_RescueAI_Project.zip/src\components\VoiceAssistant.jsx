import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Send,
  Radio,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  RotateCcw,
  Globe,
  Loader2,
  Minimize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import '@/styles/voiceAssistant.css';

const SpeechRecognition =
  typeof window !== 'undefined'
    ? window.SpeechRecognition || window.webkitSpeechRecognition
    : null;

export default function VoiceAssistant() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [language, setLanguage] = useState('en'); // 'en' | 'te'
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [pendingSos, setPendingSos] = useState(null);

  const [messages, setMessages] = useState([
    {
      id: 'init-1',
      sender: 'assistant',
      text:
        'Hello! I am your RescueAI Voice Assistant. You can speak to me in English or Telugu. How can I help you with an emergency or safety advice?',
      time: 'Just now'
    }
  ]);

  const recognitionRef = useRef(null);
  const chatScrollRef = useRef(null);
  const isSpeakingRef = useRef(false);
  const isMutedRef = useRef(false);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, interimText]);

  // Request browser location once if granted for seamless emergency routing
  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          try {
            const rev = await base44.functions.invoke('reverseGeocode', { lat, lng });
            const name = rev?.data?.display || rev?.data?.place || 'Current Location';
            setUserLocation({ lat, lng, name });
          } catch {
            setUserLocation({ lat, lng, name: 'Current Location' });
          }
        },
        () => {},
        { timeout: 8000 }
      );
    }
  }, []);

  // Stop synthesis when component unmounts
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  // Voice playback using SpeechSynthesis API
  const speakResponse = useCallback(
    (rawText, lang) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) return;

      window.speechSynthesis.cancel();
      if (isMutedRef.current) return;

      // Clean markdown tags for spoken audio
      const cleanText = rawText
        .replace(/[*#_`~]/g, '')
        .replace(/https?:\/\/\S+/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/\s+/g, ' ')
        .trim();

      if (!cleanText) return;

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      const langCode = lang === 'te' ? 'te-IN' : 'en-IN';
      utterance.lang = langCode;

      const voices = window.speechSynthesis.getVoices() || [];
      const matchVoice = voices.find(
        (v) => v.lang && v.lang.toLowerCase().startsWith(lang === 'te' ? 'te' : 'en')
      );
      if (matchVoice) {
        utterance.voice = matchVoice;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    },
    []
  );

  // Stop speech playback
  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  // Process message through backend Voice Assistant
  const processMessage = useCallback(
    async (textToSend) => {
      const text = textToSend?.trim();
      if (!text) return;

      stopSpeaking();
      setErrorMsg('');
      setInterimText('');
      setInputText('');

      const userMsgId = `u-${Date.now()}`;
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      setMessages((prev) => [
        ...prev,
        { id: userMsgId, sender: 'user', text, time: nowStr }
      ]);
      setLoading(true);

      try {
        const historyForApi = messages.slice(-6).map((m) => ({
          role: m.sender === 'user' ? 'user' : 'assistant',
          text: m.text
        }));

        const res = await base44.functions.invoke('voiceAssistant', {
          message: text,
          language,
          history: historyForApi,
          context: {
            userLocation,
            pendingSos
          }
        });

        const data = res?.data || {};
        const reply = data.reply || (language === 'te' ? 'సమాచారం అందింది.' : 'Information received.');

        setPendingSos(data.pendingSos || null);

        const aiMsgId = `a-${Date.now()}`;
        setMessages((prev) => [
          ...prev,
          {
            id: aiMsgId,
            sender: 'assistant',
            text: reply,
            action: data.action,
            sos_data: data.sos_data,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);

        speakResponse(reply, language);
      } catch (err) {
        console.error('Voice Assistant error:', err);
        const errMsg =
          language === 'te'
            ? 'క్షమించండి, సర్వర్‌ను సంప్రదించడంలో సమస్య ఏర్పడింది. దయచేసి మళ్లీ ప్రయత్నించండి.'
            : 'Sorry, I could not process your request right now. Please try again or use direct SOS.';
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            sender: 'assistant',
            text: errMsg,
            isError: true,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        speakResponse(errMsg, language);
      } finally {
        setLoading(false);
      }
    },
    [language, messages, userLocation, pendingSos, speakResponse, stopSpeaking]
  );

  // Initialize Speech Recognition
  const startListening = useCallback(() => {
    if (!SpeechRecognition) {
      setErrorMsg(
        'Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari, or type your message.'
      );
      return;
    }

    stopSpeaking();
    setErrorMsg('');
    setInterimText('');

    try {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = language === 'te' ? 'te-IN' : 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (interim) setInterimText(interim);
        if (final) {
          setIsListening(false);
          processMessage(final);
        }
      };

      recognition.onerror = (event) => {
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setErrorMsg('Microphone access blocked. Please allow microphone permissions in your browser.');
        } else if (event.error === 'no-speech') {
          // User stayed silent, no error display needed
        } else {
          setErrorMsg(`Recognition notice: ${event.error}`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.warn('Speech recognition start failed:', e);
      setIsListening(false);
    }
  }, [language, processMessage, stopSpeaking]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  }, []);

  // Toggle mic button action
  const handleMicToggle = () => {
    if (isSpeaking) {
      stopSpeaking();
      startListening();
      return;
    }
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Switch language
  const handleLanguageToggle = () => {
    const nextLang = language === 'en' ? 'te' : 'en';
    setLanguage(nextLang);
    stopSpeaking();
    stopListening();
    const introMsg =
      nextLang === 'te'
        ? 'భాష తెలుగుకు మార్చబడింది. మీరు ఇప్పుడు తెలుగులో మాట్లాడవచ్చు. అత్యవసర సహాయం కావాలంటే నాకు చెప్పండి.'
        : 'Language switched to English. You can speak now. How can I assist you with rescue or safety?';
    setMessages((prev) => [
      ...prev,
      {
        id: `lang-${Date.now()}`,
        sender: 'assistant',
        text: introMsg,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    speakResponse(introMsg, nextLang);
  };

  // One-click Share Location
  const handleShareLocation = () => {
    if (!navigator.geolocation) {
      setErrorMsg('Geolocation not supported by your browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(4));
        const lng = Number(pos.coords.longitude.toFixed(4));
        try {
          const rev = await base44.functions.invoke('reverseGeocode', { lat, lng });
          const name = rev?.data?.display || rev?.data?.place || `${lat}, ${lng}`;
          setUserLocation({ lat, lng, name });
          processMessage(`My location is ${name}`);
        } catch {
          setUserLocation({ lat, lng, name: `${lat}, ${lng}` });
          processMessage(`My location is ${lat}, ${lng}`);
        }
      },
      () => {
        setErrorMsg('Could not retrieve GPS location. Please type or speak your street / area.');
      }
    );
  };

  // SOS Quick Actions
  const handleConfirmSos = () => {
    processMessage(language === 'te' ? 'అవును, వెంటనే రెస్క్యూ టీమ్‌కి పంపండి' : 'Yes, please dispatch emergency SOS immediately');
  };

  const handleCancelSos = () => {
    processMessage(language === 'te' ? 'వద్దు, రద్దు చేయండి' : 'No, cancel SOS');
  };

  return (
    <>
      {/* Floating Launch Button (Fixed Bottom-Right) */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-50">
          <button
            type="button"
            onClick={() => {
              setIsOpen(true);
              startListening();
            }}
            aria-label="Open RescueAI Voice Assistant"
            className="group relative flex h-14 items-center gap-3 rounded-full bg-gradient-to-r from-coral to-[#E5484D] px-4 py-2.5 text-white shadow-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-coral/40"
          >
            <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
              <Mic className="h-5 w-5 text-white transition-transform group-hover:scale-110" />
              <span className="absolute inset-0 animate-ping rounded-full bg-white/30 duration-1000" />
            </span>
            <div className="pr-1 text-left">
              <p className="text-xs font-bold uppercase tracking-wider">RescueAI Voice</p>
              <p className="text-[10px] text-white/80">Speak in English / తెలుగు</p>
            </div>
          </button>
        </div>
      )}

      {/* Voice Assistant Panel */}
      {isOpen && (
        <div
          role="dialog"
          aria-label="RescueAI Voice Assistant"
          className="voice-panel-enter fixed bottom-4 right-4 z-50 flex h-[600px] max-h-[92vh] w-[400px] max-w-[calc(100vw-32px)] flex-col overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-2xl transition-all sm:bottom-6 sm:right-6 sm:h-[620px]"
        >
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-slate-100 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 px-4 py-3.5 text-white">
            <div className="flex items-center gap-2.5">
              <div
                className={`relative grid h-8 w-8 place-items-center rounded-full ${
                  isListening
                    ? 'bg-sev-critical text-white'
                    : isSpeaking
                    ? 'bg-sky-500 text-white'
                    : 'bg-white/15 text-white'
                }`}
              >
                <Radio className={`h-4 w-4 ${isListening || isSpeaking ? 'animate-pulse' : ''}`} />
              </div>
              <div>
                <h3 className="text-sm font-semibold leading-tight">RescueAI Voice</h3>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                  <span
                    className={`h-2 w-2 rounded-full ${
                      isListening
                        ? 'bg-sev-critical animate-ping'
                        : isSpeaking
                        ? 'bg-sky-400 animate-pulse'
                        : 'bg-emerald-400'
                    }`}
                  />
                  <span>
                    {isListening
                      ? 'Listening to your voice...'
                      : isSpeaking
                      ? 'Speaking response...'
                      : loading
                      ? 'Processing...'
                      : 'Active & Ready'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {/* Language Switcher */}
              <button
                type="button"
                onClick={handleLanguageToggle}
                className="inline-flex h-8 items-center gap-1 rounded-lg bg-white/10 px-2 text-xs font-semibold text-white transition-colors hover:bg-white/20"
                title="Switch Language (English / తెలుగు)"
              >
                <Globe className="h-3 w-3" />
                <span>{language === 'en' ? 'EN' : 'తెలుగు'}</span>
              </button>

              {/* Mute / Unmute */}
              <button
                type="button"
                onClick={() => {
                  if (isSpeaking) stopSpeaking();
                  setIsMuted(!isMuted);
                }}
                className="grid h-8 w-8 place-items-center rounded-lg bg-white/10 text-white transition-colors hover:bg-white/20"
                title={isMuted ? 'Unmute voice' : 'Mute voice'}
              >
                {isMuted ? <VolumeX className="h-4 w-4 text-sev-critical" /> : <Volume2 className="h-4 w-4" />}
              </button>

              {/* Minimize / Close */}
              <button
                type="button"
                onClick={() => {
                  stopSpeaking();
                  stopListening();
                  setIsOpen(false);
                }}
                className="grid h-8 w-8 place-items-center rounded-lg bg-white/10 text-white transition-colors hover:bg-white/20"
                title="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Quick Context & Location Pill */}
          <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/80 px-4 py-1.5 text-[11px] text-slate-600">
            <div className="flex items-center gap-1.5 truncate">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-coral" />
              <span className="truncate">
                {userLocation ? userLocation.name : 'Location not set'}
              </span>
            </div>
            {!userLocation && (
              <button
                type="button"
                onClick={handleShareLocation}
                className="shrink-0 font-semibold text-coral hover:underline"
              >
                Share GPS
              </button>
            )}
          </div>

          {/* Chat Messages Flow */}
          <div
            ref={chatScrollRef}
            className="flex-1 space-y-3.5 overflow-y-auto p-4 bg-gradient-to-b from-slate-50/50 to-white"
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm ${
                    msg.sender === 'user'
                      ? 'bg-slate-900 text-white rounded-br-xs'
                      : msg.isError
                      ? 'bg-rose-50 text-sev-critical border border-rose-200 rounded-bl-xs'
                      : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Dispatched SOS Card */}
                  {msg.sos_data && (
                    <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50/90 p-3 text-emerald-950">
                      <div className="flex items-center gap-2 font-semibold">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                        <span>SOS Dispatched: {msg.sos_data.reference_id}</span>
                      </div>
                      <p className="mt-1 text-xs text-emerald-800">
                        High-priority rescue team alert triggered. Emergency status: Pending.
                      </p>
                      <button
                        type="button"
                        onClick={() => navigate(`/track/${msg.sos_data.reference_id}`)}
                        className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow-xs transition hover:bg-emerald-700"
                      >
                        <span>Track Live Status</span>
                        <ExternalLink className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
                <span className="mt-1 px-1 text-[10px] text-slate-400">{msg.time}</span>
              </div>
            ))}

            {/* Interim Transcript while user is actively speaking */}
            {interimText && (
              <div className="flex flex-col items-end">
                <div className="max-w-[85%] rounded-2xl rounded-br-xs bg-slate-900/70 px-4 py-2.5 text-sm text-white/90 italic shadow-sm">
                  {interimText} ...
                </div>
                <span className="mt-1 px-1 text-[10px] text-coral font-medium animate-pulse">
                  Listening...
                </span>
              </div>
            )}

            {/* Loading Indicator */}
            {loading && (
              <div className="flex items-center gap-2 rounded-xl bg-slate-100 px-3 py-2 text-xs text-slate-600 w-fit">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-coral" />
                <span>RescueAI is analyzing...</span>
              </div>
            )}

            {/* Error Message if any */}
            {errorMsg && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-2.5 text-xs text-sev-critical">
                <div className="flex items-center gap-1.5 font-semibold">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <span>Notice</span>
                </div>
                <p className="mt-0.5">{errorMsg}</p>
              </div>
            )}
          </div>

          {/* Interactive Action Prompt Bar (e.g. SOS Confirmation Buttons) */}
          {pendingSos && pendingSos.readyToDispatch && (
            <div className="border-t border-amber-200 bg-amber-50/90 p-3">
              <p className="text-xs font-semibold text-amber-900">
                Confirm Emergency SOS Dispatch:
              </p>
              <div className="mt-2 flex gap-2">
                <Button
                  type="button"
                  size="sm"
                  onClick={handleConfirmSos}
                  className="flex-1 bg-sev-critical hover:bg-[#D93D42] text-white font-semibold text-xs h-9 rounded-lg"
                >
                  <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />
                  {language === 'te' ? 'అవును, SOS పంపండి' : 'Yes, Dispatch SOS'}
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={handleCancelSos}
                  className="bg-white text-slate-700 text-xs h-9 rounded-lg border-slate-300"
                >
                  {language === 'te' ? 'వద్దు, రద్దు చేయి' : 'Cancel'}
                </Button>
              </div>
            </div>
          )}

          {/* Soundwave Visualizer Bars */}
          <div className="flex h-10 items-center justify-center gap-1 border-t border-slate-100 bg-slate-50 px-4">
            <span
              className={`voice-bar voice-bar-1 ${
                isListening ? 'text-sev-critical' : isSpeaking ? 'text-sky-500' : 'text-slate-300'
              }`}
            />
            <span
              className={`voice-bar voice-bar-2 ${
                isListening ? 'text-sev-critical' : isSpeaking ? 'text-sky-500' : 'text-slate-300'
              }`}
            />
            <span
              className={`voice-bar voice-bar-3 ${
                isListening ? 'text-sev-critical' : isSpeaking ? 'text-sky-500' : 'text-slate-300'
              }`}
            />
            <span
              className={`voice-bar voice-bar-4 ${
                isListening ? 'text-sev-critical' : isSpeaking ? 'text-sky-500' : 'text-slate-300'
              }`}
            />
            <span
              className={`voice-bar voice-bar-5 ${
                isListening ? 'text-sev-critical' : isSpeaking ? 'text-sky-500' : 'text-slate-300'
              }`}
            />
            <span className="ml-2 text-[11px] font-medium text-slate-500">
              {isListening
                ? language === 'te' ? 'మాట్లాడండి...' : 'Listening... Speak now'
                : isSpeaking
                ? language === 'te' ? 'వాయిస్ సమాధానం...' : 'Voice reply speaking...'
                : language === 'te' ? 'మైక్ నొక్కి మాట్లాడండి' : 'Tap mic to speak'}
            </span>
          </div>

          {/* Bottom Controls & Fallback Input */}
          <div className="border-t border-slate-200/80 bg-white p-3">
            <div className="flex items-center gap-2">
              {/* Main Central Microphone Button */}
              <button
                type="button"
                onClick={handleMicToggle}
                aria-label={isListening ? 'Stop listening' : 'Start speaking'}
                className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-white shadow-md transition-all duration-200 hover:scale-105 active:scale-95 ${
                  isListening
                    ? 'voice-mic-glow-listening bg-sev-critical'
                    : isSpeaking
                    ? 'bg-sky-500'
                    : 'bg-slate-900 hover:bg-slate-800'
                }`}
                title={
                  isSpeaking
                    ? 'Interrupt & Speak'
                    : isListening
                    ? 'Stop listening'
                    : 'Tap to speak'
                }
              >
                {isListening ? (
                  <MicOff className="h-5 w-5" />
                ) : (
                  <Mic className="h-5 w-5" />
                )}
              </button>

              {/* Text Fallback Input */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  processMessage(inputText);
                }}
                className="flex flex-1 items-center gap-1.5"
              >
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={
                    language === 'te'
                      ? 'ఇక్కడ టైప్ చేయండి లేదా మాట్లాడండి...'
                      : 'Speak or type emergency message...'
                  }
                  className="h-10 flex-1 rounded-xl border border-slate-200 bg-slate-50/70 px-3 text-xs text-slate-800 placeholder-slate-400 focus:border-coral focus:bg-white focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim() || loading}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-coral text-white transition hover:bg-[#D9614A] disabled:opacity-40"
                  aria-label="Send message"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
