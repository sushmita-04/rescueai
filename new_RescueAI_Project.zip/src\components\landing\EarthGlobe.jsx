import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * High-performance, cinematic Three.js 3D Earth Globe.
 * Sized to occupy ~24-28% of desktop viewport width on the right side of the hero.
 * Features:
 * - High-detail procedural continent map with tactical data-matrix dots and glowing coastlines
 * - Realistic day/night terminator lighting with deep oceanic specularity
 * - Electric-blue atmospheric Fresnel rim glow shader
 * - Delicate orbital lines at 23.5° axial tilt
 * - Pulsing emergency distress beacons (red radar pulses & vertical light beams)
 * - Animated 3D Great-Circle rescue paths with traveling light pulses
 * - Drifting stardust particles in deep space
 * - Smooth mouse parallax with inertial damping (lerp) & touch drag support
 * - Reduced motion support
 */

const EMERGENCY_NODES = [
  { name: 'Tokyo', lat: 35.68, lng: 139.76, type: 'Quake / Tsunami' },
  { name: 'Mumbai', lat: 19.07, lng: 72.88, type: 'Cyclone / Flood' },
  { name: 'San Francisco', lat: 37.77, lng: -122.42, type: 'Wildfire / Quake' },
  { name: 'Jakarta', lat: -6.2, lng: 106.85, type: 'Flash Flood' },
  { name: 'Cairo', lat: 30.04, lng: 31.24, type: 'Severe Storm' },
  { name: 'London', lat: 51.51, lng: -0.13, type: 'Coastal Storm' },
  { name: 'Sydney', lat: -33.87, lng: 151.21, type: 'Wildfire Barrier' }
];

const RESCUE_ARCS = [
  [0, 3], // Tokyo <-> Jakarta
  [3, 1], // Jakarta <-> Mumbai
  [1, 4], // Mumbai <-> Cairo
  [4, 5], // Cairo <-> London
  [2, 0], // San Francisco <-> Tokyo
  [3, 6]  // Jakarta <-> Sydney
];

function latLngToVector3(lat, lng, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

function createEarthTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // 1. Deep midnight oceanic gradient
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  oceanGrad.addColorStop(0, '#020716');
  oceanGrad.addColorStop(0.5, '#01040D');
  oceanGrad.addColorStop(1, '#020716');
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 2. Graticule coordinate grid
  ctx.strokeStyle = 'rgba(34, 211, 238, 0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= canvas.width; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y <= canvas.height; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // 3. Simplified continental landmass polygons
  const W = canvas.width;
  const H = canvas.height;
  const toXY = (lon, lat) => [((lon + 180) / 360) * W, ((90 - lat) / 180) * H];

  const drawPoly = (coords) => {
    if (coords.length < 3) return;
    ctx.beginPath();
    const [startX, startY] = toXY(coords[0][0], coords[0][1]);
    ctx.moveTo(startX, startY);
    for (let i = 1; i < coords.length; i++) {
      const [x, y] = toXY(coords[i][0], coords[i][1]);
      ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = '#081226';
    ctx.fill();
    ctx.strokeStyle = 'rgba(34, 211, 238, 0.55)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
  };

  const northAmerica = [
    [-168, 66], [-140, 70], [-100, 74], [-80, 70], [-60, 50],
    [-70, 42], [-76, 35], [-81, 25], [-97, 26], [-98, 19],
    [-88, 16], [-83, 10], [-77, 8], [-80, 9], [-92, 14],
    [-105, 20], [-115, 30], [-124, 38], [-124, 48], [-135, 57],
    [-160, 58], [-168, 66]
  ];

  const southAmerica = [
    [-77, 8], [-60, 5], [-50, -2], [-35, -5], [-37, -13],
    [-42, -22], [-50, -30], [-65, -45], [-70, -55], [-75, -50],
    [-72, -40], [-71, -30], [-76, -15], [-81, -5], [-77, 8]
  ];

  const europe = [
    [-10, 36], [0, 38], [15, 40], [25, 36], [28, 42],
    [32, 45], [40, 42], [50, 48], [40, 56], [30, 60],
    [25, 71], [15, 65], [5, 60], [-5, 58], [-5, 48],
    [-10, 44], [-10, 36]
  ];

  const africa = [
    [-6, 36], [10, 37], [25, 32], [32, 31], [35, 28],
    [43, 12], [51, 12], [42, -2], [40, -15], [32, -28],
    [27, -34], [18, -34], [12, -20], [10, -5], [2, 4],
    [-14, 11], [-17, 15], [-13, 28], [-6, 36]
  ];

  const asia = [
    [32, 45], [50, 48], [60, 55], [70, 73], [100, 78],
    [140, 72], [170, 65], [170, 60], [140, 50], [130, 38],
    [122, 30], [108, 20], [100, 10], [98, 3], [80, 8],
    [70, 20], [60, 25], [50, 30], [35, 32], [32, 45]
  ];

  const australia = [
    [114, -22], [125, -15], [136, -12], [142, -11], [150, -22],
    [153, -28], [150, -37], [138, -35], [130, -32], [116, -35],
    [113, -26], [114, -22]
  ];

  [northAmerica, southAmerica, europe, africa, asia, australia].forEach(drawPoly);

  // 4. Tactical Data Matrix: Micro-dots across landmasses
  ctx.fillStyle = 'rgba(56, 189, 248, 0.35)';
  for (let i = 0; i < 2000; i++) {
    const rx = Math.random() * canvas.width;
    const ry = Math.random() * canvas.height;
    const p = ctx.getImageData(rx, ry, 1, 1).data;
    if (p[0] === 8 && p[1] === 18 && p[2] === 38) {
      ctx.beginPath();
      ctx.arc(rx, ry, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 5. City lights clusters
  const cityClusters = [
    [-74, 40.7], [-122, 37.7], [-0.1, 51.5], [2.3, 48.8],
    [77.2, 28.6], [72.8, 19.0], [139.7, 35.7], [121.5, 31.2],
    [151.2, -33.9], [31.2, 30.0]
  ];

  cityClusters.forEach(([lon, lat]) => {
    const [cx, cy] = toXY(lon, lat);
    for (let c = 0; c < 12; c++) {
      const ox = cx + (Math.random() - 0.5) * 20;
      const oy = cy + (Math.random() - 0.5) * 14;
      ctx.fillStyle = c === 0 ? 'rgba(255, 255, 255, 0.95)' : 'rgba(251, 191, 36, 0.65)';
      ctx.beginPath();
      ctx.arc(ox, oy, c === 0 ? 1.8 : 0.9, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.generateMipmaps = true;
  return texture;
}

export default function EarthGlobe({ activeScenarioIndex = 0 }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const width = mount.clientWidth || 360;
    const height = mount.clientHeight || 360;

    // 1. Scene & Camera Setup (tailored for compact right-side globe)
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
    camera.position.set(0, 0, 5.0);

    // 2. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    mount.appendChild(renderer.domElement);

    // 3. Lighting: High-Contrast Terminator + Emergency Red Rim
    const ambientLight = new THREE.AmbientLight(0x0a1024, 1.9);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xdbeafe, 3.2);
    sunLight.position.set(5, 3, 4);
    scene.add(sunLight);

    const emergencyRimLight = new THREE.DirectionalLight(0xef4444, 2.2);
    emergencyRimLight.position.set(-5, -2, -2);
    scene.add(emergencyRimLight);

    const fillLight = new THREE.PointLight(0x0284c7, 2.0, 15);
    fillLight.position.set(0, -4, 2);
    scene.add(fillLight);

    // 4. Main Globe Hierarchy
    const globeRadius = 1.55;
    const globeGroup = new THREE.Group();
    globeGroup.rotation.z = (23.5 * Math.PI) / 180; // 23.5° axial tilt
    scene.add(globeGroup);

    // Earth Sphere Core
    const earthGeometry = new THREE.SphereGeometry(globeRadius, 64, 64);
    const earthTexture = createEarthTexture();
    const earthMaterial = new THREE.MeshStandardMaterial({
      map: earthTexture,
      roughness: 0.55,
      metalness: 0.22,
      emissive: new THREE.Color(0x020818),
      emissiveIntensity: 0.5
    });
    const earthMesh = new THREE.Mesh(earthGeometry, earthMaterial);
    globeGroup.add(earthMesh);

    // 5. Electric-Blue Atmospheric Fresnel Rim Shader
    const atmosphereVertexShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `;

    const atmosphereFragmentShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      uniform vec3 glowColor;
      void main() {
        vec3 viewDir = normalize(-vPosition);
        float intensity = pow(1.0 - max(dot(viewDir, vNormal), 0.0), 2.5);
        gl_FragColor = vec4(glowColor, intensity * 0.85);
      }
    `;

    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: atmosphereVertexShader,
      fragmentShader: atmosphereFragmentShader,
      uniforms: {
        glowColor: { value: new THREE.Color(0x22d3ee) }
      },
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false
    });

    const atmosphereMesh = new THREE.Mesh(
      new THREE.SphereGeometry(globeRadius * 1.14, 64, 64),
      atmosphereMaterial
    );
    globeGroup.add(atmosphereMesh);

    // 6. Delicate Orbital Rings
    const orbitGroup = new THREE.Group();
    scene.add(orbitGroup);

    const orbitGeo = new THREE.RingGeometry(globeRadius * 1.35, globeRadius * 1.36, 64);
    const orbitMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.22,
      blending: THREE.AdditiveBlending
    });
    const orbitMesh = new THREE.Mesh(orbitGeo, orbitMat);
    orbitMesh.rotation.x = Math.PI / 2.3;
    orbitMesh.rotation.y = Math.PI / 6;
    orbitGroup.add(orbitMesh);

    // 7. Emergency Distress Beacons (Pulsing Red Beacons & Distress Pins)
    const beaconRings = [];
    const beaconGroup = new THREE.Group();
    globeGroup.add(beaconGroup);

    EMERGENCY_NODES.forEach((node) => {
      const pos = latLngToVector3(node.lat, node.lng, globeRadius);
      const normal = pos.clone().normalize();

      // Glowing core dot
      const markerGeo = new THREE.SphereGeometry(0.032, 16, 16);
      const markerMat = new THREE.MeshBasicMaterial({ color: 0xff2233 });
      const markerMesh = new THREE.Mesh(markerGeo, markerMat);
      markerMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.012)));
      beaconGroup.add(markerMesh);

      // Vertical pin beam
      const beamHeight = 0.28;
      const beamGeo = new THREE.CylinderGeometry(0.003, 0.014, beamHeight, 8);
      const beamMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending
      });
      const beamMesh = new THREE.Mesh(beamGeo, beamMat);
      beamMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
      beamMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(beamHeight / 2)));
      beaconGroup.add(beamMesh);

      // Expanding radar pulses
      for (let r = 0; r < 2; r++) {
        const ringGeo = new THREE.RingGeometry(0.015, 0.038, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xef4444,
          transparent: true,
          opacity: 0.75,
          side: THREE.DoubleSide,
          blending: THREE.AdditiveBlending,
          depthWrite: false
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.015)));
        ringMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
        beaconGroup.add(ringMesh);

        beaconRings.push({
          mesh: ringMesh,
          initialScale: 0.2 + r * 0.5,
          scale: 0.2 + r * 0.5,
          speed: 0.016 + (r % 2) * 0.005,
          maxScale: 2.2
        });
      }
    });

    // 8. Animated 3D Great-Circle Rescue Routes
    const arcPulses = [];
    const arcsGroup = new THREE.Group();
    globeGroup.add(arcsGroup);

    RESCUE_ARCS.forEach(([idxA, idxB], arcIndex) => {
      const nodeA = EMERGENCY_NODES[idxA];
      const nodeB = EMERGENCY_NODES[idxB];
      if (!nodeA || !nodeB) return;

      const pA = latLngToVector3(nodeA.lat, nodeA.lng, globeRadius);
      const pB = latLngToVector3(nodeB.lat, nodeB.lng, globeRadius);

      const distance = pA.distanceTo(pB);
      const midPoint = pA.clone().add(pB).multiplyScalar(0.5);
      const elevation = globeRadius + distance * 0.24;
      midPoint.normalize().multiplyScalar(elevation);

      const curve = new THREE.QuadraticBezierCurve3(pA, midPoint, pB);
      const points = curve.getPoints(40);
      const arcGeometry = new THREE.BufferGeometry().setFromPoints(points);

      const arcMaterial = new THREE.LineBasicMaterial({
        color: arcIndex % 2 === 0 ? 0x22d3ee : 0x6d5ef8,
        transparent: true,
        opacity: 0.4,
        blending: THREE.AdditiveBlending
      });
      const arcLine = new THREE.Line(arcGeometry, arcMaterial);
      arcsGroup.add(arcLine);

      // Light packet pulse
      const pulseGeo = new THREE.SphereGeometry(0.028, 10, 10);
      const pulseMat = new THREE.MeshBasicMaterial({
        color: arcIndex % 2 === 0 ? 0x38bdf8 : 0xef4444,
        blending: THREE.AdditiveBlending
      });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      arcsGroup.add(pulseMesh);

      arcPulses.push({
        curve,
        mesh: pulseMesh,
        progress: (arcIndex * 0.18) % 1.0,
        speed: 0.003 + (arcIndex % 3) * 0.001
      });
    });

    // 9. Floating Space Particles
    const particleCount = 280;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const pRadius = globeRadius * (1.25 + Math.random() * 2.2);
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      particlePositions[i * 3] = pRadius * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = pRadius * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = pRadius * Math.cos(phi);
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.02,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // 10. Interactive Parallax & Touch Handling
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;
    let isDragging = false;
    let prevX = 0;
    let prevY = 0;

    const onPointerMove = (e) => {
      if (prefersReducedMotion) return;
      const cx = e.clientX || (e.touches && e.touches[0]?.clientX) || 0;
      const cy = e.clientY || (e.touches && e.touches[0]?.clientY) || 0;

      if (isDragging) {
        globeGroup.rotation.y += (cx - prevX) * 0.006;
        globeGroup.rotation.x += (cy - prevY) * 0.006;
        prevX = cx;
        prevY = cy;
      } else {
        targetX = (cx / window.innerWidth - 0.5) * 0.5;
        targetY = (cy / window.innerHeight - 0.5) * 0.35;
      }
    };

    const onPointerDown = (e) => {
      isDragging = true;
      prevX = e.clientX || (e.touches && e.touches[0]?.clientX) || 0;
      prevY = e.clientY || (e.touches && e.touches[0]?.clientY) || 0;
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    window.addEventListener('mousemove', onPointerMove, { passive: true });
    window.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mouseup', onPointerUp);
    window.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchstart', onPointerDown, { passive: true });
    window.addEventListener('touchend', onPointerUp);

    const onResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || 360;
      const h = mount.clientHeight || 360;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // 11. Animation Loop
    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      if (!isDragging && !prefersReducedMotion) {
        globeGroup.rotation.y += 0.0018;

        mouseX += (targetX - mouseX) * 0.04;
        mouseY += (targetY - mouseY) * 0.04;
        camera.position.x = mouseX * 0.8;
        camera.position.y = -mouseY * 0.6;
        camera.lookAt(0, 0, 0);

        orbitGroup.rotation.z += 0.0006;
        particles.rotation.y -= 0.0004;
      }

      // Animate pulsing rings
      beaconRings.forEach((ring) => {
        ring.scale += ring.speed;
        if (ring.scale > ring.maxScale) {
          ring.scale = ring.initialScale;
        }
        ring.mesh.scale.set(ring.scale, ring.scale, ring.scale);
        const op = (ring.scale - ring.initialScale) / (ring.maxScale - ring.initialScale);
        ring.mesh.material.opacity = Math.max(0, 0.8 * (1.0 - op));
      });

      // Animate arc pulses
      arcPulses.forEach((pulse) => {
        pulse.progress += pulse.speed;
        if (pulse.progress > 1.0) pulse.progress = 0;
        pulse.mesh.position.copy(pulse.curve.getPoint(pulse.progress));
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchstart', onPointerDown);
      window.removeEventListener('touchend', onPointerUp);
      window.removeEventListener('resize', onResize);

      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
      earthGeometry.dispose();
      earthMaterial.dispose();
      earthTexture.dispose();
      atmosphereMaterial.dispose();
      orbitGeo.dispose();
      orbitMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="w-full h-full relative flex items-center justify-center cursor-grab active:cursor-grabbing select-none"
      style={{ touchAction: 'none' }}
      aria-hidden="true"
    />
  );
}
