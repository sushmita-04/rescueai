import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import session from 'express-session';
import dotenv from 'dotenv';

dotenv.config();

import { initDatabase } from './db.js';
import { createSessionStore } from './sessionStore.js';
import authRouter, { attachUser } from './auth.js';
import sosRouter from './routes/sos.js';
import entitiesRouter from './routes/entities.js';
import functionsRouter from './routes/functions.js';
import audioRouter from './routes/audio.js';

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

// Enable trust proxy for cookies behind reverse proxies (Replit)
app.set('trust proxy', 1);

app.use(
  cors({
    origin: (origin, callback) => callback(null, true),
    credentials: true
  })
);

app.use(express.json({ limit: '12mb' }));
app.use(express.urlencoded({ extended: true, limit: '12mb' }));
app.use(cookieParser());

// Bootstrap database and session store
async function startServer() {
  let retries = 5;
  while (retries > 0) {
    try {
      await initDatabase();
      console.log('Database initialized successfully.');
      break;
    } catch (err) {
      retries--;
      console.warn(`Database connection attempt failed (${err.message}). Retrying in 2s... (${retries} left)`);
      if (retries === 0) throw err;
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  const store = await createSessionStore();
  const isProd = process.env.NODE_ENV === 'production';

  app.use(
    session({
      store,
      secret: process.env.SESSION_SECRET || 'rescueai-secret-session-key-12345',
      name: 'rescueai.sid',
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: isProd,
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      }
    })
  );

  app.use(attachUser);

  // App Public Settings (replaces Base44 getPublicSettings)
  app.get('/api/app/public-settings', (req, res) => {
    res.json({
      id: 'rescueai',
      public_settings: {
        smtp_configured: Boolean(process.env.SMTP_HOST && process.env.SMTP_USER)
      }
    });
  });

  // Mount API modules
  app.use('/api/auth', authRouter);
  app.use('/api', sosRouter);
  app.use('/api', entitiesRouter);
  app.use('/api', functionsRouter);
  app.use('/api', audioRouter);

  // Serve static assets in production or if dist exists
  const distDir = path.resolve(process.cwd(), 'dist');
  if (fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (req, res) => {
      if (req.path.startsWith('/api')) {
        return res.status(404).json({ error: 'Endpoint not found' });
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    app.get('/', (req, res) => {
      res.send('RescueAI API Server is running. In dev mode, run Vite frontend.');
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`RescueAI server listening on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
