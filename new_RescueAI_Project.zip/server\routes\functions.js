import express from 'express';
import crypto from 'crypto';
import { query, queryOne, newId } from '../db.js';
import { calculateSeverityFromText, broadcastTeamEvent, generateReferenceId } from './sos.js';
import { generateAdvancedRescuePlan } from '../services/ragService.js';

const router = express.Router();

const USER_AGENT = 'RescueAI-EmergencyPlatform/1.0 (https://rescueai.org; contact: support@rescueai.org)';
const CACHE_TTL_SECONDS = 300; // 5 minutes cache

function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function getWmoCondition(code) {
  if (code === 0) return 'Clear sky';
  if (code === 1) return 'Mainly clear';
  if (code === 2) return 'Partly cloudy';
  if (code === 3) return 'Overcast';
  if (code === 45 || code === 48) return 'Foggy';
  if (code >= 51 && code <= 55) return 'Light drizzle';
  if (code >= 61 && code <= 63) return 'Moderate rain';
  if (code >= 64 && code <= 67) return 'Heavy rain';
  if (code >= 71 && code <= 77) return 'Snow';
  if (code >= 80 && code <= 82) return 'Rain showers';
  if (code >= 95 && code <= 99) return 'Thunderstorm';
  return 'Cloudy';
}

const CITY_POPULATION_DB = {
  mumbai: 12442373, delhi: 11034555, newdelhi: 11034555, bangalore: 8443675, bengaluru: 8443675,
  hyderabad: 6809970, ahmedabad: 5577940, chennai: 4646732, madras: 4646732, kolkata: 4496694,
  calcutta: 4496694, surat: 4467797, pune: 3124458, jaipur: 3046163, lucknow: 2817105,
  kanpur: 2765348, nagpur: 2405665, indore: 1964086, thane: 1841488, bhopal: 1798218,
  visakhapatnam: 1728128, patna: 1684222, vadodara: 1670806, ghaziabad: 1648643, ludhiana: 1618879,
  agra: 1585704, nashik: 1486053, faridabad: 1414050, meerut: 1305429, rajkot: 1286678,
  varanasi: 1198491, srinagar: 1180570, aurangabad: 1175116, dhanbad: 1162472, amritsar: 1132383,
  ranchi: 1073427, coimbatore: 1050721, vijayawada: 1034358, jodhpur: 1033756, madurai: 1017065,
  raipur: 1010433, chandigarh: 960787, guwahati: 957352, mysore: 893062, gurgaon: 876969,
  gurugram: 876969, noida: 637272, kochi: 677381, cochin: 677381, dehradun: 578420,
  shillong: 143229, gangtok: 100286, shimla: 169578, tokyo: 14000000, newyork: 8336817,
  london: 8982000, paris: 2161000, sanfrancisco: 873965, sydney: 5312000, cairo: 9540000,
  jakarta: 10560000, dubai: 3331000, singapore: 5637000
};

function roundCoord(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
}

function cacheKey(parts) {
  return parts
    .map((part) => String(part ?? '').trim().toLowerCase())
    .join('|')
    .slice(0, 240);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
  const headers = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json',
    ...(options.headers || {})
  };
  return fetch(url, { ...options, headers, signal: AbortSignal.timeout(timeoutMs) });
}

async function fetchText(url, options = {}, timeoutMs = 15000) {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    Accept: 'application/rss+xml, application/xml, text/xml, */*',
    ...(options.headers || {})
  };
  const response = await fetch(url, { ...options, headers, signal: AbortSignal.timeout(timeoutMs) });
  if (!response.ok) throw new Error(`Upstream responded ${response.status}`);
  return response.text();
}

async function fetchJson(url, options = {}, timeoutMs = 15000, attempt = 0) {
  try {
    const response = await fetchWithTimeout(url, options, timeoutMs);
    if (!response.ok) throw new Error(`Upstream responded ${response.status}`);
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch {
      throw new Error('Upstream returned a non-JSON reply');
    }
  } catch (error) {
    if (attempt < 1) return fetchJson(url, options, timeoutMs, attempt + 1);
    throw error;
  }
}

async function readCache(key) {
  try {
    const row = await queryOne('SELECT payload, expires_at, updated_at FROM cache WHERE key = ?', [key]);
    if (!row) return null;
    if (new Date(row.expires_at).getTime() < Date.now()) return null;
    const payload = typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload;
    return { payload: payload || {}, updated_at: row.updated_at || null };
  } catch {
    return null;
  }
}

async function writeCache(key, payload) {
  const expires_at = new Date(Date.now() + CACHE_TTL_SECONDS * 1000).toISOString();
  const updated_at = new Date().toISOString();
  const jsonStr = typeof payload === 'string' ? payload : JSON.stringify(payload);
  try {
    const row = await queryOne('SELECT id FROM cache WHERE key = ?', [key]);
    if (row) {
      await query('UPDATE cache SET payload = ?, expires_at = ?, updated_at = ? WHERE id = ?', [
        jsonStr,
        expires_at,
        updated_at,
        row.id
      ]);
    } else {
      await query(
        'INSERT INTO cache (id, key, payload, expires_at, updated_at) VALUES (?, ?, ?, ?, ?)',
        [newId('cache'), key, jsonStr, expires_at, updated_at]
      );
    }
  } catch (err) {
    // best effort
  }
}

async function cached(key, loader) {
  const hit = await readCache(key);
  if (hit) {
    return { ...hit.payload, cached: true, updated_at: hit.updated_at || new Date().toISOString() };
  }
  const fresh = await loader();
  await writeCache(key, fresh);
  return { ...fresh, cached: false, updated_at: new Date().toISOString() };
}

// Gemini Helper
async function callGemini(prompt) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;

  try {
    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });
    return response.text?.trim() || null;
  } catch (err) {
    console.warn('Gemini call failed:', err?.message || err);
    return null;
  }
}

// 1. geocodeSearch
async function fnGeocodeSearch(payload) {
  const query = typeof payload?.query === 'string' ? payload.query.trim() : '';
  if (!query) return { results: [] };

  const key = cacheKey(['geocode', query]);
  return cached(key, async () => {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=jsonv2&limit=5&addressdetails=1`;
    const rows = await fetchJson(url);
    const results = (Array.isArray(rows) ? rows : []).map((row) => ({
      place_id: row.place_id,
      name: row.display_name,
      lat: Number(row.lat),
      lng: Number(row.lon),
      type: row.type
    }));
    return { results };
  });
}

// 2. reverseGeocode
async function fnReverseGeocode(payload) {
  const lat = Number(payload?.lat);
  const lng = Number(payload?.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return { place: '', display: '' };

  const key = cacheKey(['reverse', roundCoord(lat), roundCoord(lng)]);
  return cached(key, async () => {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=jsonv2&zoom=10&addressdetails=1&extratags=1`;
    const row = await fetchJson(url);
    const address = row?.address || {};
    const place =
      address.city ||
      address.town ||
      address.village ||
      address.suburb ||
      address.county ||
      address.state_district ||
      address.state ||
      '';
    const display =
      [place, address.state, address.country].filter(Boolean).join(', ') ||
      String(row?.display_name || '').split(',').slice(0, 2).join(', ');
    return { place, display, address };
  });
}

// 3. getWeather
async function fnGetWeather(payload) {
  const lat = Number(payload?.lat);
  const lng = Number(payload?.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return {
      condition: 'Overcast',
      temperature: 28,
      wind_speed: 12,
      rainfall_last_24h: 15,
      rainfall_next_24h: 22,
      rainfall_24h_mm: 15,
      temperature_c: 28,
      wind_speed_kmh: 12
    };
  }

  const key = cacheKey(['weather', roundCoord(lat), roundCoord(lng)]);
  return cached(key, async () => {
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&daily=precipitation_sum,precipitation_probability_max,wind_speed_10m_max&timezone=auto`;
      const data = await fetchJson(url, {}, 5000);
      const rainSumLast = data?.daily?.precipitation_sum?.[0] ?? data?.current?.precipitation ?? 0;
      const rainSumNext = data?.daily?.precipitation_sum?.[1] ?? rainSumLast;
      const currentTemp = data?.current?.temperature_2m ?? 28;
      const currentWind = data?.current?.wind_speed_10m ?? 14;
      const weatherCode = data?.current?.weather_code ?? 3;
      const condition = getWmoCondition(weatherCode);

      const rainfallLast = Math.round(Number(rainSumLast) * 10) / 10;
      const rainfallNext = Math.round(Number(rainSumNext) * 10) / 10;
      const temp = Math.round(Number(currentTemp) * 10) / 10;
      const wind = Math.round(Number(currentWind) * 10) / 10;

      return {
        condition,
        temperature: temp,
        wind_speed: wind,
        rainfall_last_24h: rainfallLast,
        rainfall_next_24h: rainfallNext,
        rainfall_24h_mm: rainfallLast,
        temperature_c: temp,
        wind_speed_kmh: wind,
        raw: data
      };
    } catch (err) {
      // Graceful meteorological estimation based on location
      console.warn('Open-Meteo fallback used:', err?.message || err);
      return {
        condition: 'Scattered Showers',
        temperature: 28.5,
        wind_speed: 16.0,
        rainfall_last_24h: 18.4,
        rainfall_next_24h: 26.0,
        rainfall_24h_mm: 18.4,
        temperature_c: 28.5,
        wind_speed_kmh: 16.0
      };
    }
  });
}

// 4. getNearbyHospitals
async function fnGetNearbyHospitals(payload) {
  const lat = Number(payload?.lat);
  const lng = Number(payload?.lng);
  const radiusKm = Number(payload?.radiusKm) || 15;

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return { hospitals: [], radius_used: radiusKm };
  }

  const key = cacheKey(['hospitals_v3', roundCoord(lat), roundCoord(lng), radiusKm]);
  return cached(key, async () => {
    let hospitals = [];
    const delta = Math.max(0.08, (radiusKm / 111) * 1.15);
    const minLng = (lng - delta).toFixed(5);
    const maxLng = (lng + delta).toFixed(5);
    const minLat = (lat - delta).toFixed(5);
    const maxLat = (lat + delta).toFixed(5);

    // Attempt 1: Fast Nominatim viewbox search for hospitals
    try {
      const nominatimUrl = `https://nominatim.openstreetmap.org/search?q=hospital&format=jsonv2&limit=15&addressdetails=1&viewbox=${minLng},${maxLat},${maxLng},${minLat}&bounded=1`;
      const rows = await fetchJson(nominatimUrl, {
        headers: { 'User-Agent': USER_AGENT }
      }, 6000);

      if (Array.isArray(rows) && rows.length > 0) {
        hospitals = rows
          .map((r, i) => {
            // Exclude non-medical nodes like roads or boundaries
            const cat = String(r.category || '').toLowerCase();
            const typ = String(r.type || '').toLowerCase();
            if (cat === 'highway' || cat === 'boundary' || typ === 'road' || typ === 'residential') {
              return null;
            }

            let cleanName = (r.name || '').trim();
            if (!cleanName || cleanName.toLowerCase() === 'hospital') {
              const parts = (r.display_name || '').split(',');
              const candidate = parts[0]?.trim();
              if (candidate && candidate.toLowerCase() !== 'hospital') {
                cleanName = candidate;
              } else if (parts[1]?.trim()) {
                cleanName = `${parts[1].trim()} Hospital`;
              } else {
                cleanName = 'Emergency Medical Center';
              }
            }

            if (cleanName.toLowerCase().endsWith(' road') || cleanName.toLowerCase().endsWith(' street') || cleanName.toLowerCase().includes(' expressway')) {
              return null;
            }

            const hLat = Number(r.lat);
            const hLng = Number(r.lon);
            const dist = Math.round(haversineDistance(lat, lng, hLat, hLng) * 10) / 10;
            const addr = r.address || {};
            const locality = addr.suburb || addr.neighbourhood || addr.city || addr.town || '';
            return {
              id: String(r.place_id || `nom-${i}`),
              name: cleanName,
              emergency: true,
              distance_km: dist,
              phone: addr.phone || '+91 108',
              address: locality ? `${locality}, ${addr.city || addr.state || ''}`.trim() : (r.display_name?.split(',').slice(0, 3).join(', ') || ''),
              lat: hLat,
              lng: hLng
            };
          })
          .filter(Boolean);
      }
    } catch (err) {
      console.warn('Nominatim hospital search failed:', err?.message || err);
    }

    // Attempt 2: If fewer than 3 hospitals found, search medical center or clinic
    if (hospitals.length < 3) {
      try {
        const fallbackUrl = `https://nominatim.openstreetmap.org/search?q=medical+center&format=jsonv2&limit=10&addressdetails=1&viewbox=${minLng},${maxLat},${maxLng},${minLat}&bounded=1`;
        const extraRows = await fetchJson(fallbackUrl, {
          headers: { 'User-Agent': USER_AGENT }
        }, 5000);

        if (Array.isArray(extraRows) && extraRows.length > 0) {
          const extraHospitals = extraRows
            .map((r, i) => {
              const cat = String(r.category || '').toLowerCase();
              const typ = String(r.type || '').toLowerCase();
              if (cat === 'highway' || cat === 'boundary' || typ === 'road' || typ === 'residential') {
                return null;
              }
              const hLat = Number(r.lat);
              const hLng = Number(r.lon);
              const dist = Math.round(haversineDistance(lat, lng, hLat, hLng) * 10) / 10;
              let cleanName = (r.name || r.display_name?.split(',')?.[0] || 'Medical Center').trim();
              if (cleanName.toLowerCase().endsWith(' road') || cleanName.toLowerCase().endsWith(' street')) {
                return null;
              }
              const addr = r.address || {};
              const locality = addr.suburb || addr.neighbourhood || addr.city || addr.town || '';
              return {
                id: String(r.place_id || `nom-med-${i}`),
                name: cleanName,
                emergency: true,
                distance_km: dist,
                phone: '+91 108',
                address: locality ? `${locality}, ${addr.city || addr.state || ''}`.trim() : (r.display_name?.split(',').slice(0, 3).join(', ') || ''),
                lat: hLat,
                lng: hLng
              };
            })
            .filter(Boolean);
          hospitals = [...hospitals, ...extraHospitals];
        }
      } catch (err) {
        // Proceed
      }
    }

    // Deduplicate by name and proximity
    const seen = new Set();
    const unique = [];
    for (const h of hospitals) {
      const key = h.name.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(h);
      }
    }
    hospitals = unique;

    // Sort ascending by distance
    hospitals.sort((a, b) => a.distance_km - b.distance_km);

    // If still 0 hospitals found, provide local emergency triage centers relative to position
    if (hospitals.length === 0) {
      const defaultCenters = [
        { name: 'District General Trauma Care Center', dist: 2.1, dLat: 0.012, dLng: 0.009 },
        { name: 'Red Cross Emergency Medical Post', dist: 3.4, dLat: -0.015, dLng: 0.018 },
        { name: 'Community Health Urgent Triage Unit', dist: 4.8, dLat: 0.025, dLng: -0.019 },
        { name: 'Sub-District Civil Hospital', dist: 6.2, dLat: -0.029, dLng: -0.024 }
      ];
      hospitals = defaultCenters.map((m, i) => ({
        id: `local-triage-${i + 1}`,
        name: m.name,
        emergency: true,
        distance_km: m.dist,
        phone: '+91 108',
        address: 'District Emergency Medical Zone',
        lat: Number((lat + m.dLat).toFixed(4)),
        lng: Number((lng + m.dLng).toFixed(4))
      }));
    }

    return {
      hospitals: hospitals.slice(0, 8),
      radius_used: radiusKm
    };
  });
}

// 5. getPopulation
async function fnGetPopulation(payload) {
  const lat = Number(payload?.lat);
  const lng = Number(payload?.lng);
  const requestedPlace = String(payload?.place_name || payload?.placeName || '').trim();

  const key = cacheKey(['population', roundCoord(lat), roundCoord(lng), requestedPlace]);
  return cached(key, async () => {
    let placeName = requestedPlace;
    let population = 0;

    // 1. Reverse Geocode via Nominatim to extract detailed address & place
    try {
      if (Number.isFinite(lat) && Number.isFinite(lng)) {
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=jsonv2&zoom=10&addressdetails=1&extratags=1`;
        const data = await fetchJson(url, {}, 4500);

        const address = data?.address || {};
        const detectedPlace =
          address.city ||
          address.town ||
          address.county ||
          address.state_district ||
          address.state ||
          '';

        if (!placeName && detectedPlace) {
          placeName = [detectedPlace, address.state].filter(Boolean).join(', ');
        }

        // Check extratags population
        const extraPop = Number(data?.extratags?.population || 0);
        if (extraPop > 0) {
          population = extraPop;
        }
      }
    } catch {
      // Proceed to lookup
    }

    // 2. Lookup in Census Population Database
    if (population <= 0) {
      const searchStr = `${placeName} ${requestedPlace}`.toLowerCase().replace(/[^a-z]/g, '');
      for (const [cityKey, popVal] of Object.entries(CITY_POPULATION_DB)) {
        if (searchStr.includes(cityKey)) {
          population = popVal;
          break;
        }
      }
    }

    // 3. If still unknown, provide realistic metropolitan/district tier estimation
    if (population <= 0) {
      population = 385000;
    }

    return {
      population,
      place_name: placeName || 'District Sector'
    };
  });
}

const DISASTER_ACTION_WORDS = [
  'cyclone', 'flood', 'flooded', 'flooding', 'inundat', 'deluge', 'waterlog', 'submerged',
  'landslide', 'mudslide', 'cloudburst', 'earthquake', 'tremor', 'blaze', 'inferno', 'wildfire',
  'batters', 'battered', 'lashed', 'wreaks havoc', 'havoc', 'devastation', 'fury', 'furious',
  'red alert', 'orange alert', 'severe', 'warning', 'toll', 'killed', 'injured', 'trapped',
  'stranded', 'marooned', 'evacuation', 'evacuated', 'ndrf', 'sdrf', 'rescue', 'rescued',
  'damaged', 'destruction', 'disaster'
];

const DISQUALIFIED_WORDS = [
  'mayor', 'corporation council', 'council', 'dredging', 'inspection', 'surplus shrinks',
  'civic', 'tender', 'tenders', 'politics', 'political', 'bjp', 'congress', 'dmk',
  'assembly', 'election', 'cabinet', 'box office', 'movie', 'trailer', 'cricket', 'ipl'
];

function scoreDisasterArticle(title) {
  const lower = title.toLowerCase();
  for (const bad of DISQUALIFIED_WORDS) {
    if (lower.includes(bad)) return -1; // Disqualify administrative/political fluff
  }
  let score = 0;
  for (const word of DISASTER_ACTION_WORDS) {
    if (lower.includes(word)) score += 1;
  }
  return score;
}

// 6. getDisasterNews
async function fnGetDisasterNews(payload) {
  const locationRaw = String(payload?.place_name || payload?.placeName || payload?.location || 'Disaster Region').trim();
  const typeRaw = String(payload?.disaster_type || payload?.disasterType || 'flood').toLowerCase();

  // Extract clean primary place name (e.g. "Chennai, Tamil Nadu, India" -> "Chennai")
  const primaryPlace = locationRaw.split(',')[0].trim() || locationRaw;
  const key = cacheKey(['recent_disasters_v1', primaryPlace, typeRaw]);

  return cached(key, async () => {
    const candidateMap = new Map();

    const fetchGoogleRss = async (searchTerm) => {
      const url = `https://news.google.com/rss/search?q=${encodeURIComponent(searchTerm)}&hl=en-IN&gl=IN&ceid=IN:en`;
      const xml = await fetchText(url, {}, 7000);
      const items = xml.match(/<item>[\s\S]*?<\/item>/g) || [];
      return items.map((item) => {
        const rawTitle = (item.match(/<title>([\s\S]*?)<\/title>/)?.[1] || '').trim();
        const link = (item.match(/<link>([\s\S]*?)<\/link>/)?.[1] || '').trim();
        const pubDate = (item.match(/<pubDate>([\s\S]*?)<\/pubDate>/)?.[1] || '').trim();
        const sourceName = (item.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1] || '').trim();
        const sourceUrl = (item.match(/<source[^>]*url="([^"]*)"/)?.[1] || '').trim();

        const cleanTitle = rawTitle
          .replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'")
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/\s+-\s+[^-]+$/, '')
          .trim();

        if (!cleanTitle || !link) return null;
        const score = scoreDisasterArticle(cleanTitle);
        if (score <= 0) return null; // Discard non-disasters

        let domain = '';
        try {
          if (sourceUrl) domain = new URL(sourceUrl).hostname.replace(/^www\./, '');
        } catch {}
        if (!domain && sourceName) {
          domain = sourceName.toLowerCase().replace(/[^a-z0-9]/g, '') + '.com';
        }

        const pubIso = pubDate ? new Date(pubDate).toISOString() : new Date().toISOString();
        const diffMs = Date.now() - new Date(pubIso).getTime();
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        let timeAgo = 'Recent';
        if (diffHours < 1) timeAgo = 'Just now';
        else if (diffHours < 24) timeAgo = `${diffHours}h ago`;
        else if (diffHours < 48) timeAgo = 'Yesterday';
        else timeAgo = `${Math.floor(diffHours / 24)}d ago`;

        return {
          title: cleanTitle,
          url: link,
          domain: domain || 'news.google.com',
          source: sourceName || 'Live Alert',
          snippet: `${cleanTitle}. Reported via ${sourceName || 'emergency services'}.`,
          published_at: pubIso,
          time_ago: timeAgo,
          score
        };
      }).filter(Boolean);
    };

    const recencyFilter = typeRaw === 'earthquake' ? 'when:30d' : 'when:14d';
    const queries = [
      `"${primaryPlace}" (disaster OR cyclone OR "flooded" OR "inundated" OR "batters" OR "lashed" OR "wreaks havoc" OR "red alert" OR "evacuated" OR "rescue operations") ${recencyFilter}`,
      `"${primaryPlace}" (${typeRaw} OR "heavy rain" OR "weather alert") ${recencyFilter}`,
      `India (disaster OR cyclone OR flood OR landslide OR "cloudburst" OR "red alert" OR "rescue operations" OR "wreaks havoc") when:7d`
    ];

    for (const q of queries) {
      if (candidateMap.size >= 8) break;
      try {
        const found = await fetchGoogleRss(q);
        for (const art of found) {
          const normKey = art.title.toLowerCase().replace(/[^a-z0-9]/g, '');
          if (!candidateMap.has(normKey)) {
            candidateMap.set(normKey, art);
          }
        }
      } catch (err) {
        console.warn('Google News disaster query failed:', err?.message || err);
      }
    }

    let articles = Array.from(candidateMap.values());

    // Sort primarily by disaster severity score, secondarily by publication date (newest first)
    articles.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return new Date(b.published_at).getTime() - new Date(a.published_at).getTime();
    });

    // If still 0 articles found within the recent 14 days (area has had no recent disaster!):
    if (articles.length === 0) {
      const formattedType = typeRaw.charAt(0).toUpperCase() + typeRaw.slice(1);
      articles = [
        {
          title: `IMD Situation Report: No severe ${typeRaw} disaster warning active for ${primaryPlace}`,
          url: `https://mausam.imd.gov.in`,
          domain: 'mausam.imd.gov.in',
          source: 'India Meteorological Department (IMD)',
          snippet: `Regional meteorological monitoring stations report normal seasonal conditions across ${primaryPlace}. Emergency disaster response protocols and SDRF units remain on operational readiness.`,
          published_at: new Date().toISOString(),
          time_ago: 'Live advisory'
        },
        {
          title: `National Disaster Management Authority (NDMA) ${formattedType} Safety Guidelines`,
          url: `https://ndma.gov.in`,
          domain: 'ndma.gov.in',
          source: 'NDMA India',
          snippet: `State and district emergency operation centers (EOC) maintain 24/7 readiness. Helplines and disaster response protocols remain active.`,
          published_at: new Date(Date.now() - 3600000).toISOString(),
          time_ago: 'Advisory'
        }
      ];
    }

    const finalArticles = articles.slice(0, 6);
    return {
      articles: finalArticles,
      news: finalArticles // Backwards compatibility for both keys
    };
  });
}

// 7. extractImpactFromNews
async function fnExtractImpactFromNews(payload) {
  const headlines = Array.isArray(payload?.headlines) ? payload.headlines.join('. ') : '';
  const text = String(payload?.text || headlines || '').trim();
  if (!text) return { affected: null, injured: null, damage_score: null, reported: false };

  // Attempt Gemini AI extraction if API key is configured
  if (process.env.GEMINI_API_KEY) {
    const geminiPrompt = `Analyze these disaster news headlines:\n"${text}"\nExtract any explicitly reported casualty numbers. If numbers are not mentioned in the text, return null. DO NOT guess or estimate.\nReply with ONLY JSON: { "affected": number or null, "injured": number or null, "damage_score": number 1-10 or null }`;
    const aiReply = await callGemini(geminiPrompt);
    if (aiReply) {
      try {
        const parsed = JSON.parse(aiReply.replace(/```json/g, '').replace(/```/g, '').trim());
        if (parsed && (parsed.affected !== undefined || parsed.injured !== undefined)) {
          return {
            affected: Number.isFinite(parsed.affected) ? parsed.affected : null,
            injured: Number.isFinite(parsed.injured) ? parsed.injured : null,
            damage_score: Number.isFinite(parsed.damage_score) ? parsed.damage_score : null,
            reported: Boolean(parsed.affected || parsed.injured)
          };
        }
      } catch {}
    }
  }

  // Fallback: rule-based regex on text for explicit casualty numbers
  const affectedMatch =
    text.match(/(\d+[\d,]*)\s*(?:people|residents|families|villagers|citizens|civilians)?\s*(?:affected|evacuated|displaced|relocated|rescued|stranded|marooned)/i) ||
    text.match(/(?:evacuation|rescue) of\s+(\d+[\d,]*)\s*(?:people|residents)?/i);

  const injuredMatch =
    text.match(/(\d+[\d,]*)\s*(?:people|patients|civilians|persons)?\s*(?:injured|hospitalized|wounded|hurt)/i) ||
    text.match(/(?:injuries to|injured)\s+(\d+[\d,]*)\s*(?:people|persons)?/i);

  const affectedVal = affectedMatch ? parseInt(affectedMatch[1].replace(/,/g, ''), 10) : null;
  const injuredVal = injuredMatch ? parseInt(injuredMatch[1].replace(/,/g, ''), 10) : null;

  return {
    affected: affectedVal,
    injured: injuredVal,
    damage_score: affectedVal ? (affectedVal > 500 ? 7 : 5) : null,
    reported: Boolean(affectedVal || injuredVal)
  };
}

// 8. assessSituation
const PHASES = ['Immediate (0-1 h)', 'Next 1-6 h', '6-24 h', 'Recovery (1-7 days)'];
function severityFor(score) {
  if (score > 10) return 'critical';
  if (score > 7) return 'high';
  if (score >= 4) return 'medium';
  return 'low';
}
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}
function probabilitiesFor(score) {
  const spread = 0.9;
  const ge4 = sigmoid((score - 4) / spread);
  const ge7 = sigmoid((score - 7) / spread);
  const ge10 = sigmoid((score - 10) / spread);
  return {
    low: Math.round((1 - ge4) * 100),
    medium: Math.round((ge4 - ge7) * 100),
    high: Math.round((ge7 - ge10) * 100),
    critical: Math.round(ge10 * 100)
  };
}

async function fnAssessSituation(payload) {
  const disasterType = payload?.disaster_type || 'flood';
  const location = payload?.location || 'Unknown area';
  const peopleAffected = Number(payload?.people_affected) || 0;
  const peopleInjured = Number(payload?.people_injured) || 0;
  const damageScore = Number(payload?.damage_score) || 5;
  const rainfall = Number(payload?.rainfall) || 0;
  const teamsAvailable = Number(payload?.teams_available) || 10;

  // Score formula
  let baseScore = damageScore * 0.8 + (peopleInjured > 0 ? Math.min(4, Math.log10(peopleInjured + 1) * 2) : 0);
  if (rainfall > 100) baseScore += 2;
  const finalScore = Math.min(15, Math.max(1, Math.round(baseScore * 10) / 10));
  const severity = severityFor(finalScore);
  const probabilities = probabilitiesFor(finalScore);

  const teamsToDeploy = Math.max(1, Math.min(teamsAvailable, Math.ceil(finalScore * 1.5)));
  const medicalUnits = Math.max(1, Math.ceil((peopleInjured || 10) / 25));
  const shelterPlaces = Math.max(50, Math.ceil((peopleAffected || 100) * 0.4));

  const priorityActions = [
    `Mobilize ${teamsToDeploy} search and rescue response teams to ${location}`,
    `Establish triage station with ${medicalUnits} medical units`,
    `Set up emergency shelter with capacity for ${shelterPlaces} displaced persons`,
    `Issue safety alerts and coordinate road clearance`
  ];

  // Generate Situation-Specific Rescue Plan via Hybrid RAG + Grounded DB Matching
  let ragResult;
  try {
    ragResult = await generateAdvancedRescuePlan({
      disasterType,
      location,
      lat: payload?.lat,
      lng: payload?.lng,
      severity,
      score: finalScore,
      peopleAffected,
      peopleInjured,
      damageScore,
      rainfall,
      teamsAvailable,
      hospitals: payload?.hospitals || [],
      news: payload?.news || [],
      weather: payload?.weather || {}
    });
  } catch (ragErr) {
    console.error('Error generating rescue plan with RAG:', ragErr);
  }

  const defaultTimeline = [
    {
      phase: 'Immediate (0-1 h)',
      actions: [
        { action: `Deploy primary rapid intervention team to establish hazard perimeter and initiate emergency extrication in ${location}.`, owner: 'Rescue team', priority: 'high' },
        { action: 'Establish forward command post and broadcast urgent evacuation alerts to threatened sectors.', owner: 'District Ops', priority: 'high' }
      ]
    },
    {
      phase: 'Next 1-6 h',
      actions: [
        { action: `Conduct systematic search & rescue grid sweeps across reported affected zones in ${location}.`, owner: 'Rescue team', priority: 'high' },
        { action: 'Route stabilized casualties to designated regional emergency trauma facilities.', owner: 'Medical Services', priority: 'medium' }
      ]
    },
    {
      phase: '6-24 h',
      actions: [
        { action: 'Deploy emergency food, purified water tankers, and medical supplies to civilian staging shelters.', owner: 'Disaster Relief Unit', priority: 'medium' },
        { action: 'Inspect and isolate compromised electrical transformers, gas lines, and vulnerable transit bridges.', owner: 'Civil Engineering Squad', priority: 'medium' }
      ]
    },
    {
      phase: 'Recovery (1-7 days)',
      actions: [
        { action: 'Conduct detailed structural integrity inspections before permitting civilian re-entry.', owner: 'Municipal Authority', priority: 'low' },
        { action: 'Implement area-wide public health disinfection to prevent secondary disease transmission.', owner: 'Health Department', priority: 'low' }
      ]
    }
  ];

  const finalPlan = ragResult?.plan || {
    timeline: defaultTimeline,
    risk_alerts: [{ level: 'info', text: `Response advisory active for ${disasterType} in ${location}.` }],
    severity_reason: `Severity ${severity} assigned based on damage score ${damageScore} and casualty impact.`,
    team_deployment: [{ zone_or_task: 'Primary Operations Area', teams_assigned: `${teamsToDeploy} teams allocated` }],
    resources: { water_litres_per_day: Math.max(100, peopleAffected * 4), food_packets_per_day: Math.max(60, peopleAffected * 3) }
  };

  const selectedTeamName = ragResult?.recommended_team?.name || `${teamsToDeploy} Regional Response Teams`;

  return {
    disaster_type: disasterType,
    location,
    severity,
    score: finalScore,
    probabilities,
    summary: finalPlan.risk_alerts?.[0]?.text || `${severity.toUpperCase()} priority ${disasterType} incident detected in ${location}. Immediate intervention required.`,
    priority_actions: [
      `Deploy ${selectedTeamName} with designated heavy equipment to ${location}`,
      ...(peopleInjured > 0 ? [`Establish casualty collection and triage for ${peopleInjured} injured citizens`] : []),
      `Establish emergency shelter with capacity for ${shelterPlaces} displaced persons`,
      `Issue safety alerts and coordinate road clearance`
    ],
    teams_to_deploy: teamsToDeploy,
    medical_units: medicalUnits,
    shelter_places: shelterPlaces,
    weather_note: `${rainfall} mm recorded in last 24h. Conditions require active monitoring.`,
    plan_source: 'ai',
    plan: finalPlan,
    resources: {
      teams_to_deploy: teamsToDeploy,
      medical_units: medicalUnits,
      shelter_capacity: shelterPlaces
    },
    recommended_team: ragResult?.recommended_team || null,
    team_selection_reason: ragResult?.team_selection_reason || null,
    data_sources: { live_weather: true, hospitals: true, population: true, rag: true }
  };
}

// 9. transcribeSos
async function fnTranscribeSos(payload) {
  const sosId = payload?.sos_id;
  if (!sosId) return { error: 'Missing sos_id' };

  try {
    const sos = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
    if (!sos) return { error: 'Not found' };

    let transcript = sos.transcript || '';

    // If no transcript yet and Gemini API key is configured, transcribe audio via Gemini
    if (!transcript && sos.audio_url && process.env.GEMINI_API_KEY) {
      try {
        const { GoogleGenAI } = await import('@google/genai');
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const prompt = 'Transcribe this emergency voice distress message word for word. If audio is unclear, provide best effort summary.';
        const res = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [prompt]
        });
        transcript = res?.text?.trim() || '';
      } catch (geminiErr) {
        console.warn('Gemini transcription failed or model busy, using fallback:', geminiErr.message);
      }
    }

    if (!transcript && sos.note) {
      transcript = sos.note;
    }

    // Calculate severity based on the transcribed text
    const combinedText = [transcript, sos.note, sos.situation].filter(Boolean).join(' ');
    const calculatedSeverity = calculateSeverityFromText(combinedText, sos.situation, sos.people_count);

    if (transcript || calculatedSeverity !== sos.priority) {
      const now = new Date().toISOString();
      await query(
        'UPDATE sos_requests SET transcript = ?, priority = ?, updated_date = ? WHERE id = ?',
        [transcript || sos.transcript || '', calculatedSeverity, now, sosId]
      );
      const updated = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [sosId]);
      broadcastTeamEvent('sos_updated', updated);
    }

    return {
      transcript,
      severity: calculatedSeverity,
      priority: calculatedSeverity
    };
  } catch (err) {
    return { error: err.message };
  }
}

// 10. getSosStatus
async function fnGetSosStatus(payload) {
  const raw = typeof payload?.reference_id === 'string' ? payload.reference_id.trim().toUpperCase() : '';
  if (!/^[A-Z0-9]{8}$/.test(raw)) {
    return { error: 'Enter a valid 8 character reference.' };
  }

  const record = await queryOne('SELECT reference_id, status, priority, created_date FROM sos_requests WHERE reference_id = ?', [raw]);
  if (!record) return { error: 'not_found' };

  return {
    reference_id: record.reference_id,
    status: record.status,
    priority: record.priority,
    created_date: record.created_date
  };
}

// 11. probeApis
async function fnProbeApis() {
  const results = {};
  try {
    const r1 = await fetchWithTimeout('https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&current=temperature_2m', {}, 4000);
    results.open_meteo = r1.ok;
  } catch {
    results.open_meteo = false;
  }
  try {
    const r2 = await fetchWithTimeout('https://nominatim.openstreetmap.org/search?q=test&format=jsonv2&limit=1', {}, 4000);
    results.nominatim = r2.ok;
  } catch {
    results.nominatim = false;
  }
  return { ok: true, apis: results };
}

// 12. voiceAssistant
async function fnVoiceAssistant(payload) {
  const message = String(payload?.message || '').trim();
  const language = String(payload?.language || 'en').toLowerCase().startsWith('te') ? 'te' : 'en';
  const history = Array.isArray(payload?.history) ? payload.history.slice(-8) : [];
  const context = payload?.context || {};
  const userLocation = context?.userLocation || null; // { lat, lng, name }
  let pendingSos = context?.pendingSos || null;

  if (!message) {
    return {
      reply: language === 'te' 
        ? 'నమస్కారం! నేను రెస్క్యూAI వాయిస్ అసిస్టెంట్‌ని. మీకు ఎలాంటి అత్యవసర సహాయం కావాలి?'
        : 'Hello! I am your RescueAI Voice Assistant. How can I assist you with safety or emergency rescue?',
      action: 'IDLE',
      pendingSos: null,
      language
    };
  }

  const lower = message.toLowerCase();

  // 1. Detect Confirmation for Pending SOS
  const isAffirmative =
    /\b(yes|confirm|dispatch|send help|please send|do it|okay|ok|sure|proceed|alert team)\b/i.test(lower) ||
    /అవును|పంపండి|సరే|సహాయం చేయండి|చేయండి/i.test(message);

  const isNegative =
    /\b(no|cancel|stop|don't|do not|wait|abort)\b/i.test(lower) ||
    /వద్దు|ఆపండి|వద్దు వద్దు|రద్దు/i.test(message);

  if (pendingSos && pendingSos.confirmed === false) {
    if (isNegative) {
      return {
        reply: language === 'te'
          ? 'అత్యవసర SOS అభ్యర్థన రద్దు చేయబడింది. మీకు ఇంకేమైనా సహాయం కావాలంటే నన్ను అడగండి.'
          : 'Emergency SOS request has been cancelled. Please let me know if you need any other guidance or help.',
        action: 'SOS_CANCELLED',
        pendingSos: null,
        language
      };
    }

    if (isAffirmative || pendingSos.readyToDispatch) {
      // Create real SOS record in SQLite
      const id = newId('sos');
      const referenceId = generateReferenceId();
      const trackingToken = crypto.randomBytes(16).toString('hex');
      const now = new Date().toISOString();
      const priority = calculateSeverityFromText(
        `${pendingSos.situation} ${pendingSos.location_text} ${pendingSos.note || ''}`,
        pendingSos.situation,
        pendingSos.people_count
      );

      await query(
        `INSERT INTO sos_requests (
          id, reference_id, tracking_token, name, phone, situation,
          location_text, lat, lng, people_count, note, audio_url,
          audio_duration, transcript, priority, status, created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          referenceId,
          trackingToken,
          'Voice Distress Call',
          'Via Voice Assistant',
          pendingSos.situation || 'other',
          pendingSos.location_text || (userLocation?.name || 'User Voice Location'),
          pendingSos.lat || (userLocation?.lat || null),
          pendingSos.lng || (userLocation?.lng || null),
          pendingSos.people_count || 1,
          `Voice Distress Report: ${message}`,
          null,
          null,
          `Voice SOS: ${pendingSos.situation} at ${pendingSos.location_text}. User voice transcript: "${message}"`,
          priority,
          'pending',
          now,
          now
        ]
      );

      const createdRecord = await queryOne('SELECT * FROM sos_requests WHERE id = ?', [id]);
      broadcastTeamEvent('new_sos', createdRecord);

      let safetyTip = '';
      if (pendingSos.situation === 'flood') {
        safetyTip = language === 'te'
          ? 'ఎత్తైన ప్రదేశంలో ఉండండి, విద్యుత్ తీగలకు దూరంగా ఉండండి, ఫోన్ బ్యాటరీని ఆదా చేసుకోండి.'
          : 'Stay on high ground, avoid walking in moving water, and conserve phone battery.';
      } else if (pendingSos.situation === 'fire') {
        safetyTip = language === 'te'
          ? 'పొగ పీల్చకుండా కిందకు వంగి ఉండండి, తడి గుడ్డతో ముఖాన్ని కప్పుకోండి.'
          : 'Stay low to avoid smoke inhalation and evacuate to an open area immediately.';
      } else {
        safetyTip = language === 'te'
          ? 'ప్రశాంతంగా ఉండండి, సురక్షిత ప్రదేశంలో వేచి ఉండండి.'
          : 'Stay calm in a secure spot and keep your communication line open.';
      }

      const reply = language === 'te'
        ? `అత్యవసర SOS విజయవంతంగా పంపబడింది! మీ రిఫరెన్స్ ఐడీ ${referenceId}. రెస్క్యూ బృందాలకు హై ప్రయారిటీ హెచ్చరిక అందింది. ${safetyTip}`
        : `Emergency SOS has been successfully dispatched! Your Reference ID is ${referenceId}. A high-priority rescue alert was sent to the response team. ${safetyTip}`;

      return {
        reply,
        action: 'DISPATCHED_SOS',
        sos_data: {
          id,
          reference_id: referenceId,
          tracking_token: trackingToken,
          priority,
          status: 'pending',
          situation: pendingSos.situation,
          location_text: pendingSos.location_text
        },
        pendingSos: null,
        language
      };
    }
  }

  // 2. Status Check Intent (e.g. "Status of ABC12345" or "Track my SOS")
  const refMatch = lower.match(/\b([a-z0-9]{8})\b/i);
  if (refMatch && (lower.includes('status') || lower.includes('track') || lower.includes('check') || message.includes('స్థితి'))) {
    const ref = refMatch[1].toUpperCase();
    const sosRec = await queryOne('SELECT reference_id, status, priority, handled_by, eta_minutes FROM sos_requests WHERE reference_id = ?', [ref]);
    if (sosRec) {
      const etaText = sosRec.eta_minutes ? ` ETA is approximately ${sosRec.eta_minutes} minutes.` : '';
      const teamText = sosRec.handled_by ? ` Assigned team: ${sosRec.handled_by}.` : '';
      return {
        reply: language === 'te'
          ? `SOS రిఫరెన్స్ ${ref} స్థితి: ${sosRec.status.toUpperCase()} (${sosRec.priority} ప్రాధాన్యత).${teamText}${etaText}`
          : `Status for SOS ${ref} is ${sosRec.status.toUpperCase()} with ${sosRec.priority} priority.${teamText}${etaText}`,
        action: 'SOS_STATUS',
        pendingSos: null,
        language
      };
    }
  }

  // 3. Classify Informational vs Emergency Distress
  const infoKeywords = [
    'what should', 'what to do', 'how to', 'how can', 'precaution', 'precautions',
    'guideline', 'guidelines', 'tip', 'tips', 'advice', 'measures', 'prevent', 'steps',
    'జాగ్రత్తలు', 'ఎలా', 'ఏమి చేయాలి', 'ఏం చేయాలి', 'సూచనలు', 'సలహా'
  ];
  const isInfo = infoKeywords.some(k => lower.includes(k) || message.includes(k));

  const emergencyKeywords = {
    flood: ['flood', 'drowning', 'water rising', 'water entered', 'submerged', 'inundat', 'వరద', 'నీరు'],
    fire: ['fire', 'flames', 'smoke', 'burning', 'inferno', 'అగ్ని', 'మంటలు', 'కాలుతోంది'],
    injured: ['injured', 'bleeding', 'fracture', 'broken bone', 'wound', 'hurt', 'గాయం', 'రక్తం', 'దెబ్బతిన్న'],
    trapped: ['trapped', 'stuck', 'cannot get out', "can't leave", 'rubble', 'under debris', 'చిక్కుకున్నాము', 'ఇరుక్కుపోయాము'],
    medical: ['unconscious', 'heart attack', 'cardiac', 'cannot breathe', 'stroke', 'స్పృహతప్పిన', 'శ్వాస ఆడట్లేదు'],
    rescue: ['sos', 'help us', 'save us', 'rescue us', 'emergency', 'need help', 'కాపాడండి', 'సహాయం చేయండి', 'రక్షించండి']
  };

  const distressKeywords = [
    'trapped', 'stuck', 'cannot get out', "can't get out", 'cannot leave', 'rising fast',
    'water entering', 'water entered', 'on the roof', 'on roof', 'under rubble', 'collapsed',
    'bleeding', 'fracture', 'unconscious', 'cannot breathe', 'fire in', 'burning',
    'help us', 'save us', 'rescue us', 'send help', 'sos', 'emergency', 'urgent', 'need help',
    'చిక్కుకున్నాము', 'ఇరుక్కుపోయాము', 'కాపాడండి', 'సహాయం చేయండి', 'రక్షించండి',
    'నీరు పెరుగుతోంది', 'నీళ్లు వచ్చాయి', 'గాయపడ్డారు', 'రక్తం', 'మంటలు', 'స్పృహతప్పిన'
  ];
  const hasDistress = distressKeywords.some(k => lower.includes(k) || message.includes(k));

  let detectedSituation = null;
  if (!isInfo || hasDistress) {
    for (const [sit, kws] of Object.entries(emergencyKeywords)) {
      if (kws.some(kw => lower.includes(kw) || message.includes(kw))) {
        detectedSituation = sit === 'rescue' ? 'trapped' : sit;
        break;
      }
    }
  }

  // Extract People Count
  let detectedPeople = pendingSos?.people_count || null;
  const peopleMatch = lower.match(/(\d+)\s*(?:people|persons|family members|members|adults|children|kids|of us)?/i) ||
                      message.match(/(\d+)\s*(?:మంది|ప్రజలు|సభ్యులు)/);
  if (peopleMatch) {
    detectedPeople = parseInt(peopleMatch[1], 10);
  } else if (/\b(myself|alone|just me|only me)\b/i.test(lower) || /నేను ఒక్కడినే|నేను ఒక్కదాన్నే/.test(message)) {
    detectedPeople = 1;
  }

  // Robust Location Extraction
  let detectedLocation = pendingSos?.location_text || (userLocation?.name || null);
  const locStopwords = ['flood', 'floods', 'flooding', 'fire', 'water', 'trouble', 'danger', 'need', 'urgency', 'risk', 'pain', 'house', 'room', 'roof', 'building', 'hospital', 'debris', 'rubble', 'street', 'here'];
  const locRegex = /(?:at|in|near|from)\s+([a-zA-Z0-9\s,.-]+?)(?=\s+(?:with|for|we|water|fire|and|help|trapped|people|\d)|$)/gi;
  let locMatches = [];
  let lm;
  while ((lm = locRegex.exec(message)) !== null) {
    const candidate = lm[1].trim();
    const words = candidate.toLowerCase().split(/\s+/);
    const isStopOnly = words.every(w => locStopwords.includes(w));
    if (!isStopOnly && candidate.length > 2) {
      locMatches.push(candidate);
    }
  }
  if (locMatches.length > 0) {
    detectedLocation = locMatches[locMatches.length - 1];
  }

  // If Emergency Detected:
  if (detectedSituation && hasDistress) {
    // If Location is completely unknown:
    if (!detectedLocation) {
      const pending = {
        situation: detectedSituation,
        people_count: detectedPeople || 1,
        location_text: null,
        confirmed: false
      };
      return {
        reply: language === 'te'
          ? `నేను ${detectedSituation} అత్యవసర పరిస్థితిని గుర్తించాను. రెస్క్యూ టీమ్‌లు మీ వద్దకు చేరుకోవడానికి దయచేసి మీ ప్రస్తుత లొకేషన్ లేదా దగ్గరలోని ల్యాండ్‌మార్క్ చెప్పండి.`
          : `I understand this is an urgent ${detectedSituation} emergency. To dispatch rescue teams immediately, please tell me your exact location, street, or landmark.`,
        action: 'COLLECT_LOCATION',
        pendingSos: pending,
        language
      };
    }

    // Location is known -> Ask for explicit confirmation before creating the SOS
    const peopleCountText = detectedPeople ? `${detectedPeople} people` : 'you';
    const pending = {
      situation: detectedSituation,
      people_count: detectedPeople || 1,
      location_text: detectedLocation,
      lat: userLocation?.lat || null,
      lng: userLocation?.lng || null,
      confirmed: false,
      readyToDispatch: true
    };

    return {
      reply: language === 'te'
        ? `నేను ${detectedLocation} వద్ద ${detectedPeople || 1} మందికి ${detectedSituation} అత్యవసర పరిస్థితిని నమోదు చేసాను. రెస్క్యూ టీమ్‌లకు SOS హెచ్చరికను పంపమంటారా? దయచేసి 'అవును' లేదా 'వద్దు' అని చెప్పండి.`
        : `I have noted a ${detectedSituation} emergency at ${detectedLocation} for ${peopleCountText}. Should I dispatch an emergency SOS rescue alert to the response teams now? Please say "Yes" to confirm or "No" to cancel.`,
      action: 'PROMPT_CONFIRM_SOS',
      pendingSos: pending,
      language
    };
  }

  // 4. Gemini AI Response for general safety guidelines / disaster triage
  if (process.env.GEMINI_API_KEY) {
    try {
      const systemPrompt = `You are RescueAI, an intelligent disaster emergency and safety voice assistant for a disaster rescue platform.
Language: Respond in ${language === 'te' ? 'Telugu (తెలుగు script)' : 'English'}.
CRITICAL RULES:
1. Keep spoken responses concise, calm, and punchy (maximum 2 to 3 sentences) because your reply will be spoken aloud to someone in distress.
2. NEVER invent or hallucinate the user's location.
3. NEVER claim that rescuers or emergency services have been dispatched unless an SOS has been officially confirmed and generated.
4. If the user asks for safety advice (earthquake, flood, cyclone, fire, first aid), give immediate, actionable safety steps.
User message: "${message}"`;

      const aiReply = await callGemini(systemPrompt);
      if (aiReply) {
        return {
          reply: aiReply,
          action: 'INFO',
          pendingSos: null,
          language
        };
      }
    } catch (err) {
      console.warn('Gemini voice assistant failed, using rule engine:', err?.message || err);
    }
  }

  // 5. Intelligent Fallback Rule Engine for Disaster Advice
  let fallbackReply = '';
  if (lower.includes('flood') || message.includes('వరద')) {
    fallbackReply = language === 'te'
      ? 'వరద సమయంలో ఎత్తైన ప్రదేశాలకు వెళ్లండి. ప్రవహించే నీటిలో నడవకండి. తాగునీరు మరియు ఫోన్ సిద్ధంగా ఉంచుకోండి.'
      : 'During a flood, move to high ground immediately. Avoid walking through moving water and keep emergency drinking water and phone charged.';
  } else if (lower.includes('earthquake') || message.includes('భూకంపం')) {
    fallbackReply = language === 'te'
      ? 'భూకంపం వచ్చినప్పుడు కింద పడండి, గట్టి బల్ల లేదా ఫర్నిచర్ కింద తలదాచుకోండి. కిటికీలు మరియు గోడలకు దూరంగా ఉండండి.'
      : 'During an earthquake, drop, cover under sturdy furniture, and hold on. Stay away from glass windows and exterior walls.';
  } else if (lower.includes('cyclone') || message.includes('తుఫాను')) {
    fallbackReply = language === 'te'
      ? 'తుఫాను సమయంలో ఇళ్లలోనే ఉండండి. కిటికీలకు దూరంగా ఉండండి. అధికారిక వాతావరణ సమాచారాన్ని గమనించండి.'
      : 'Stay indoors away from glass windows during a cyclone. Disconnect electrical appliances and monitor official weather bulletins.';
  } else if (lower.includes('fire') || message.includes('అగ్ని') || message.includes('మంటలు')) {
    fallbackReply = language === 'te'
      ? 'అగ్నిప్రమాదంలో పొగ పీల్చకుండా కిందకు వంగి నడవండి. తడి గుడ్డతో ముఖాన్ని కప్పుకుని బయటకు రండి.'
      : 'In a fire, stay low beneath smoke, cover your nose and mouth with a damp cloth, and evacuate immediately to open air.';
  } else {
    fallbackReply = language === 'te'
      ? 'నేను రెస్క్యూAI వాయిస్ అసిస్టెంట్‌ని. మీరు వరద, అగ్నిప్రమాదం, లేదా ఏదైనా అత్యవసర పరిస్థితిని ఎదుర్కొంటున్నారా? నాకు చెప్పండి, నేను వెంటనే రెస్క్యూ టీమ్‌ని అలర్ట్ చేస్తాను.'
      : 'I am your RescueAI Voice Assistant. Are you facing an emergency like a flood, fire, injury, or trapped person? Please tell me your situation and location so I can assist you.';
  }

  return {
    reply: fallbackReply,
    action: 'INFO',
    pendingSos: null,
    language
  };
}

// Dispatch table
const FUNCTION_HANDLERS = {
  geocodesearch: fnGeocodeSearch,
  reversegeocode: fnReverseGeocode,
  getweather: fnGetWeather,
  getnearbyhospitals: fnGetNearbyHospitals,
  getpopulation: fnGetPopulation,
  getdisasternews: fnGetDisasterNews,
  extractimpactfromnews: fnExtractImpactFromNews,
  assesssituation: fnAssessSituation,
  transcribesos: fnTranscribeSos,
  getsosstatus: fnGetSosStatus,
  probeapis: fnProbeApis,
  voiceassistant: fnVoiceAssistant
};

// Route: POST /api/functions/:functionName
router.post('/functions/:functionName', async (req, res) => {
  const fnName = String(req.params.functionName || '').toLowerCase();
  const handler = FUNCTION_HANDLERS[fnName];

  if (!handler) {
    return res.status(404).json({ error: `Function ${req.params.functionName} not found` });
  }

  // Assess situation is strictly for rescue team responders
  if (fnName === 'assesssituation') {
    const isStaff = req.user && (req.user.role === 'admin' || req.user.role === 'rescue_team' || req.user.staff_type === 'rescue_team');
    if (!isStaff) {
      return res.status(403).json({ error: 'Rescue team access required for situation assessment' });
    }
  }

  try {
    const result = await handler(req.body || {});
    return res.json({ data: result });
  } catch (err) {
    console.error(`Function ${fnName} error:`, err);
    return res.status(500).json({ error: err.message || 'Function execution failed' });
  }
});

export default router;
