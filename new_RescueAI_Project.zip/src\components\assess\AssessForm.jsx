import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import LocationPicker from '@/components/assess/LocationPicker';
import { cn } from '@/lib/utils';

const DISASTERS = [
  { value: 'flood', label: 'Flood' },
  { value: 'earthquake', label: 'Earthquake' },
  { value: 'fire', label: 'Fire' },
  { value: 'cyclone', label: 'Cyclone' }
];

const LIVE_KINDS = ['weather', 'hospitals', 'population', 'news'];

const EXPOSURE = { flood: 0.08, earthquake: 0.12, fire: 0.01, cyclone: 0.1 };

const SOURCE_META = {
  live: { label: 'Live API', className: 'bg-steel/10 text-steel ring-steel/20' },
  news: { label: 'From news', className: 'bg-coral/10 text-coral ring-coral/25' },
  estimated: { label: 'Estimated', className: 'bg-sev-medium/15 text-[#8A6410] ring-sev-medium/30' },
  manual: { label: 'Manual', className: 'bg-canvas text-graphite ring-ink/10' }
};

const INITIAL = {
  disaster_type: 'flood',
  location: '',
  lat: null,
  lng: null,
  placeName: '',
  people_affected: '',
  people_injured: '',
  rainfall: '',
  damage_score: 5,
  teams_available: ''
};

function SourceBadge({ source }) {
  const meta = SOURCE_META[source];
  if (!meta) return null;
  return (
    <span
      className={cn(
        'rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ring-1',
        meta.className
      )}
    >
      {meta.label}
    </span>
  );
}

function validate(values) {
  const errors = {};
  const affected = Number(values.people_affected);
  const injured = Number(values.people_injured);
  const rainfall = Number(values.rainfall);
  const teams = Number(values.teams_available);

  if (!values.location.trim()) errors.location = 'Enter the affected location.';

  if (values.people_affected !== '' && (!Number.isInteger(affected) || affected < 0)) {
    errors.people_affected = 'Whole number, 0 or more.';
  }

  if (values.people_injured !== '' && (!Number.isInteger(injured) || injured < 0)) {
    errors.people_injured = 'Whole number, 0 or more.';
  } else if (
    values.people_injured !== '' &&
    values.people_affected !== '' &&
    Number.isInteger(affected) &&
    Number.isInteger(injured) &&
    injured > affected
  ) {
    errors.people_injured = 'Cannot be more than people affected.';
  }

  if (values.rainfall !== '' && (!Number.isFinite(rainfall) || rainfall < 0)) {
    errors.rainfall = 'Enter 0 mm or more.';
  }

  if (!Number.isFinite(values.damage_score) || values.damage_score < 0 || values.damage_score > 10) {
    errors.damage_score = 'Pick a score between 0 and 10.';
  }

  if (values.teams_available === '' || !Number.isInteger(teams) || teams < 0) {
    errors.teams_available = 'Whole number, 0 or more.';
  }

  return errors;
}

function Field({ id, label, error, hint, badge, children }) {
  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <Label htmlFor={id} className="text-sm font-medium text-ink">
          {label}
        </Label>
        {badge ? <SourceBadge source={badge} /> : null}
      </div>
      <div className="mt-1.5">{children}</div>
      {error ? (
        <p id={`${id}-error`} className="mt-1 text-xs font-medium text-sev-critical">
          {error}
        </p>
      ) : hint ? (
        <p className="mt-1 text-xs text-graphite">{hint}</p>
      ) : null}
    </div>
  );
}

export default function AssessForm({ onSubmit, loading, liveData, liveHospitals = [], onLiveQuery }) {
  const [values, setValues] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [sources, setSources] = useState({});
  const manualRef = useRef({ rainfall: false, people_affected: false, people_injured: false });

  const update = (key, value) => {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
    if (['rainfall', 'people_affected', 'people_injured'].includes(key)) {
      manualRef.current[key] = true;
      setSources((current) => ({ ...current, [key]: 'manual' }));
    }
  };

  // Auto-fill editable fields from live data. Fields the user edits by hand are never overwritten.
  useEffect(() => {
    if (!liveData) return;

    const next = {};
    const apply = (key, value, source) => {
      if (manualRef.current[key]) return;
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0) return;
      next[key] = { value: String(Math.round(n * 10) / 10), source };
    };

    if (liveData.weather) apply('rainfall', liveData.weather.rainfall_last_24h, 'live');

    const impactAffected = liveData.impact?.affected;
    const impactInjured = liveData.impact?.injured;

    // Auto-fill casualty / evacuation counts only when explicitly verified and reported in news
    if (Number.isFinite(impactAffected) && impactAffected > 0) {
      apply('people_affected', impactAffected, 'news');
    }
    if (Number.isFinite(impactInjured) && impactInjured > 0) {
      apply('people_injured', impactInjured, 'news');
    }

    if (Object.keys(next).length === 0) return;

    setValues((current) => {
      const merged = { ...current };
      Object.entries(next).forEach(([key, entry]) => {
        merged[key] = entry.value;
      });
      return merged;
    });
    setSources((current) => {
      const merged = { ...current };
      Object.entries(next).forEach(([key, entry]) => {
        merged[key] = entry.source;
      });
      return merged;
    });
  }, [liveData]);

  const handlePick = (place) => {
    if (!place || !Number.isFinite(place.lat) || !Number.isFinite(place.lng)) {
      setValues((current) => ({ ...current, location: place?.name || '' }));
      return;
    }
    manualRef.current = { rainfall: false, people_affected: false, people_injured: false };
    setSources({});
    setValues((current) => ({
      ...current,
      location: place.name,
      lat: place.lat,
      lng: place.lng,
      placeName: place.placeName || place.name
    }));
    setErrors((current) => ({ ...current, location: undefined }));
    onLiveQuery?.(
      {
        lat: place.lat,
        lng: place.lng,
        placeName: place.placeName || place.name,
        disaster_type: values.disaster_type
      },
      LIVE_KINDS
    );
  };

  const changeDisaster = (value) => {
    update('disaster_type', value);
    if (Number.isFinite(values.lat) && Number.isFinite(values.lng)) {
      onLiveQuery?.(
        { lat: values.lat, lng: values.lng, placeName: values.placeName, disaster_type: value },
        ['news']
      );
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (loading) return;
    const nextErrors = validate(values);
    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }
    onSubmit({
      disaster_type: values.disaster_type,
      location: values.location.trim(),
      lat: values.lat,
      lng: values.lng,
      placeName: values.placeName,
      people_affected: values.people_affected === '' ? null : Number(values.people_affected),
      people_injured: values.people_injured === '' ? null : Number(values.people_injured),
      rainfall: values.rainfall === '' ? null : Number(values.rainfall),
      damage_score: Number(values.damage_score),
      teams_available: Number(values.teams_available),
      affected_source:
        sources.people_affected === 'news' || sources.people_affected === 'estimated'
          ? sources.people_affected
          : 'manual',
      injured_source:
        sources.people_injured === 'news' || sources.people_injured === 'estimated'
          ? sources.people_injured
          : 'manual'
    });
  };

  const invalid = (key) => (errors[key] ? `${key}-error` : undefined);

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5 sm:p-7"
    >
      <div className="mb-5">
        <h2 className="font-heading text-xl text-ink sm:text-2xl">Disaster details</h2>
        <p className="mt-1 text-sm text-graphite">
          Give the inputs you have. Live data fills the rest — everything stays editable.
        </p>
      </div>

      <fieldset className="space-y-4">
        <legend className="mb-1 text-sm font-medium text-ink">Disaster type</legend>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {DISASTERS.map((disaster) => {
            const active = values.disaster_type === disaster.value;
            return (
              <button
                key={disaster.value}
                type="button"
                aria-pressed={active}
                onClick={() => changeDisaster(disaster.value)}
                className={cn(
                  'rounded-xl border px-3 py-2.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral/50',
                  active
                    ? 'border-coral bg-coral/10 text-coral shadow-sm'
                    : 'border-ink/10 bg-white text-steel hover:border-steel/40'
                )}
              >
                {disaster.label}
              </button>
            );
          })}
        </div>

        <Field
          id="location"
          label="Location"
          error={errors.location}
          hint="Search, use your current location, or drag the map pin"
        >
          <LocationPicker
            value={values.location}
            onChange={handlePick}
            hospitals={liveHospitals}
            error={Boolean(errors.location)}
          />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field
            id="people_affected"
            label="People affected"
            error={errors.people_affected}
            badge={values.people_affected !== '' ? sources.people_affected : null}
            hint="Auto-filled if reported in live news, or enter from field report"
          >
            <Input
              id="people_affected"
              type="number"
              inputMode="numeric"
              min={0}
              value={values.people_affected}
              onChange={(event) => update('people_affected', event.target.value)}
              placeholder="0"
              aria-invalid={Boolean(errors.people_affected)}
              aria-describedby={invalid('people_affected')}
              className={cn('h-11 rounded-xl', errors.people_affected && 'border-sev-critical')}
            />
          </Field>

          <Field
            id="people_injured"
            label="People injured"
            error={errors.people_injured}
            badge={values.people_injured !== '' ? sources.people_injured : null}
            hint="Auto-filled if reported in live news, or enter from field report"
          >
            <Input
              id="people_injured"
              type="number"
              inputMode="numeric"
              min={0}
              value={values.people_injured}
              onChange={(event) => update('people_injured', event.target.value)}
              placeholder="0"
              aria-invalid={Boolean(errors.people_injured)}
              aria-describedby={invalid('people_injured')}
              className={cn('h-11 rounded-xl', errors.people_injured && 'border-sev-critical')}
            />
          </Field>

          <Field
            id="rainfall"
            label="Rainfall (mm)"
            error={errors.rainfall}
            badge={values.rainfall !== '' ? sources.rainfall : null}
            hint="Last 24 hours — auto-filled from live weather"
          >
            <Input
              id="rainfall"
              type="number"
              inputMode="decimal"
              min={0}
              value={values.rainfall}
              onChange={(event) => update('rainfall', event.target.value)}
              placeholder="0"
              aria-invalid={Boolean(errors.rainfall)}
              aria-describedby={invalid('rainfall')}
              className={cn('h-11 rounded-xl', errors.rainfall && 'border-sev-critical')}
            />
          </Field>

          <Field id="teams_available" label="Rescue teams available" error={errors.teams_available}>
            <Input
              id="teams_available"
              type="number"
              inputMode="numeric"
              min={0}
              value={values.teams_available}
              onChange={(event) => update('teams_available', event.target.value)}
              placeholder="0"
              aria-invalid={Boolean(errors.teams_available)}
              aria-describedby={invalid('teams_available')}
              className={cn('h-11 rounded-xl', errors.teams_available && 'border-sev-critical')}
            />
          </Field>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <Label htmlFor="damage_score" className="text-sm font-medium text-ink">
              Damage score
            </Label>
            <span className="rounded-full bg-canvas px-2.5 py-0.5 font-mono text-sm text-steel">
              {values.damage_score}/10
            </span>
          </div>
          <div className="mt-3 px-1">
            <Slider
              id="damage_score"
              value={[values.damage_score]}
              onValueChange={(next) => update('damage_score', next[0])}
              min={0}
              max={10}
              step={1}
              aria-label="Damage score from 0 to 10"
            />
          </div>
          <p className="mt-2 flex justify-between text-[11px] uppercase tracking-wider text-graphite/80">
            <span>0 no damage</span>
            <span>10 destroyed</span>
          </p>
        </div>
      </fieldset>

      <Button
        type="submit"
        disabled={loading}
        className="mt-6 h-12 w-full rounded-xl bg-coral text-base font-semibold text-white shadow-sm transition-colors hover:bg-[#D9614A] disabled:opacity-70"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
            Analysing…
          </>
        ) : (
          'Analyse & plan rescue'
        )}
      </Button>
    </form>
  );
}
