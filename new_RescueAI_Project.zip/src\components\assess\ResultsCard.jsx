import {
  AlertCircle,
  CloudRain,
  HeartPulse,
  Home as HomeIcon,
  Sparkles,
  Users,
  Bot,
  ListChecks,
  Download,
  FileText
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import ProbabilityBars from '@/components/assess/ProbabilityBars';
import GuidelineList from '@/components/assess/GuidelineList';
import PlanTimeline from '@/components/assess/PlanTimeline';
import { generatePlanPdf, generatePlanText } from '@/utils/exportPlan';
import { SEVERITY_META, DISASTER_LABELS } from '@/lib/severity';
import { cn } from '@/lib/utils';

const cardClass = 'rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5 sm:p-7';

function EmptyState() {
  return (
    <div className={cn(cardClass, 'flex min-h-[420px] flex-col items-center justify-center text-center')}>
      <span className="grid h-14 w-14 place-items-center rounded-2xl bg-canvas text-steel">
        <Sparkles className="h-6 w-6" aria-hidden="true" />
      </span>
      <h2 className="mt-4 font-heading text-xl text-ink">No assessment yet</h2>
      <p className="mt-2 max-w-xs text-sm leading-relaxed text-graphite">
        Fill in the disaster details and run an analysis to see the predicted severity, deployable
        resources and priority actions here.
      </p>
    </div>
  );
}

function LoadingState() {
  return (
    <div className={cardClass} aria-busy="true" aria-live="polite">
      <p className="sr-only">Analysing the situation…</p>
      <Skeleton className="h-3 w-28" />
      <Skeleton className="mt-3 h-9 w-40 rounded-full" />
      <Skeleton className="mt-5 h-4 w-full" />
      <Skeleton className="mt-2 h-4 w-5/6" />
      <div className="mt-6 grid grid-cols-3 gap-3">
        <Skeleton className="h-20 rounded-xl" />
        <Skeleton className="h-20 rounded-xl" />
        <Skeleton className="h-20 rounded-xl" />
      </div>
      <div className="mt-6 space-y-3">
        <Skeleton className="h-2.5 w-full rounded-full" />
        <Skeleton className="h-2.5 w-full rounded-full" />
        <Skeleton className="h-2.5 w-full rounded-full" />
        <Skeleton className="h-2.5 w-full rounded-full" />
      </div>
      <Skeleton className="mt-6 h-28 w-full rounded-xl" />
    </div>
  );
}

export default function ResultsCard({ result, loading, error, doneActions, onToggleAction }) {
  if (loading) return <LoadingState />;
  if (!result) {
    return (
      <div className={cn(cardClass, 'min-h-[420px]')}>
        {error ? (
          <div className="mb-4 flex items-start gap-3 rounded-xl bg-sev-critical/5 p-4 ring-1 ring-sev-critical/20">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-sev-critical" aria-hidden="true" />
            <p className="text-sm text-sev-critical" role="alert">
              {error}
            </p>
          </div>
        ) : null}
        <EmptyState />
      </div>
    );
  }

  const meta = SEVERITY_META[result.severity] || SEVERITY_META.low;
  const resources = result.resources || {};
  const tiles = [
    { label: 'Teams to deploy', value: resources.teams_to_deploy ?? 0, icon: Users },
    { label: 'Medical units', value: resources.medical_units ?? 0, icon: HeartPulse },
    { label: 'Shelter places', value: resources.shelter_capacity ?? 0, icon: HomeIcon }
  ];

  return (
    <div className={cn(cardClass, 'animate-in fade-in duration-300')}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
            Predicted severity
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <span
              className={cn(
                'inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-lg font-semibold ring-1',
                meta.chip
              )}
            >
              <span className={cn('h-2.5 w-2.5 rounded-full', meta.dot)} aria-hidden="true" />
              {meta.label}
            </span>
            <span className="text-sm text-graphite">
              risk score <span className="font-mono text-ink">{result.score}</span>
            </span>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-navy/5 px-3 py-1 text-xs font-medium text-navy">
          {result.plan_source === 'ai' ? (
            <Bot className="h-3.5 w-3.5" aria-hidden="true" />
          ) : (
            <ListChecks className="h-3.5 w-3.5" aria-hidden="true" />
          )}
          {result.plan_source === 'ai' ? 'Plan by AI' : 'Rule-based plan'}
        </span>
      </div>

      <p className="mt-4 text-sm leading-relaxed text-ink/80">{result.summary}</p>
      <p className="mt-1 text-xs text-graphite">
        {DISASTER_LABELS[result.input?.disaster_type] || result.input?.disaster_type} ·{' '}
        {result.input?.location}
      </p>

      <div className="mt-6">
        <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
          Severity distribution
        </h3>
        <ProbabilityBars probabilities={result.probabilities} />
      </div>

      <div className="mt-6 grid grid-cols-3 gap-2 sm:gap-3">
        {tiles.map((tile) => (
          <div key={tile.label} className="rounded-xl bg-canvas p-3 text-center ring-1 ring-ink/5">
            <tile.icon className="mx-auto h-4 w-4 text-steel" aria-hidden="true" />
            <p className="mt-1.5 font-heading text-2xl text-ink">{tile.value}</p>
            <p className="mt-0.5 text-[11px] leading-tight text-graphite">{tile.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-ink/5 pb-2">
          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
              Rescue plan
            </h3>
            <p className="text-xs text-graphite">Actionable tactical response protocol</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => generatePlanPdf(result)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-navy px-3 py-1.5 text-xs font-semibold text-white shadow-xs transition hover:bg-navy/90 active:scale-95"
              title="Download official PDF Incident Action Plan"
            >
              <Download className="h-3.5 w-3.5 text-coral" />
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={() => generatePlanText(result)}
              className="inline-flex items-center gap-1 rounded-lg border border-ink/15 bg-white px-2.5 py-1.5 text-xs font-medium text-steel shadow-2xs transition hover:bg-canvas active:scale-95"
              title="Download plain text dispatch briefing"
            >
              <FileText className="h-3.5 w-3.5 text-steel" />
              <span>TXT</span>
            </button>
          </div>
        </div>
        <PlanTimeline
          plan={result.plan}
          doneActions={doneActions}
          onToggle={onToggleAction}
        />
      </div>

      <div className="mt-6 flex items-start gap-3 rounded-xl bg-steel/5 p-4 ring-1 ring-steel/10">
        <CloudRain className="mt-0.5 h-4 w-4 shrink-0 text-steel" aria-hidden="true" />
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-steel">
            Weather analysis
          </p>
          <p className="mt-1 text-sm leading-relaxed text-ink/80">{result.weather_note}</p>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
          Retrieved emergency guidelines
        </h3>
        <GuidelineList items={result.guidelines || []} />
      </div>
    </div>
  );
}
