import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

export default async function (req) {
  try {
    const body = await req.json().catch(() => ({}));
    const raw = typeof body?.reference_id === 'string' ? body.reference_id.trim().toUpperCase() : '';
    if (!/^[A-Z0-9]{8}$/.test(raw)) {
      return Response.json({ error: 'Enter a valid 8 character reference.' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const page = await base44.asServiceRole.entities.SOSRequest.filter({ reference_id: raw }, { limit: 1 });
    const record = (page?.items || [])[0];
    if (!record) {
      return Response.json({ error: 'not_found' }, { status: 404 });
    }

    return Response.json({
      reference_id: record.reference_id,
      status: record.status,
      priority: record.priority,
      created_date: record.created_date
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
