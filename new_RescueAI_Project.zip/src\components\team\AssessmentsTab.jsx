import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Download, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Skeleton } from '@/components/ui/skeleton';
import { generatePlanPdf } from '@/utils/exportPlan';
import { DISASTER_LABELS, SEVERITY_META } from '@/lib/severity';
import { cn } from '@/lib/utils';

export default function AssessmentsTab() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;

    const load = async () => {
      try {
        const page = await base44.entities.Assessment.filter({}, { sort: '-created_date', limit: 50 });
        if (active) setItems(page?.items || []);
      } catch (err) {
        if (active) setError(err?.message || 'Could not load assessments.');
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((index) => (
          <Skeleton key={index} className="h-24 w-full rounded-[16px]" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <p className="rounded-[16px] bg-white p-6 text-sm text-sev-critical ring-1 ring-black/5" role="alert">
        {error}
      </p>
    );
  }

  if (!items.length) {
    return (
      <p className="rounded-[16px] bg-white p-8 text-center text-sm text-graphite ring-1 ring-black/5">
        No assessments yet. Run an analysis from the Assess page and it will appear here.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const meta = SEVERITY_META[item.severity] || SEVERITY_META.low;
        return (
          <article
            key={item.id}
            className="rounded-[16px] bg-white p-4 shadow-soft ring-1 ring-black/5 sm:p-5"
          >
            <div className="flex flex-wrap items-center gap-2">
              <span className={cn('rounded-full px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider ring-1', meta.chip)}>
                {meta.label}
              </span>
              <span className="text-xs font-medium text-steel">
                {DISASTER_LABELS[item.disaster_type] || item.disaster_type}
              </span>
              <span className="ml-auto text-[11px] text-graphite">
                {item.created_date ? format(new Date(item.created_date), 'dd MMM yyyy, HH:mm') : ''}
              </span>
            </div>

            <h3 className="mt-2 flex items-start gap-1.5 font-heading text-base text-ink">
              <MapPin className="mt-1 h-3.5 w-3.5 shrink-0 text-steel" aria-hidden="true" />
              {item.location}
            </h3>

            <p className="mt-1 text-xs text-graphite">
              {item.people_affected ?? 0} affected · {item.people_injured ?? 0} injured · damage{' '}
              {item.damage_score ?? 0}/10 · risk score {item.score ?? 0}
            </p>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div className="flex flex-wrap gap-2">
                <span className="rounded-md bg-canvas px-2 py-1 text-steel">
                  {item.teams_to_deploy ?? 0} teams
                </span>
                <span className="rounded-md bg-canvas px-2 py-1 text-steel">
                  {item.medical_units ?? 0} medical units
                </span>
                <span className="rounded-md bg-canvas px-2 py-1 text-steel">
                  {item.shelter_places ?? 0} shelter places
                </span>
                <span className="rounded-md bg-canvas px-2 py-1 text-steel">
                  {item.plan_source === 'ai' ? 'Plan by AI' : 'Rule-based plan'}
                </span>
              </div>
              {item.plan && (
                <button
                  type="button"
                  onClick={() =>
                    generatePlanPdf({
                      ...item,
                      input: {
                        disaster_type: item.disaster_type,
                        location: item.location,
                        lat: item.lat,
                        lng: item.lng
                      }
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-lg bg-navy/5 px-2.5 py-1 font-semibold text-navy transition hover:bg-navy/10 active:scale-95"
                  title="Download Incident Action Plan PDF"
                >
                  <Download className="h-3 w-3 text-coral" />
                  <span>Download Plan</span>
                </button>
              )}
            </div>
          </article>
        );
      })}
    </div>
  );
}
