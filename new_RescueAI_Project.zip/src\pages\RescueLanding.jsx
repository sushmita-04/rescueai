import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Shield,
  Radio,
  MapPin,
  Clock,
  Users,
  Sparkles,
  PhoneCall,
  Play,
  Zap,
  ShieldCheck,
  Ambulance,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import EmergencyCity3D from '@/components/landing/EmergencyCity3D';
import '@/styles/editorialLanding.css';

/**
 * RescueLanding:
 * Updated RescueAI Landing Page UI matching reference design.
 *
 * Requirements Met:
 * - Background: Soft blush pink and warm white with subtle pink gradients and gentle shadows.
 * - Navigation: RescueAI logo on left, Features/How It Works/Rescue Teams in center, dark navy pill Login button on right.
 * - Hero layout: Two columns on desktop (Text on left, 3D emergency city map on right). Stacks vertically on mobile.
 * - Headline: "One tap in." (dark charcoal navy serif) / "Help on the way." (italic coral pink serif).
 * - Description: Muted blue-gray text.
 * - Buttons:
 *     1. Dark navy pill button with subtle coral glow, SOS icon, "Send SOS" text, and arrow icon.
 *     2. White/transparent secondary button with thin pale-pink border, play icon, and "See how it works" text.
 * - Trust indicators: Fast Response, Trusted Teams, Live Tracking with small coral icons and pale-pink circular backgrounds.
 * - 3D Illustration: Miniature isometric city with white/pale-pink buildings, curved roads, green trees,
 *   glossy coral SOS pin, glowing coral route, white ambulance, and hospital with helipad.
 * - Floating status card: "Rescue Team Arriving" • "ETA 2 mins".
 * - Bottom wave: Subtle flowing pale-pink wave along the bottom of the hero section.
 * - Preserves all existing functionality, links, routes, authentication, and lower sections.
 */
export default function RescueLanding() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e, sectionId) => {
    e.preventDefault();
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="editorial-landing-root">
      {/* Subtle Blurred Pastel Color Blobs */}
      <div className="editorial-blob editorial-blob-1" aria-hidden="true" />
      <div className="editorial-blob editorial-blob-2" aria-hidden="true" />
      <div className="editorial-blob editorial-blob-3" aria-hidden="true" />

      <div className="editorial-content-shell">
        {/* 1. NAVBAR (Sticky, transparent with blur on scroll) */}
        <header className={`editorial-navbar ${isScrolled ? 'scrolled' : ''}`}>
          <div className="editorial-navbar-inner">
            {/* Logo */}
            <Link to="/" className="editorial-brand" aria-label="RescueAI Home">
              <div className="editorial-brand-badge">
                <Shield className="h-4 w-4" />
              </div>
              <span className="editorial-brand-text">RescueAI</span>
            </Link>

            {/* Center Navigation Links (Smooth scroll) */}
            <nav className="editorial-nav-center" aria-label="Landing Navigation">
              <a
                href="#features"
                onClick={(e) => scrollToSection(e, 'features')}
                className="editorial-nav-link"
              >
                Features
              </a>
              <a
                href="#how-it-works"
                onClick={(e) => scrollToSection(e, 'how-it-works')}
                className="editorial-nav-link"
              >
                How It Works
              </a>
              <Link to="/team-login" className="editorial-nav-link">
                Rescue Teams
              </Link>
            </nav>

            {/* Right: Dark Navy Pill Login Button */}
            <div className="editorial-nav-right">
              <Link to="/login" className="editorial-signin-btn">
                Login
              </Link>
            </div>
          </div>
        </header>

        {/* 2. TWO-COLUMN HERO SECTION */}
        <section className="editorial-hero-two-col" aria-label="RescueAI Emergency Overview">
          {/* Left Column: Headlines, Text, CTA Buttons & Trust Badges */}
          <div className="editorial-hero-left">
            {/* Headline */}
            <h1 className="editorial-headline-large">
              <span className="editorial-headline-navy">One tap in.</span>
              <span className="editorial-headline-coral-italic">Help on the way.</span>
            </h1>

            {/* Description */}
            <p className="editorial-desc-muted">
              RescueAI connects people in emergencies with the nearest rescue teams in seconds. Send an SOS, share your live location, and track help in real time.
            </p>

            {/* Action Buttons */}
            <div className="editorial-hero-buttons">
              {/* Primary Button */}
              <Link to="/sos" className="editorial-btn-navy-sos" aria-label="Send Emergency SOS">
                <Radio className="h-4 w-4 text-coral animate-pulse" aria-hidden="true" />
                <span>Send SOS</span>
                <ArrowRight className="h-4 w-4 text-white/80" aria-hidden="true" />
              </Link>

              {/* Secondary Button */}
              <a
                href="#how-it-works"
                onClick={(e) => scrollToSection(e, 'how-it-works')}
                className="editorial-btn-pink-outline"
                aria-label="See how RescueAI works"
              >
                <div className="w-5 h-5 rounded-full bg-rose-100 flex items-center justify-center text-rose-500">
                  <Play className="h-2.5 w-2.5 fill-rose-500 ml-0.5" aria-hidden="true" />
                </div>
                <span>See how it works</span>
              </a>
            </div>

            {/* Trust Indicators */}
            <div className="editorial-trust-strip" aria-label="Trust indicators">
              {/* Fast Response */}
              <div className="editorial-trust-item">
                <div className="editorial-trust-icon-wrap">
                  <Zap className="h-3.5 w-3.5" aria-hidden="true" />
                </div>
                <span className="editorial-trust-text">Fast Response</span>
              </div>

              {/* Trusted Teams */}
              <div className="editorial-trust-item">
                <div className="editorial-trust-icon-wrap">
                  <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                </div>
                <span className="editorial-trust-text">Trusted Teams</span>
              </div>

              {/* Live Tracking */}
              <div className="editorial-trust-item">
                <div className="editorial-trust-icon-wrap">
                  <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                </div>
                <span className="editorial-trust-text">Live Tracking</span>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Emergency City Illustration with Floating Status Card */}
          <div className="editorial-hero-right">
            <div className="editorial-3d-scene-wrapper">
              {/* Floating White Status Card */}
              <div className="editorial-status-card" role="status" aria-live="polite">
                <div className="editorial-status-icon-box">
                  <Ambulance className="h-5 w-5 text-coral animate-bounce" aria-hidden="true" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-coral animate-ping" />
                    <span className="text-xs font-bold text-slate-900 tracking-wide">Rescue Team Arriving</span>
                  </div>
                  <p className="text-xs font-bold text-coral mt-0.5">ETA 2 mins</p>
                </div>
              </div>

              {/* 3D Isometric Miniature City Scene */}
              <EmergencyCity3D />
            </div>
          </div>
        </section>

        {/* Subtle Flowing Pale-Pink Wave Divider along the bottom of the hero */}
        <div className="editorial-wave-divider" aria-hidden="true">
          <svg viewBox="0 0 1440 100" fill="none" preserveAspectRatio="none" className="w-full h-12 sm:h-16 lg:h-20">
            <path
              d="M0,32 C240,75 480,12 720,48 C960,84 1200,24 1440,56 L1440,100 L0,100 Z"
              fill="#fff0f2"
              fillOpacity="0.8"
            />
          </svg>
        </div>

        {/* 3. FEATURES SECTION ("Everything a rescue needs") */}
        <section id="features" className="editorial-features" aria-label="Platform Features">
          <div className="editorial-section-header">
            <div className="editorial-section-tag">Capabilities</div>
            <h2 className="editorial-section-title">Everything a rescue needs.</h2>
            <p className="editorial-section-desc">
              Built specifically for crisis speed. Seamless coordination between citizens in distress and verified rescue squads.
            </p>
          </div>

          <div className="editorial-features-grid">
            {/* Card 1: One-tap SOS */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <Radio className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">One-Tap SOS</h3>
              <p className="editorial-card-desc">
                Trigger emergency voice or text dispatch in seconds. Works with live speech-to-text so you can report hands-free.
              </p>
            </div>

            {/* Card 2: Live location sharing */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <MapPin className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">Live Location Sharing</h3>
              <p className="editorial-card-desc">
                High-accuracy GPS coordinates paired with nearby landmarks guide responders straight to your exact position.
              </p>
            </div>

            {/* Card 3: Real-time status tracking */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <Clock className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">Real-Time Status Tracking</h3>
              <p className="editorial-card-desc">
                Stay informed every minute with live status events from dispatched, to en route, to on-scene arrival.
              </p>
            </div>

            {/* Card 4: Rescue team dispatch */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <Users className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">Rescue Team Dispatch</h3>
              <p className="editorial-card-desc">
                Direct integration with verified NDRF, SDRF, and civil defense units authenticated with government credentials.
              </p>
            </div>

            {/* Card 5: AI-assisted guidance */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <Sparkles className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">AI-Assisted Guidance</h3>
              <p className="editorial-card-desc">
                Instant life-saving protocols and first-aid instructions tailored specifically to floods, quakes, fires, or trauma.
              </p>
            </div>

            {/* Card 6: 24/7 availability */}
            <div className="editorial-feature-card">
              <div className="editorial-card-icon">
                <PhoneCall className="h-5 w-5" />
              </div>
              <h3 className="editorial-card-title">24/7 Availability</h3>
              <p className="editorial-card-desc">
                Always accessible on any phone, tablet, or laptop browser without downloading heavy external apps.
              </p>
            </div>
          </div>
        </section>

        {/* 4. HOW IT WORKS (3 Steps) */}
        <section id="how-it-works" className="editorial-how" aria-label="How RescueAI Works">
          <div className="editorial-section-header">
            <div className="editorial-section-tag">Workflow</div>
            <h2 className="editorial-section-title">Help in three clear steps.</h2>
            <p className="editorial-section-desc">
              From the moment trouble strikes to safe extraction, every second is optimized for speed.
            </p>
          </div>

          <div className="editorial-steps-grid">
            {/* Step 1 */}
            <div className="editorial-step-card">
              <div className="editorial-step-number">01</div>
              <h3 className="editorial-step-title">Send SOS</h3>
              <p className="editorial-step-desc">
                Tap the emergency button or speak to the Voice Assistant. State your situation and share your location in one step.
              </p>
            </div>

            {/* Step 2 */}
            <div className="editorial-step-card">
              <div className="editorial-step-number">02</div>
              <h3 className="editorial-step-title">Team Accepts</h3>
              <p className="editorial-step-desc">
                Authorized rescue squads receive high-priority alerts with casualty counts, severity score, and optimal routes.
              </p>
            </div>

            {/* Step 3 */}
            <div className="editorial-step-card">
              <div className="editorial-step-number">03</div>
              <h3 className="editorial-step-title">Track Help Live</h3>
              <p className="editorial-step-desc">
                Follow your assigned team’s progress in real time with continuous safety advice while help makes its way to you.
              </p>
            </div>
          </div>
        </section>

        {/* 5. FINAL CTA BAND */}
        <section className="editorial-cta-band" aria-label="Take Action Now">
          <div className="editorial-cta-box">
            <div className="editorial-cta-blob" aria-hidden="true" />
            <h2 className="editorial-cta-title">
              When every second matters, RescueAI is ready.
            </h2>
            <p className="editorial-cta-desc">
              Whether you need urgent emergency rescue or are coordinating emergency disaster relief, access the platform now.
            </p>
            <div className="editorial-cta-actions">
              <Link to="/sos" className="editorial-btn-coral" aria-label="Send SOS Now">
                <span>Send Emergency SOS</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/login" className="editorial-btn-white" aria-label="Citizen Sign In">
                <span>Sign in to Platform</span>
              </Link>
            </div>
          </div>
        </section>

        {/* 6. SIMPLE FOOTER */}
        <footer className="editorial-footer">
          <div className="editorial-footer-inner">
            <div className="flex items-center gap-2">
              <div className="editorial-brand-badge w-6 h-6">
                <Shield className="h-3.5 w-3.5" />
              </div>
              <span className="font-bold text-sm text-ink">RescueAI Emergency Systems</span>
            </div>

            <div className="editorial-footer-links">
              <Link to="/sos" className="editorial-footer-link">
                Emergency SOS
              </Link>
              <Link to="/team-login" className="editorial-footer-link">
                Rescue Team Portal
              </Link>
              <Link to="/login" className="editorial-footer-link">
                Citizen Login
              </Link>
              <Link to="/" className="editorial-footer-link">
                Disaster Assessment
              </Link>
            </div>

            <p className="editorial-footer-copy">
              &copy; {new Date().getFullYear()} RescueAI. Built for rapid emergency life preservation.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
