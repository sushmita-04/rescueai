import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Edit3,
  HelpCircle,
  Mic,
  Radio,
  RotateCcw,
  Sparkles,
  Square,
  Volume2,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { calculateSeverityFromText, formatDuration, getSeverityDetails } from '@/lib/sos';
import { PRIORITY_META } from '@/lib/severity';

const MAX_SECONDS = 120;

const QUICK_PRESETS = [
  {
    label: '🚨 Trapped & Water Rising',
    text: 'We are trapped inside our home and flood water is rising fast. Need immediate rescue now!',
    severity: 'emergency'
  },
  {
    label: '🚨 Fire / Collapse',
    text: 'Building collapse with fire and smoke. People trapped under rubble, cannot breathe!',
    severity: 'emergency'
  },
  {
    label: '⚠️ Injured & Broken Bone',
    text: 'Family member injured with a broken leg and severe bleeding. Need ambulance and medical help.',
    severity: 'medium'
  },
  {
    label: '⚠️ Stranded on Roof',
    text: 'Stranded on the roof with 4 people including children. Food and clean drinking water finished.',
    severity: 'medium'
  },
  {
    label: 'ℹ️ Sheltered / Safe',
    text: 'We are sheltered safely on higher ground. Waiting for evacuation boat and updates.',
    severity: 'low'
  }
];

export default function VoiceRecorder({ onChange }) {
  const [phase, setPhase] = useState('idle');
  const [seconds, setSeconds] = useState(0);
  const [error, setError] = useState('');
  const [speechStatus, setSpeechStatus] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [transcript, setTranscript] = useState('');
  const [liveInterim, setLiveInterim] = useState('');
  const [isSpeechActive, setIsSpeechActive] = useState(false);
  const [isSpeechSupported, setIsSpeechSupported] = useState(true);
  const [speechLang, setSpeechLang] = useState(() => {
    if (typeof navigator !== 'undefined') {
      const navLang = navigator.language || navigator.userLanguage || 'en-IN';
      if (navLang.startsWith('te')) return 'te-IN';
      if (navLang.startsWith('en')) return 'en-IN';
      if (navLang.startsWith('hi')) return 'hi-IN';
      return navLang;
    }
    return 'en-IN';
  });

  const mediaRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const restartTimerRef = useRef(null);
  const rafRef = useRef(null);
  const canvasRef = useRef(null);
  const secondsRef = useRef(0);
  const previewRef = useRef('');
  const recognitionRef = useRef(null);
  const transcriptRef = useRef('');
  const committedPrefixRef = useRef('');
  const sessionFinalRef = useRef('');
  const isSpeechActiveRef = useRef(false);
  const isRecordingRef = useRef(false);
  const recordedBlobRef = useRef(null);

  const teardown = () => {
    isRecordingRef.current = false;
    isSpeechActiveRef.current = false;
    setIsSpeechActive(false);

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {}
      recognitionRef.current = null;
    }
  };

  useEffect(() => {
    const SpeechRecognition = typeof window !== 'undefined'
      ? (window.SpeechRecognition || window.webkitSpeechRecognition)
      : null;
    if (!SpeechRecognition) {
      setIsSpeechSupported(false);
      setSpeechStatus('Speech-to-text not natively supported by this browser. You can type or use quick presets below.');
    }

    return () => {
      teardown();
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    };
  }, []);

  // Smooth procedural waveform animation (doesn't lock the microphone hardware)
  const drawWaveform = () => {
    let frame = 0;
    const step = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const bars = 36;
      const barWidth = width / bars;
      ctx.fillStyle = '#E76F51';

      frame += 0.09;
      for (let i = 0; i < bars; i += 1) {
        const wave1 = Math.sin(frame + i * 0.38);
        const wave2 = Math.cos(frame * 0.72 + i * 0.22);
        const value = Math.max(0.12, (wave1 * 0.5 + wave2 * 0.5 + 1) / 2);
        const barHeight = Math.max(4, value * (height * 0.85));
        const x = i * barWidth + barWidth * 0.22;
        const w = barWidth * 0.56;
        const y = (height - barHeight) / 2;
        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') ctx.roundRect(x, y, w, barHeight, w / 2);
        else ctx.rect(x, y, w, barHeight);
        ctx.fill();
      }

      if (isRecordingRef.current || isSpeechActiveRef.current) {
        rafRef.current = requestAnimationFrame(step);
      } else {
        ctx.clearRect(0, 0, width, height);
      }
    };

    step();
  };

  // Helper to start SpeechRecognition cleanly with auto-restart on pauses
  const startSpeechEngine = (targetLang) => {
    const SpeechRecognition = typeof window !== 'undefined'
      ? (window.SpeechRecognition || window.webkitSpeechRecognition)
      : null;

    if (!SpeechRecognition) return null;

    const lang = targetLang || speechLang || 'en-IN';

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.lang = lang;

      recognition.onstart = () => {
        setIsSpeechActive(true);
        isSpeechActiveRef.current = true;
        setSpeechStatus('Listening to your voice... Speak your emergency clearly.');
      };

      recognition.onspeechstart = () => {
        setSpeechStatus('🎙️ Hearing speech... Converting to text live!');
      };

      recognition.onresult = (event) => {
        let interim = '';
        let final = '';

        for (let i = 0; i < event.results.length; i += 1) {
          const res = event.results[i];
          if (res.isFinal) {
            final += res[0].transcript + ' ';
          } else {
            interim += res[0].transcript;
          }
        }

        sessionFinalRef.current = final.trim();
        setLiveInterim(interim.trim());

        // Full transcript is committed previous sessions + current session final + current interim
        const full = [committedPrefixRef.current, sessionFinalRef.current, interim.trim()]
          .filter(Boolean)
          .join(' ')
          .trim();

        if (full) {
          setTranscript(full);
          transcriptRef.current = full;
          setSpeechStatus('🟢 Voice converted to text live!');

          onChange?.({
            blob: recordedBlobRef.current,
            url: previewRef.current,
            seconds: secondsRef.current,
            mimeType: recordedBlobRef.current?.type || 'audio/webm',
            transcript: full
          });
        }
      };

      recognition.onerror = (e) => {
        console.warn('SpeechRecognition notice:', e?.error);
        if (e.error === 'no-speech') {
          return;
        }
        if (e.error === 'audio-capture') {
          setSpeechStatus('Microphone device busy. You can speak into Voice Assistant or type below.');
        } else if (e.error === 'not-allowed') {
          setSpeechStatus('Microphone permission blocked. Please allow mic in browser settings.');
        } else if (e.error === 'network') {
          setSpeechStatus('Live speech network busy. Tap presets below or speak into Voice Assistant.');
        } else {
          setSpeechStatus(`Speech status: ${e.error}`);
        }
      };

      recognition.onend = () => {
        if (sessionFinalRef.current) {
          committedPrefixRef.current = [committedPrefixRef.current, sessionFinalRef.current]
            .filter(Boolean)
            .join(' ')
            .trim();
          sessionFinalRef.current = '';
        }
        setLiveInterim('');

        if (isRecordingRef.current || isSpeechActiveRef.current) {
          clearTimeout(restartTimerRef.current);
          restartTimerRef.current = setTimeout(() => {
            if (isRecordingRef.current || isSpeechActiveRef.current) {
              startSpeechEngine(lang);
            }
          }, 150);
        } else {
          setIsSpeechActive(false);
          isSpeechActiveRef.current = false;
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
      return recognition;
    } catch (err) {
      console.warn('Could not start SpeechRecognition:', err);
      return null;
    }
  };

  const stopSpeechEngine = () => {
    isSpeechActiveRef.current = false;
    setIsSpeechActive(false);
    clearTimeout(restartTimerRef.current);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
  };

  const stopRecording = () => {
    isRecordingRef.current = false;
    stopSpeechEngine();

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    const recorder = mediaRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try {
        recorder.stop();
      } catch (stopError) {
        // recorder already stopped
      }
    }
  };

  const startRecording = async () => {
    setError('');
    setSpeechStatus('');
    isRecordingRef.current = true;
    isSpeechActiveRef.current = true;

    // Start live speech-to-text and procedural waveform
    startSpeechEngine(speechLang);
    drawWaveform();

    if (!navigator.mediaDevices?.getUserMedia || typeof window.MediaRecorder === 'undefined') {
      setPhase('recording');
      timerRef.current = setInterval(() => {
        secondsRef.current += 1;
        setSeconds(secondsRef.current);
        if (secondsRef.current >= MAX_SECONDS) stopRecording();
      }, 1000);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
      const mimeType = candidates.find((type) => {
        try {
          return MediaRecorder.isTypeSupported(type);
        } catch {
          return false;
        }
      });

      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) chunksRef.current.push(event.data);
      };

      recorder.onstop = async () => {
        isRecordingRef.current = false;
        const duration = secondsRef.current;
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        recordedBlobRef.current = blob;
        teardown();
        mediaRef.current = null;

        if (duration < 1 || blob.size === 0) {
          secondsRef.current = 0;
          setSeconds(0);
          setPhase('idle');
          setError('Recording was too short. Speak a little longer so the rescue team can hear you.');
          onChange?.({
            blob: null,
            url: '',
            seconds: 0,
            mimeType: '',
            transcript: transcriptRef.current
          });
          return;
        }

        const url = URL.createObjectURL(blob);
        if (previewRef.current) URL.revokeObjectURL(previewRef.current);
        previewRef.current = url;
        setPreviewUrl(url);
        setPhase('recorded');

        onChange?.({
          blob,
          url,
          seconds: duration,
          mimeType: blob.type,
          transcript: transcriptRef.current
        });

        // AI audio transcription fallback if speech-to-text was empty
        if (!transcriptRef.current.trim() && blob.size > 0) {
          try {
            setSpeechStatus('Transcribing recorded audio with AI...');
            const formData = new FormData();
            formData.append('file', blob, 'sos-audio.webm');
            const transRes = await fetch('/api/audio/transcribe', {
              method: 'POST',
              body: formData
            });
            if (transRes.ok) {
              const transData = await transRes.json();
              if (transData.transcript) {
                handleTranscriptChange(transData.transcript);
                setSpeechStatus('🟢 Audio transcribed successfully with AI!');
              }
            }
          } catch (e) {
            console.warn('Fallback transcription failed:', e);
          }
        }
      };

      mediaRef.current = recorder;
      secondsRef.current = 0;
      setSeconds(0);
      setPhase('recording');
      recorder.start();

      timerRef.current = setInterval(() => {
        secondsRef.current += 1;
        setSeconds(secondsRef.current);
        if (secondsRef.current >= MAX_SECONDS) stopRecording();
      }, 1000);
    } catch (err) {
      console.warn('Microphone error in MediaRecorder:', err);
      if (err?.name === 'NotAllowedError' || err?.name === 'SecurityError') {
        setError('Microphone access was blocked. Allow microphone access in your browser or type your SOS message below.');
      } else {
        setError('Could not connect to microphone. You can type your message or click presets below.');
      }
      setPhase('idle');
    }
  };

  // Direct speech-to-text toggle (instant voice-to-text on screen)
  const toggleSpeechOnly = () => {
    if (isSpeechActive) {
      stopSpeechEngine();
      setSpeechStatus('Voice-to-text listening paused.');
    } else {
      setError('');
      isSpeechActiveRef.current = true;
      setIsSpeechActive(true);
      setSpeechStatus('🎙️ Listening to your voice... Speak now!');
      drawWaveform();
      startSpeechEngine(speechLang);
    }
  };

  const handleLanguageSwitch = (newLang) => {
    setSpeechLang(newLang);
    if (isSpeechActiveRef.current || isRecordingRef.current) {
      startSpeechEngine(newLang);
    }
  };

  const handleTranscriptChange = (newVal) => {
    setTranscript(newVal);
    transcriptRef.current = newVal;
    committedPrefixRef.current = newVal;
    sessionFinalRef.current = '';
    onChange?.({
      blob: recordedBlobRef.current,
      url: previewRef.current,
      seconds: secondsRef.current,
      mimeType: recordedBlobRef.current?.type || 'audio/webm',
      transcript: newVal
    });
  };

  const applyPreset = (preset) => {
    handleTranscriptChange(preset.text);
    setSpeechStatus(`Applied preset: ${preset.label}`);
  };

  const reset = () => {
    isRecordingRef.current = false;
    isSpeechActiveRef.current = false;
    committedPrefixRef.current = '';
    sessionFinalRef.current = '';
    teardown();
    mediaRef.current = null;
    chunksRef.current = [];
    recordedBlobRef.current = null;
    secondsRef.current = 0;
    setSeconds(0);
    setError('');
    setSpeechStatus('');
    setTranscript('');
    setLiveInterim('');
    transcriptRef.current = '';
    setPhase('idle');
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = '';
    }
    setPreviewUrl('');
    onChange?.(null);
  };

  const recording = phase === 'recording';
  const recorded = phase === 'recorded';

  const severityDetails = getSeverityDetails(transcript);
  const calculatedSeverity = severityDetails.severity;
  const severityMeta = PRIORITY_META[calculatedSeverity] || PRIORITY_META.normal;

  return (
    <div>
      <div className="flex flex-col items-center">
        <div className="relative">
          {recording ? (
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-[#C1121F]/40" aria-hidden="true" />
          ) : null}
          <button
            type="button"
            onClick={recording ? stopRecording : recorded ? reset : startRecording}
            aria-label={recording ? 'Stop recording' : recorded ? 'Start a new recording' : 'Start speaking'}
            className={cn(
              'relative grid h-28 w-28 place-items-center rounded-full text-white shadow-lift transition-colors focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-coral/30 sm:h-32 sm:w-32',
              recording ? 'bg-[#C1121F]' : 'bg-coral hover:bg-[#D9614A]'
            )}
          >
            {recording ? (
              <Square className="h-9 w-9" fill="currentColor" aria-hidden="true" />
            ) : (
              <Mic className="h-10 w-10" aria-hidden="true" />
            )}
          </button>
        </div>

        <p className="mt-4 font-mono text-xl tabular-nums text-ink" aria-live="polite">
          {formatDuration(seconds)}
        </p>

        {recording ? (
          <div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#C1121F] animate-pulse">
            <Radio className="h-3.5 w-3.5" />
            <span>Recording & listening... Speak your emergency now</span>
          </div>
        ) : recorded ? (
          <p className="mt-1 text-xs text-graphite">
            Voice recorded · Review and edit transcribed text below
          </p>
        ) : (
          <p className="mt-1 text-xs text-graphite">
            Tap mic to speak — converts voice to text on the screen
          </p>
        )}

        <canvas
          ref={canvasRef}
          width={640}
          height={80}
          className="mt-4 h-16 w-full max-w-sm rounded-xl bg-canvas"
          aria-hidden="true"
        />

        {/* Alternate direct voice button */}
        {!recording && (
          <div className="mt-2 flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={toggleSpeechOnly}
              className={cn(
                'h-8 text-xs rounded-full border-steel/20',
                isSpeechActive ? 'border-coral bg-coral/10 text-coral font-semibold animate-pulse' : 'text-steel'
              )}
            >
              <Mic className="mr-1.5 h-3.5 w-3.5" />
              {isSpeechActive ? 'Listening... (Tap to stop)' : 'Speech-to-Text Only'}
            </Button>
          </div>
        )}
      </div>

      {/* Voice Assistant Speech-to-Text Interactive Screen */}
      <div className="mt-5 rounded-2xl border border-steel/20 bg-canvas/80 p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-coral" />
            <span className="text-xs font-bold uppercase tracking-wider text-steel">
              Voice Assistant Speech-to-Text
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className={cn('rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider ring-1', severityMeta.chip)}>
              {severityMeta.label} Severity
            </span>
          </div>
        </div>

        {/* Speech Status feedback bar */}
        {speechStatus && (
          <div className="mb-2 flex items-center gap-1.5 rounded-lg bg-navy/5 px-2.5 py-1.5 text-[11px] text-steel">
            <Radio className="h-3 w-3 text-coral animate-pulse" />
            <span>{speechStatus}</span>
          </div>
        )}

        {/* Language Selection Bar */}
        <div className="mb-2 flex flex-wrap items-center gap-1.5 text-[11px] text-graphite">
          <span className="font-semibold text-steel">Speech Accent:</span>
          <button
            type="button"
            onClick={() => handleLanguageSwitch('en-IN')}
            className={cn(
              'rounded-md px-2 py-0.5 font-medium transition-colors border',
              speechLang === 'en-IN' ? 'bg-navy text-white border-navy' : 'bg-white text-steel border-steel/20 hover:bg-canvas'
            )}
          >
            English (India)
          </button>
          <button
            type="button"
            onClick={() => handleLanguageSwitch('te-IN')}
            className={cn(
              'rounded-md px-2 py-0.5 font-medium transition-colors border',
              speechLang === 'te-IN' ? 'bg-navy text-white border-navy' : 'bg-white text-steel border-steel/20 hover:bg-canvas'
            )}
          >
            Telugu (తెలుగు)
          </button>
          <button
            type="button"
            onClick={() => handleLanguageSwitch('en-US')}
            className={cn(
              'rounded-md px-2 py-0.5 font-medium transition-colors border',
              speechLang === 'en-US' ? 'bg-navy text-white border-navy' : 'bg-white text-steel border-steel/20 hover:bg-canvas'
            )}
          >
            English (US)
          </button>
          <button
            type="button"
            onClick={() => handleLanguageSwitch('hi-IN')}
            className={cn(
              'rounded-md px-2 py-0.5 font-medium transition-colors border',
              speechLang === 'hi-IN' ? 'bg-navy text-white border-navy' : 'bg-white text-steel border-steel/20 hover:bg-canvas'
            )}
          >
            Hindi (हिंदी)
          </button>
        </div>

        {/* Live Audio / Transcribed Text Screen */}
        <div className="relative rounded-xl border border-steel/20 bg-white p-2.5 shadow-inner">
          <div className="flex items-center justify-between text-[11px] text-graphite mb-1.5 px-1">
            <span className="flex items-center gap-1 font-medium text-steel">
              <Edit3 className="h-3 w-3 text-coral" />
              Live Transcribed Text (Click to edit or make corrections)
            </span>
            {transcript && (
              <span className="font-mono text-[10px] text-graphite">
                {transcript.split(/\s+/).filter(Boolean).length} words
              </span>
            )}
          </div>

          <Textarea
            value={transcript}
            onChange={(e) => handleTranscriptChange(e.target.value)}
            placeholder={
              recording || isSpeechActive
                ? 'Speak clearly into your mic... What you say converts to text here live!'
                : 'Your speech converts into text here as you speak. You can also edit, correct words, or type directly.'
            }
            rows={3}
            className="w-full resize-none border-0 p-1 text-sm font-medium leading-relaxed text-ink focus-visible:ring-0 focus-visible:outline-none placeholder:text-graphite/60"
          />

          {liveInterim && (
            <div className="mt-1 flex items-center gap-1.5 rounded bg-amber-50 px-2 py-1 text-[11px] text-amber-800">
              <span className="font-semibold">Hearing:</span>
              <span className="italic">&ldquo;{liveInterim}&rdquo;</span>
            </div>
          )}

          {(recording || isSpeechActive) && !liveInterim && (
            <div className="mt-1 flex items-center gap-1.5 text-[11px] text-coral font-medium">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-coral" />
              </span>
              <span>Transcribing live speech... Speak now</span>
            </div>
          )}
        </div>

        {/* Dynamic Keyword and Severity Explanation */}
        <div className="mt-3 rounded-lg bg-white/70 p-2.5 text-xs border border-steel/10">
          <div className="flex flex-wrap items-center justify-between gap-1 text-[11px]">
            <span className="text-graphite font-medium">
              Severity Calculation:
            </span>
            <span className="font-semibold text-ink">
              {calculatedSeverity === 'emergency'
                ? '🚨 Emergency (High Priority Triage)'
                : calculatedSeverity === 'medium'
                ? '⚠️ Medium (Urgent Medical / Assistance)'
                : 'ℹ️ Low (Stable / Informational)'}
            </span>
          </div>

          {severityDetails.matchedKeywords.length > 0 ? (
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] uppercase font-semibold text-graphite">Detected Signals:</span>
              {severityDetails.matchedKeywords.map((kw, i) => (
                <span
                  key={i}
                  className={cn(
                    'rounded-md px-2 py-0.5 font-mono text-[11px] font-medium',
                    calculatedSeverity === 'emergency'
                      ? 'bg-sev-critical/15 text-sev-critical ring-1 ring-sev-critical/30'
                      : 'bg-sev-medium/20 text-[#8A6410] ring-1 ring-sev-medium/40'
                  )}
                >
                  &ldquo;{kw}&rdquo;
                </span>
              ))}
            </div>
          ) : (
            <p className="mt-1 text-[11px] text-graphite/80 italic">
              💡 Tip: Mention life-threatening situations (e.g., &ldquo;trapped&rdquo;, &ldquo;water rising&rdquo;, &ldquo;cannot breathe&rdquo;) to trigger Emergency severity immediately.
            </p>
          )}
        </div>

        {/* One-Tap Emergency Voice Presets */}
        <div className="mt-3 pt-3 border-t border-steel/15">
          <p className="text-[11px] font-semibold text-graphite mb-1.5 flex items-center gap-1">
            <Zap className="h-3 w-3 text-coral" />
            Quick One-Tap Emergency Voice Presets (tap to load & edit):
          </p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_PRESETS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => applyPreset(p)}
                className="rounded-lg border border-steel/20 bg-white px-2 py-1 text-[11px] font-medium text-steel hover:border-coral hover:text-coral transition-colors shadow-xs"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <p className="mt-2.5 text-[11px] text-steel flex items-center justify-between">
          <span>Make any corrections above before sending — rescue teams read this text directly.</span>
          {transcript && (
            <span className="text-[10px] text-emerald-700 font-medium flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3 text-emerald-600" />
              Ready
            </span>
          )}
        </p>
      </div>

      {recorded && previewUrl ? (
        <div className="mt-4 space-y-2 rounded-xl border border-steel/15 bg-white p-3">
          <div className="flex items-center justify-between text-xs text-graphite mb-1">
            <span className="font-medium text-steel">Recorded Voice Audio</span>
            <span>Duration: {formatDuration(seconds)}</span>
          </div>
          <audio controls src={previewUrl} className="w-full h-10" />
          <div className="flex justify-end pt-1">
            <Button type="button" variant="ghost" size="sm" onClick={reset} className="text-steel h-7 text-xs">
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
              Re-record voice
            </Button>
          </div>
        </div>
      ) : null}

      {error ? (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl bg-sev-critical/5 p-3 ring-1 ring-sev-critical/20" role="alert">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-sev-critical" aria-hidden="true" />
          <p className="text-xs leading-relaxed text-sev-critical">{error}</p>
        </div>
      ) : null}
    </div>
  );
}
