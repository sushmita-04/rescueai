import { fetchWithTimeout } from '../../shared/live.ts';

const TARGETS = [
  { name: 'nominatim-hospitals', url: 'https://nominatim.openstreetmap.org/search?q=hospital&format=jsonv2&limit=20&extratags=1&bounded=1&viewbox=80.51,16.61,80.71,16.41' },
  { name: 'reliefweb', url: 'https://api.reliefweb.int/v1/reports?appname=rescueai&limit=5&sort%5B%5D=date%3Adesc&query%5Bvalue%5D=flood%20India' },
  { name: 'bing-news', url: 'https://www.bing.com/news/search?q=flood+Vijayawada&format=RSS' },
  { name: 'overpass-de-short', url: 'https://overpass-api.de/api/interpreter?data=%5Bout%3Ajson%5D%5Btimeout%3A10%5D%3Bnode%5B%22amenity%22%3D%22hospital%22%5D(around%3A3000%2C16.51%2C80.61)%3Bout%20tags%2010%3B' },
  { name: 'gdelt', url: 'https://api.gdeltproject.org/api/v2/doc/doc?query=flood%20Vijayawada&mode=ArtList&format=json&maxrecords=5&timespan=3d&sort=DateDesc' }
];

export default async function () {
  const results = await Promise.all(
    TARGETS.map(async (target) => {
      const started = Date.now();
      try {
        const response = await fetchWithTimeout(target.url, {}, 10000);
        const text = await response.text();
        return { name: target.name, status: response.status, ms: Date.now() - started, bytes: text.length, sample: text.slice(0, 260) };
      } catch (error: any) {
        return { name: target.name, status: 'error', ms: Date.now() - started, error: error?.message };
      }
    })
  );
  return Response.json({ results });
}
