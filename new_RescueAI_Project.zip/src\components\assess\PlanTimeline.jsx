import {
  AlertTriangle,
  Ambulance,
  CheckCircle2,
  Droplets,
  Info,
  Megaphone,
  ShieldCheck,
  Users
} from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';

const LEVEL_META = {
  info: { dot: 'bg-steel', box: 'bg-steel/5 ring-steel/15' },
  warning: { dot: 'bg-sev-medium', box: 'bg-sev-medium/10 ring-sev-medium/25' },
  danger: { dot: 'bg-sev-critical', box: 'bg-sev-critical/10 ring-sev-critical/25' }
};

const PRIORITY_META = {
  high: 'bg-sev-high/10 text-sev-high ring-sev-high/25',
  medium: 'bg-sev-medium/10 text-[#8A6410] ring-sev-medium/30',
  low: 'bg-steel/10 text-steel ring-steel/20'
};

function formatCount(value) {
  const n = Number(value) || 0;
  return n.toLocaleString('en-IN');
}

function PlanSection({ title, icon: Icon, children }) {
  return (
    <div>
      <h4 className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
        <Icon className="h-3.5 w-3.5" aria-hidden="true" />
        {title}
      </h4>
      {children}
    </div>
  );
}

export default function PlanTimeline({ plan, doneActions = [], onToggle }) {
  if (!plan || !Array.isArray(plan.timeline)) return null;
  const done = new Set(doneActions);
  const allActions = plan.timeline.flatMap((phase) => phase.actions || []);
  const doneCount = allActions.filter((action) => done.has(action.action)).length;

  return (
    <div className="space-y-5">
      {plan.risk_alerts?.length ? (
        <ul className="space-y-2">
          {plan.risk_alerts.map((alert, index) => (
            <li
              key={index}
              className={cn(
                'flex items-start gap-2.5 rounded-xl p-3 text-sm ring-1',
                LEVEL_META[alert.level]?.box || LEVEL_META.info.box
              )}
            >
              <AlertTriangle
                className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sev-medium"
                aria-hidden="true"
              />
              <span className="leading-relaxed text-ink/85">{alert.text}</span>
            </li>
          ))}
        </ul>
      ) : null}

      {plan.severity_reason ? (
        <p className="text-xs leading-relaxed text-graphite">{plan.severity_reason}</p>
      ) : null}

      {plan.recommended_team ? (
        <div className="rounded-xl border border-blue-200 bg-blue-50/60 p-3.5 ring-1 ring-blue-500/15">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-blue-600" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-900">
                Recommended Rescue Team (DB Verified)
              </span>
            </div>
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
              Active Registry
            </span>
          </div>
          <p className="mt-1.5 text-sm font-semibold text-ink">{plan.recommended_team.name}</p>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-graphite">
            <span>Lead: <strong className="text-ink">{plan.recommended_team.lead_officer}</strong></span>
            <span>Base: <strong className="text-ink">{plan.recommended_team.base_location}</strong></span>
            <span>Contact: <strong className="text-ink">{plan.recommended_team.contact_phone}</strong></span>
          </div>
          {plan.team_selection_reason && (
            <p className="mt-2 text-xs leading-relaxed text-steel bg-white/90 p-2.5 rounded-lg border border-steel/10">
              <strong className="text-blue-950 font-semibold">Selection Rationale:</strong> {plan.team_selection_reason}
            </p>
          )}
          {plan.recommended_team.equipment && (
            <p className="mt-1.5 text-[11px] text-graphite">
              <strong className="text-steel">Assigned Equipment:</strong> {plan.recommended_team.equipment}
            </p>
          )}
        </div>
      ) : null}

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h4 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
            Action timeline
          </h4>
          <span className="text-[11px] font-medium text-steel">
            {doneCount} of {allActions.length} done
          </span>
        </div>
        <div className="space-y-3">
          {plan.timeline.map((phase) => (
            <section key={phase.phase} className="rounded-xl bg-canvas/70 p-3 ring-1 ring-ink/5">
              <p className="mb-2 text-xs font-semibold text-steel">{phase.phase}</p>
              <ul className="space-y-2">
                {(phase.actions || []).map((action, index) => {
                  const isDone = done.has(action.action);
                  return (
                    <li key={index} className="flex items-start gap-2.5">
                      <Checkbox
                        checked={isDone}
                        onCheckedChange={() => onToggle?.(action.action, isDone)}
                        className="mt-0.5"
                        aria-label={action.action}
                      />
                      <div className="min-w-0">
                        <p
                          className={cn(
                            'text-sm leading-snug',
                            isDone ? 'text-graphite line-through' : 'text-ink/90'
                          )}
                        >
                          {action.action}
                        </p>
                        <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-graphite">
                          <span>{action.owner}</span>
                          {action.priority ? (
                            <span
                              className={cn(
                                'rounded px-1.5 py-0.5 font-medium',
                                PRIORITY_META[action.priority] || PRIORITY_META.low
                              )}
                            >
                              {action.priority}
                            </span>
                          ) : null}
                        </p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      </div>

      {plan.team_deployment?.length ? (
        <PlanSection title="Team deployment" icon={Users}>
          <ul className="space-y-2">
            {plan.team_deployment.map((row, index) => (
              <li
                key={index}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-lg bg-white p-3 text-sm ring-1 ring-ink/5 overflow-hidden"
              >
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-ink break-words">{row.zone_or_task}</p>
                  {row.team_name ? (
                    <p className="mt-0.5 text-xs text-graphite break-words">
                      <span className="font-medium text-ink">{row.team_name}</span>
                      {row.lead ? <span> · Lead: {row.lead}</span> : null}
                    </p>
                  ) : null}
                </div>
                <div className="shrink-0 max-w-full">
                  <span className="inline-block rounded-md bg-coral/10 px-2.5 py-1 font-mono text-xs font-semibold text-coral break-words max-w-full">
                    {row.teams_assigned}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </PlanSection>
      ) : null}

      {plan.hospital_routing?.length ? (
        <PlanSection title="Hospital routing" icon={Ambulance}>
          <ul className="space-y-2">
            {plan.hospital_routing.map((row, index) => (
              <li key={index} className="rounded-lg bg-white p-3 ring-1 ring-ink/5 overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <p className="text-sm font-semibold text-ink break-words">{row.hospital_name}</p>
                  <span className="rounded bg-coral/10 px-2 py-0.5 text-[11px] font-semibold text-coral break-words">
                    {row.role}
                  </span>
                </div>
                {row.reason ? <p className="mt-1 text-xs text-graphite break-words leading-relaxed">{row.reason}</p> : null}
              </li>
            ))}
          </ul>
        </PlanSection>
      ) : null}

      {plan.evacuation_advice || plan.public_message ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {plan.evacuation_advice ? (
            <div className="rounded-xl bg-steel/5 p-3 ring-1 ring-steel/15">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-steel">
                Evacuation advice
              </p>
              <p className="mt-1 text-xs leading-relaxed text-ink/80">{plan.evacuation_advice}</p>
            </div>
          ) : null}
          {plan.public_message ? (
            <div className="rounded-xl bg-coral/5 p-3 ring-1 ring-coral/20">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-coral">
                <Megaphone className="h-3.5 w-3.5" aria-hidden="true" />
                Public message
              </p>
              <p className="mt-1 text-xs leading-relaxed text-ink/80">{plan.public_message}</p>
            </div>
          ) : null}
        </div>
      ) : null}

      {plan.resources ? (
        <div className="flex flex-wrap gap-2 text-[11px]">
          <span className="inline-flex items-center gap-1.5 rounded-md bg-canvas px-2 py-1 text-steel">
            <Droplets className="h-3 w-3" aria-hidden="true" />
            {formatCount(plan.resources.water_litres_per_day)} L water/day
          </span>
          <span className="rounded-md bg-canvas px-2 py-1 text-steel">
            {formatCount(plan.resources.food_packets_per_day)} food packets/day
          </span>
        </div>
      ) : null}

      {plan.success_metrics?.length ? (
        <PlanSection title="Success metrics" icon={CheckCircle2}>
          <ul className="space-y-1">
            {plan.success_metrics.map((metric, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-ink/85">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sev-low" aria-hidden="true" />
                <span className="leading-snug">{metric}</span>
              </li>
            ))}
          </ul>
        </PlanSection>
      ) : null}

      {plan.assumptions?.length ? (
        <div className="rounded-xl bg-canvas/60 p-3 ring-1 ring-ink/5">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">
            <Info className="h-3.5 w-3.5" aria-hidden="true" />
            Assumptions
          </p>
          <ul className="mt-1.5 space-y-1">
            {plan.assumptions.map((assumption, index) => (
              <li key={index} className="text-[11px] leading-relaxed text-graphite">
                {assumption}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
