import { useState } from 'react';
import { Loader2, Play } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { formatDuration } from '@/lib/sos';

export default function SosAudio({ fileUri, duration }) {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await base44.integrations.Core.CreateFileSignedUrl({
        file_uri: fileUri,
        expires_in: 3600
      });
      const signed = response?.signed_url;
      if (!signed) throw new Error('missing url');
      setUrl(signed);
    } catch (err) {
      setError('Could not open this recording.');
    } finally {
      setLoading(false);
    }
  };

  if (url) {
    return (
      <div className="mt-3">
        <audio controls autoPlay src={url} className="w-full" />
        {duration ? (
          <p className="mt-1 text-[11px] text-graphite">Voice message · {formatDuration(duration)}</p>
        ) : null}
      </div>
    );
  }

  return (
    <div className="mt-3">
      <Button
        type="button"
        variant="outline"
        onClick={load}
        disabled={loading}
        className="h-10 w-full justify-start rounded-xl border-ink/10 text-sm text-steel"
      >
        {loading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
        ) : (
          <Play className="mr-2 h-4 w-4" aria-hidden="true" />
        )}
        Play voice message{duration ? ` (${formatDuration(duration)})` : ''}
      </Button>
      {error ? <p className="mt-1 text-[11px] font-medium text-sev-critical">{error}</p> : null}
    </div>
  );
}
