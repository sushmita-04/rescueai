import { useEffect, useRef, useState } from 'react';
import { MapContainer, Marker, TileLayer, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Crosshair, Loader2, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const pinIcon = L.divIcon({
  className: '',
  html:
    '<div style="width:16px;height:16px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);' +
    'background:#D96D55;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.35);margin:4px 0 0 4px"></div>',
  iconSize: [24, 24],
  iconAnchor: [12, 24]
});

const hospitalIcon = L.divIcon({
  className: '',
  html:
    '<div style="width:12px;height:12px;border-radius:50%;background:#2F4A63;border:2px solid #fff;' +
    'box-shadow:0 1px 4px rgba(0,0,0,.35);margin:5px 0 0 5px"></div>',
  iconSize: [22, 22],
  iconAnchor: [11, 11]
});

function Recentre({ lat, lng }) {
  const map = useMap();
  useEffect(() => {
    map.setView([lat, lng], map.getZoom() < 12 ? 13 : map.getZoom(), { animate: true });
  }, [lat, lng, map]);
  return null;
}

async function placeNameFor(lat, lng) {
  try {
    const response = await base44.functions.invoke('reverseGeocode', { lat, lng });
    const place = response?.data;
    if (place?.display_name) return place.display_name;
    if (place?.name) return place.name;
  } catch {
    // fall through to a generic label
  }
  return `Pinned location (${lat.toFixed(4)}, ${lng.toFixed(4)})`;
}

export default function LocationPicker({ value, onChange, hospitals = [], error }) {
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [locating, setLocating] = useState(false);
  const [coords, setCoords] = useState(null);
  const [notice, setNotice] = useState('');
  const rootRef = useRef(null);
  const timerRef = useRef(null);
  const pickedRef = useRef(null);

  useEffect(() => {
    const onDocClick = (event) => {
      if (rootRef.current && !rootRef.current.contains(event.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, []);

  useEffect(() => {
    const query = (value || '').trim();
    if (query.length < 3 || query === pickedRef.current) return undefined;
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const response = await base44.functions.invoke('geocodeSearch', { query });
        setResults(response?.data?.results || []);
        setOpen(true);
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 450);
    return () => clearTimeout(timerRef.current);
  }, [value]);

  const applyPlace = (name, lat, lng) => {
    pickedRef.current = name;
    setCoords({ lat, lng });
    setOpen(false);
    onChange({ name, lat, lng, placeName: name });
  };

  const handleSelect = (place) => {
    applyPlace(place.short_name || place.display_name, place.lat, place.lng);
  };

  const useMyLocation = () => {
    if (!navigator.geolocation) {
      setNotice('This browser cannot share your location. Search or drag the pin instead.');
      return;
    }
    setLocating(true);
    setNotice('');
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        const name = await placeNameFor(latitude, longitude);
        applyPlace(name, latitude, longitude);
        setLocating(false);
      },
      () => {
        setLocating(false);
        setNotice('Could not get your location. Search or drag the pin instead.');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handlePinDrag = async (event) => {
    const { lat, lng } = event.target.getLatLng();
    setCoords({ lat, lng });
    const name = await placeNameFor(lat, lng);
    applyPlace(name, lat, lng);
  };

  return (
    <div ref={rootRef} className="relative">
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-graphite/60"
          aria-hidden="true"
        />
        {searching ? (
          <Loader2
            className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-graphite/50"
            aria-hidden="true"
          />
        ) : null}
        <Input
          id="location"
          value={value}
          onChange={(event) => onChange({ name: event.target.value })}
          placeholder="Village, ward or landmark"
          autoComplete="off"
          aria-invalid={Boolean(error)}
          className={cn('h-11 rounded-xl pl-10 pr-10', error && 'border-sev-critical')}
        />
      </div>

      {open && results.length > 0 ? (
        <ul className="absolute z-30 mt-1.5 max-h-60 w-full overflow-auto rounded-xl bg-white py-1 shadow-lg ring-1 ring-black/10">
          {results.map((place) => (
            <li key={`${place.lat},${place.lng}`}>
              <button
                type="button"
                onClick={() => handleSelect(place)}
                className="block w-full px-3.5 py-2 text-left text-sm text-ink hover:bg-canvas"
              >
                {place.display_name}
              </button>
            </li>
          ))}
        </ul>
      ) : null}

      <button
        type="button"
        onClick={useMyLocation}
        disabled={locating}
        className="mt-1.5 inline-flex items-center gap-1.5 text-xs font-medium text-steel transition-colors hover:text-coral disabled:opacity-60"
      >
        {locating ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
        ) : (
          <Crosshair className="h-3.5 w-3.5" aria-hidden="true" />
        )}
        Use my current location
      </button>
      {notice ? <p className="mt-1 text-xs text-graphite">{notice}</p> : null}

      {coords ? (
        <div className="relative z-0 mt-3 overflow-hidden rounded-xl ring-1 ring-black/10">
          <MapContainer
            center={[coords.lat, coords.lng]}
            zoom={13}
            scrollWheelZoom={false}
            className="h-56 w-full sm:h-64"
            attributionControl
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Recentre lat={coords.lat} lng={coords.lng} />
            <Marker
              position={[coords.lat, coords.lng]}
              icon={pinIcon}
              draggable
              eventHandlers={{ dragend: handlePinDrag }}
              aria-label="Disaster location pin — drag to adjust"
            />
            {hospitals.slice(0, 8).map((hospital) =>
              Number.isFinite(hospital.lat) && Number.isFinite(hospital.lng) ? (
                <Marker
                  key={hospital.id}
                  position={[hospital.lat, hospital.lng]}
                  icon={hospitalIcon}
                  aria-label={hospital.name}
                />
              ) : null
            )}
          </MapContainer>
        </div>
      ) : null}
    </div>
  );
}
