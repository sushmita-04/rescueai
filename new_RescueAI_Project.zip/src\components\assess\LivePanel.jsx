import {
  AlertTriangle,
  ExternalLink,
  MapPin,
  Navigation,
  Phone,
  RefreshCw,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

const KINDS = ['weather', 'hospitals', 'population', 'news'];

const TITLES = {
  weather: 'Live weather',
  hospitals: 'Nearby hospitals',
  population: 'Population',
  news: 'Disaster news'
};

function ErrorRow({ message, onRetry, onDismiss }) {
  return (
    <div className="flex items-start gap-2.5" role="alert">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-sev-medium" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="text-sm leading-relaxed text-ink/80">{message}</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={onRetry}
            className="h-8 rounded-lg text-xs"
          >
            <RefreshCw className="mr-1.5 h-3 w-3" aria-hidden="true" />
            Retry
          </Button>
          <Button
            type="button"
            size="sm"
            variant="ghost"
            onClick={onDismiss}
            className="h-8 rounded-lg text-xs text-graphite"
          >
            Enter manually
          </Button>
        </div>
      </div>
    </div>
  );
}

function Card({ kind, state, onRetry, onDismiss, children }) {
  const { status, data, error } = state;

  return (
    <section className="rounded-[16px] bg-white p-4 shadow-soft ring-1 ring-black/5 sm:p-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-ink">{TITLES[kind]}</h3>
        {status === 'ok' ? (
          <span className="rounded-full bg-steel/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-steel ring-1 ring-steel/20">
            Live API
          </span>
        ) : null}
      </div>

      {status === 'loading' ? (
        <div className="space-y-2">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-4 w-2/3" />
        </div>
      ) : status === 'error' ? (
        <ErrorRow message={error} onRetry={() => onRetry(kind)} onDismiss={() => onDismiss(kind)} />
      ) : status === 'ok' ? (
        children(data)
      ) : null}
    </section>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-canvas px-3 py-2">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-graphite">{label}</p>
      <p className="mt-0.5 font-heading text-lg text-ink">{value}</p>
    </div>
  );
}

function Weather({ data }) {
  return (
    <div className="space-y-3">
      <p className="text-sm text-ink/85">
        {data.condition} · {Math.round(data.temperature)}°C · wind {Math.round(data.wind_speed)} km/h
      </p>
      <div className="grid grid-cols-2 gap-2">
        <Stat label="Rain last 24 h" value={`${data.rainfall_last_24h} mm`} />
        <Stat label="Rain next 24 h" value={`${data.rainfall_next_24h} mm`} />
      </div>
      <p className="text-[11px] text-graphite">
        Auto-fills the rainfall field — edit it if you have a better number.
      </p>
    </div>
  );
}

function Hospitals({ data }) {
  const hospitals = (data.hospitals || []).slice(0, 5);

  return (
    <div className="space-y-2">
      {hospitals.length === 0 ? (
        <p className="text-sm text-graphite">
          No hospitals found within {data.radius_used} km. Retry, or enter details manually.
        </p>
      ) : (
        hospitals.map((hospital) => (
          <div
            key={hospital.id}
            className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-canvas px-3 py-2"
          >
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-ink">{hospital.name}</p>
              <p className="text-[11px] text-graphite">
                {hospital.distance_km} km{hospital.emergency ? ' · emergency' : ''}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1.5">
              {hospital.phone ? (
                <a
                  href={`tel:${hospital.phone}`}
                  className="inline-flex h-8 items-center gap-1 rounded-lg bg-steel px-2.5 text-xs font-semibold text-white transition-colors hover:bg-navy"
                >
                  <Phone className="h-3 w-3" aria-hidden="true" />
                  Call
                </a>
              ) : null}
              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${hospital.lat},${hospital.lng}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex h-8 items-center gap-1 rounded-lg bg-coral px-2.5 text-xs font-semibold text-white transition-colors hover:bg-[#D9614A]"
              >
                <Navigation className="h-3 w-3" aria-hidden="true" />
                Directions
              </a>
            </div>
          </div>
        ))
      )}
      <p className="text-[11px] text-graphite">Also shown as markers on the location map.</p>
    </div>
  );
}

function Population({ data }) {
  if (!data.population) {
    return (
      <p className="text-sm text-graphite">
        Population data is not available for this location — enter the people affected by hand.
      </p>
    );
  }
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-canvas text-steel">
        <Users className="h-5 w-5" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <p className="font-heading text-xl text-ink">{Number(data.population).toLocaleString('en-IN')}</p>
        <p className="truncate text-xs text-graphite">
          {data.place_name || 'people in the area'} · used for exposure estimates
        </p>
      </div>
    </div>
  );
}

function News({ data }) {
  const articles = (data.articles || []).slice(0, 4);

  return (
    <ul className="space-y-2.5">
      {articles.length === 0 ? (
        <li className="text-sm text-graphite">No recent disaster news found for this place.</li>
      ) : (
        articles.map((article, index) => (
          <li key={index} className="rounded-xl bg-canvas p-2.5 transition-colors hover:bg-canvas/75">
            <a
              href={article.url}
              target="_blank"
              rel="noreferrer"
              className="group block text-sm leading-snug text-ink/85 transition-colors hover:text-coral"
            >
              <div className="flex items-start gap-1.5">
                <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-graphite/60 group-hover:text-coral" aria-hidden="true" />
                <span className="font-medium text-ink group-hover:text-coral">{article.title}</span>
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-1.5 pl-5 text-[11px] text-graphite">
                <span className="font-semibold text-steel">{article.source || article.domain}</span>
                {article.time_ago ? <span>· {article.time_ago}</span> : null}
              </div>
            </a>
          </li>
        ))
      )}
    </ul>
  );
}

export default function LivePanel({ live, dismissed, onRetry, onDismiss }) {
  const active = KINDS.filter((kind) => !dismissed[kind] && live[kind] && live[kind].status !== 'idle');

  if (active.length === 0) {
    return (
      <div className="rounded-[16px] border border-dashed border-ink/15 bg-white/60 p-6 text-center">
        <MapPin className="mx-auto h-6 w-6 text-graphite/50" aria-hidden="true" />
        <p className="mt-2 text-sm leading-relaxed text-graphite">
          Pick a location to pull live weather, nearby hospitals, population and disaster news.
          Anything the live services cannot find stays editable by hand.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {active.map((kind) => (
        <Card key={kind} kind={kind} state={live[kind]} onRetry={onRetry} onDismiss={onDismiss}>
          {(data) =>
            kind === 'weather' ? (
              <Weather data={data} />
            ) : kind === 'hospitals' ? (
              <Hospitals data={data} />
            ) : kind === 'population' ? (
              <Population data={data} />
            ) : (
              <News data={data} />
            )
          }
        </Card>
      ))}
    </div>
  );
}
