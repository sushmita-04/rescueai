import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { format } from 'date-fns';
import { AlertCircle, AlertTriangle, Bell, BellOff, Inbox, Radio } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import SosCard from '@/components/team/SosCard';
import AssessmentsTab from '@/components/team/AssessmentsTab';
import { STATUS_LABELS } from '@/lib/severity';
import { cn } from '@/lib/utils';

const FILTERS = [
  { key: 'open', label: 'Open' },
  { key: 'emergency', label: '🚨 Emergency' },
  { key: 'all', label: 'All' },
  { key: 'new', label: 'New' },
  { key: 'dispatched', label: 'Dispatched' },
  { key: 'resolved', label: 'Resolved' }
];

const PRIORITY_RANK = {
  emergency: 0,
  critical: 0,
  medium: 1,
  high: 1,
  low: 2,
  normal: 2
};

function playAlert() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    [0, 0.22, 0.44].forEach((offset) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + offset);
      gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + offset + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + offset + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + offset);
      osc.stop(ctx.currentTime + offset + 0.2);
    });
    setTimeout(() => ctx.close().catch(() => {}), 1500);
  } catch (error) {
    // audio alerts are best effort
  }
}

export default function TeamDashboard() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [alertsOn, setAlertsOn] = useState(true);
  const [filter, setFilter] = useState('open');
  const [flashIds, setFlashIds] = useState([]);

  // Acknowledge Dialog State
  const [ackTarget, setAckTarget] = useState(null);
  const [ackName, setAckName] = useState('');
  const [takeoverConfirm, setTakeoverConfirm] = useState(null);

  // Dispatch Dialog State
  const [dispatchTarget, setDispatchTarget] = useState(null);
  const [dispatchTeam, setDispatchTeam] = useState('');
  const [dispatchEta, setDispatchEta] = useState('15');

  // Resolve Dialog State
  const [resolveTarget, setResolveTarget] = useState(null);
  const [resolveOutcome, setResolveOutcome] = useState('rescued');
  const [resolveNote, setResolveNote] = useState('');

  const seenRef = useRef(null);
  const alertsRef = useRef(alertsOn);

  useEffect(() => {
    alertsRef.current = alertsOn;
  }, [alertsOn]);

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/team/sos', { credentials: 'include' });
      if (!res.ok) throw new Error('Could not load SOS queue');
      const page = await res.json();
      const rows = page?.items || [];

      const seen = seenRef.current;
      if (seen) {
        const fresh = rows.filter((row) => !seen.has(row.id) && row.status === 'new').map((row) => row.id);
        if (fresh.length > 0 && alertsRef.current) {
          playAlert();
          setFlashIds((prev) => [...prev, ...fresh]);
          window.setTimeout(() => setFlashIds([]), 4500);
        }
      }
      seenRef.current = new Set(rows.map((row) => row.id));

      setItems(rows);
      setError('');
      setLastUpdated(new Date());
    } catch (err) {
      setError(err?.message || 'Could not load the SOS queue.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Polling fallback
  useEffect(() => {
    load();
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, [load]);

  // Real-time SSE Connection
  useEffect(() => {
    let eventSource = null;
    try {
      eventSource = new EventSource('/api/team/stream', { withCredentials: true });

      eventSource.addEventListener('sos_created', (e) => {
        try {
          const newSos = JSON.parse(e.data);
          if (newSos?.id) {
            if (alertsRef.current) {
              playAlert();
              setFlashIds((prev) => [...prev, newSos.id]);
              window.setTimeout(() => setFlashIds([]), 4500);
            }
            setItems((prev) => [newSos, ...prev.filter((item) => item.id !== newSos.id)]);
            setLastUpdated(new Date());
          }
        } catch {}
      });

      eventSource.addEventListener('sos_updated', (e) => {
        try {
          const updatedSos = JSON.parse(e.data);
          if (updatedSos?.id) {
            setItems((prev) => prev.map((item) => (item.id === updatedSos.id ? updatedSos : item)));
            setLastUpdated(new Date());
          }
        } catch {}
      });
    } catch {}

    return () => {
      if (eventSource) eventSource.close();
    };
  }, []);

  // Overdue check (>5 min in 'new')
  const overdueCount = useMemo(() => {
    const now = Date.now();
    return items.filter(
      (item) => item.status === 'new' && item.created_date && now - new Date(item.created_date).getTime() > 5 * 60 * 1000
    ).length;
  }, [items]);

  const counts = useMemo(() => {
    const next = { new: 0, acknowledged: 0, dispatched: 0, resolved: 0 };
    items.forEach((item) => {
      if (next[item.status] !== undefined) next[item.status] += 1;
    });
    return next;
  }, [items]);

  // Page title notification
  useEffect(() => {
    if (counts.new > 0) {
      const overdueAlert = overdueCount > 0 ? ` (${overdueCount} overdue)` : '';
      document.title = `🚨 ${counts.new}${overdueAlert} · RescueAI`;
    } else {
      document.title = 'RescueAI · Rescue Team';
    }
    return () => {
      document.title = 'RescueAI';
    };
  }, [counts.new, overdueCount]);

  // Sort: Overdue 'new' first, then regular status priority and recency
  const visible = useMemo(() => {
    const now = Date.now();
    const sorted = [...items].sort((a, b) => {
      // 1. Overdue 'new' cases at the very top
      const isOverdueA = a.status === 'new' && a.created_date && now - new Date(a.created_date).getTime() > 5 * 60 * 1000;
      const isOverdueB = b.status === 'new' && b.created_date && now - new Date(b.created_date).getTime() > 5 * 60 * 1000;
      if (isOverdueA !== isOverdueB) return isOverdueA ? -1 : 1;

      // 2. Resolved cases to bottom
      const resolvedA = a.status === 'resolved' ? 1 : 0;
      const resolvedB = b.status === 'resolved' ? 1 : 0;
      if (resolvedA !== resolvedB) return resolvedA - resolvedB;

      // 3. Priority rank
      const priorityA = PRIORITY_RANK[a.priority] ?? 3;
      const priorityB = PRIORITY_RANK[b.priority] ?? 3;
      if (priorityA !== priorityB) return priorityA - priorityB;

      // 4. Date created
      return new Date(b.created_date).getTime() - new Date(a.created_date).getTime();
    });

    if (filter === 'all') return sorted;
    if (filter === 'open') return sorted.filter((item) => item.status !== 'resolved');
    if (filter === 'emergency') return sorted.filter((item) => item.priority === 'emergency' || item.priority === 'critical');
    return sorted.filter((item) => item.status === filter);
  }, [items, filter]);

  // Seen endpoint
  const markSeen = async (id) => {
    try {
      await fetch(`/api/team/sos/${id}/seen`, {
        method: 'POST',
        credentials: 'include'
      });
    } catch {}
  };

  // Status updates
  const handleStatusChange = async (sosId, payload) => {
    try {
      const res = await fetch(`/api/team/sos/${sosId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        if (json.already_taken) {
          setTakeoverConfirm({
            sosId,
            takenBy: json.taken_by,
            payload
          });
          return;
        }
        throw new Error(json.error || 'Update failed');
      }

      await load();
      toast({
        title: 'Case updated',
        description: `Status changed to ${STATUS_LABELS[payload.status] || payload.status}`
      });
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Update failed',
        description: err?.message || 'Please try again.'
      });
    }
  };

  const confirmAcknowledge = async () => {
    if (!ackTarget) return;
    const target = ackTarget;
    setAckTarget(null);
    await handleStatusChange(target.id, {
      status: 'acknowledged',
      handled_by: ackName.trim() || user?.full_name || user?.email || 'Rescue team'
    });
    setAckName('');
  };

  const confirmTakeover = async () => {
    if (!takeoverConfirm) return;
    const { sosId, payload } = takeoverConfirm;
    setTakeoverConfirm(null);
    await handleStatusChange(sosId, { ...payload, override: true });
  };

  const confirmDispatch = async () => {
    if (!dispatchTarget) return;
    const target = dispatchTarget;
    setDispatchTarget(null);
    await handleStatusChange(target.id, {
      status: 'dispatched',
      handled_by: dispatchTeam.trim() || target.handled_by || 'Response Team Alpha',
      eta_minutes: parseInt(dispatchEta, 10) || 15
    });
  };

  const confirmResolve = async () => {
    if (!resolveTarget) return;
    const target = resolveTarget;
    setResolveTarget(null);
    await handleStatusChange(target.id, {
      status: 'resolved',
      outcome: resolveOutcome,
      note: resolveNote.trim()
    });
    setResolveNote('');
  };

  const sendMessage = async (sos, message) => {
    try {
      const res = await fetch(`/api/team/sos/${sos.id}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ message })
      });
      if (!res.ok) throw new Error('Could not send message');
      toast({ title: 'Message sent to sender' });
      await load();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Failed to send message', description: err.message });
    }
  };

  const statCards = [
    { key: 'new', label: 'New', tone: 'text-sev-critical' },
    { key: 'acknowledged', label: 'Acknowledged', tone: 'text-steel' },
    { key: 'dispatched', label: 'Dispatched', tone: 'text-coral' },
    { key: 'resolved', label: 'Resolved', tone: 'text-sev-low' }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-coral">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-coral" />
            </span>
            Live queue
          </p>
          <h1 className="mt-1 font-heading text-2xl text-ink sm:text-3xl">Incoming SOS</h1>
          <p className="mt-1 text-xs text-graphite">
            Updated{' '}
            <span className="font-mono text-ink">
              {lastUpdated ? format(lastUpdated, 'HH:mm:ss') : '—'}
            </span>
          </p>
        </div>

        <label className="flex items-center gap-2 rounded-full bg-white px-3 py-2 text-xs font-medium text-steel shadow-soft ring-1 ring-black/5">
          {alertsOn ? (
            <Bell className="h-3.5 w-3.5" aria-hidden="true" />
          ) : (
            <BellOff className="h-3.5 w-3.5" aria-hidden="true" />
          )}
          Sound alerts {alertsOn ? 'on' : 'off'}
          <Switch checked={alertsOn} onCheckedChange={setAlertsOn} aria-label="Sound alerts" />
        </label>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statCards.map((stat) => (
          <div key={stat.key} className="rounded-[16px] bg-white p-4 shadow-soft ring-1 ring-black/5">
            <p className="text-[11px] font-medium uppercase tracking-wider text-graphite">{stat.label}</p>
            <p className={cn('mt-1 font-heading text-3xl', stat.tone)}>{counts[stat.key]}</p>
          </div>
        ))}
      </div>

      <Tabs defaultValue="sos" className="mt-6">
        <TabsList className="grid w-full max-w-xs grid-cols-2 rounded-xl bg-white p-1 shadow-soft ring-1 ring-black/5">
          <TabsTrigger value="sos" className="rounded-lg text-sm">
            SOS queue
          </TabsTrigger>
          <TabsTrigger value="assessments" className="rounded-lg text-sm">
            Assessments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sos" className="mt-5">
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((chip) => (
              <button
                key={chip.key}
                type="button"
                onClick={() => setFilter(chip.key)}
                aria-pressed={filter === chip.key}
                className={cn(
                  'rounded-full border px-3 py-1.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral/40',
                  filter === chip.key
                    ? 'border-navy bg-navy text-white'
                    : 'border-ink/10 bg-white text-steel hover:border-steel/40'
                )}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {error ? (
            <div className="mt-5 flex items-start gap-2.5 rounded-xl bg-sev-critical/5 p-4 ring-1 ring-sev-critical/20" role="alert">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-sev-critical" aria-hidden="true" />
              <div>
                <p className="text-sm text-sev-critical">{error}</p>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={load}
                  className="mt-2 h-8 rounded-lg border-sev-critical/30 text-xs text-sev-critical"
                >
                  Try again
                </Button>
              </div>
            </div>
          ) : null}

          <div className="mt-4 space-y-3">
            {loading ? (
              [0, 1, 2].map((index) => <Skeleton key={index} className="h-52 w-full rounded-[16px]" />)
            ) : visible.length === 0 ? (
              <div className="rounded-[16px] bg-white p-10 text-center shadow-soft ring-1 ring-black/5">
                <Inbox className="mx-auto h-8 w-8 text-graphite/50" aria-hidden="true" />
                <p className="mt-3 text-sm text-graphite">
                  No SOS messages here yet. New ones appear automatically.
                </p>
              </div>
            ) : (
              visible.map((sos) => (
                <SosCard
                  key={sos.id}
                  sos={sos}
                  flash={flashIds.includes(sos.id)}
                  onSeen={markSeen}
                  onAcknowledge={(target) => {
                    setAckTarget(target);
                    setAckName(user?.full_name || user?.email || '');
                  }}
                  onDispatch={(target) => {
                    setDispatchTarget(target);
                    setDispatchTeam(target.handled_by || user?.full_name || 'Rescue Team');
                    setDispatchEta('15');
                  }}
                  onResolve={(target) => {
                    setResolveTarget(target);
                    setResolveOutcome('rescued');
                    setResolveNote('');
                  }}
                  onReopen={(target) => handleStatusChange(target.id, { status: 'new' })}
                  onSendMessage={sendMessage}
                />
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="assessments" className="mt-5">
          <AssessmentsTab />
        </TabsContent>
      </Tabs>

      {/* Acknowledge Dialog */}
      <Dialog open={Boolean(ackTarget)} onOpenChange={(open) => !open && setAckTarget(null)}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Acknowledge SOS</DialogTitle>
            <DialogDescription>
              Claim this case and let the sender know you have taken responsibility.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2">
            <Label htmlFor="ack-input" className="text-xs">Your callsign or name</Label>
            <Input
              id="ack-input"
              value={ackName}
              onChange={(event) => setAckName(event.target.value)}
              placeholder="e.g. Unit 4 - Sarah / Dispatcher"
              className="mt-1 h-11 rounded-xl"
              autoFocus
            />
          </div>
          <DialogFooter className="mt-4 gap-2 sm:gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setAckTarget(null)}
              className="rounded-xl"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={confirmAcknowledge}
              className="rounded-xl bg-coral text-white hover:bg-[#D9614A]"
            >
              Claim case
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Takeover Confirmation Dialog */}
      <Dialog open={Boolean(takeoverConfirm)} onOpenChange={(open) => !open && setTakeoverConfirm(null)}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading flex items-center gap-2 text-sev-critical">
              <AlertTriangle className="h-5 w-5" />
              Case Already Acknowledged
            </DialogTitle>
            <DialogDescription>
              This case is already claimed by <strong>{takeoverConfirm?.takenBy}</strong>. Do you want to take over?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4 gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setTakeoverConfirm(null)}
              className="rounded-xl"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={confirmTakeover}
              className="rounded-xl bg-sev-critical text-white hover:bg-red-700"
            >
              Take over case
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dispatch Dialog */}
      <Dialog open={Boolean(dispatchTarget)} onOpenChange={(open) => !open && setDispatchTarget(null)}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Dispatch rescue unit</DialogTitle>
            <DialogDescription>
              Deploy a response team and inform the sender of your estimated arrival time.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2 space-y-3">
            <div>
              <Label htmlFor="dispatch-team" className="text-xs">Team / Callsign</Label>
              <Input
                id="dispatch-team"
                value={dispatchTeam}
                onChange={(e) => setDispatchTeam(e.target.value)}
                placeholder="e.g. NDRF Boat Unit 2"
                className="mt-1 h-11 rounded-xl"
              />
            </div>
            <div>
              <Label htmlFor="dispatch-eta" className="text-xs">Estimated Arrival Time (Minutes)</Label>
              <Input
                id="dispatch-eta"
                type="number"
                min="1"
                max="240"
                value={dispatchEta}
                onChange={(e) => setDispatchEta(e.target.value)}
                placeholder="15"
                className="mt-1 h-11 rounded-xl"
              />
            </div>
          </div>
          <DialogFooter className="mt-4 gap-2">
            <Button type="button" variant="outline" onClick={() => setDispatchTarget(null)} className="rounded-xl">
              Cancel
            </Button>
            <Button type="button" onClick={confirmDispatch} className="rounded-xl bg-steel text-white hover:bg-navy">
              Confirm dispatch
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Resolve Dialog */}
      <Dialog open={Boolean(resolveTarget)} onOpenChange={(open) => !open && setResolveTarget(null)}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Mark SOS as resolved</DialogTitle>
            <DialogDescription>
              Record the outcome and close out this emergency call.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2 space-y-3">
            <div>
              <Label className="text-xs">Outcome</Label>
              <Select value={resolveOutcome} onValueChange={setResolveOutcome}>
                <SelectTrigger className="mt-1 h-11 rounded-xl">
                  <SelectValue placeholder="Select outcome" />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  <SelectItem value="rescued">Rescued / Safely evacuated</SelectItem>
                  <SelectItem value="referred to hospital">Referred to hospital / Medical transfer</SelectItem>
                  <SelectItem value="false alarm">False alarm</SelectItem>
                  <SelectItem value="other">Other / Assistance rendered</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="resolve-note" className="text-xs">Resolution note</Label>
              <Textarea
                id="resolve-note"
                value={resolveNote}
                onChange={(e) => setResolveNote(e.target.value)}
                placeholder="Details of the rescue and handover..."
                className="mt-1 h-20 rounded-xl text-xs"
              />
            </div>
          </div>
          <DialogFooter className="mt-4 gap-2">
            <Button type="button" variant="outline" onClick={() => setResolveTarget(null)} className="rounded-xl">
              Cancel
            </Button>
            <Button type="button" onClick={confirmResolve} className="rounded-xl bg-sev-low text-white hover:bg-[#23897C]">
              Close case
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
