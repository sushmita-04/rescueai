import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Activity,
  AlertCircle,
  ArrowRight,
  Clock,
  Compass,
  MapPin,
  Mic,
  Radio,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Waves
} from 'lucide-react';
import CityMapScene from '@/components/landing/CityMapScene';

/**
 * RescueAI Landing Page - Medium, Trustworthy Emergency Theme
 *
 * Design Direction:
 * - Clean, medium-toned emergency command-center theme (calm, professional, trustworthy)
 * - Background: soft cool slate #EEF2F7 to #DDE5EF subtle gradient
 * - 3D Hero Map: medium slate-blue city (#C7D3E3 terrain, #A9BBD1 buildings, #8FA3BC shadows)
 * - Controlled red-orange incident marker (#E5484D) with soft amber halo (#FFB86B)
 * - Trustworthy blue (#2563EB) & teal (#0E9F8A) response routes
 * - White glass panels (70-85% opacity, #D7E0EA borders, realistic low-opacity slate shadows)
 * - Headings: #1F2A37, Body text: #4B5563
 * - Primary CTA "Launch App": #1D4ED8 with subtle red-orange accent glow on hover
 * - Secondary CTA: white card-style button with slate border
 */
export default function Landing() {
  const navigate = useNavigate();
  const [isExiting, setIsExiting] = useState(false);

  const handleLaunchApp = () => {
    setIsExiting(true);
    // Smooth transition into the main application entry point (/)
    setTimeout(() => {
      navigate('/');
    }, 380);
  };

  const scrollToCommandStage = () => {
    const el = document.getElementById('command-stage');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#EEF2F7] via-[#E7ECF3] to-[#DDE5EF] text-[#1F2A37] selection:bg-[#2563EB] selection:text-white font-sans antialiased overflow-x-hidden">
      {/* 1. Subtle Architectural Grid Overlay (Soft Daylight Ambience) */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-40"
        style={{
          backgroundImage:
            'radial-gradient(circle at 1px 1px, rgba(143, 163, 188, 0.2) 1px, transparent 0)',
          backgroundSize: '36px 36px'
        }}
        aria-hidden="true"
      />

      {/* 2. Sticky Glass Command Navbar */}
      <header className="sticky top-0 z-40 border-b border-[#D7E0EA] bg-white/80 backdrop-blur-md shadow-[0_4px_20px_rgba(75,85,99,0.04)]">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          {/* Logo: RescueAI */}
          <div className="flex items-center gap-2.5 select-none">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#2563EB] to-[#0E9F8A] shadow-md shadow-[#2563EB]/20 text-white">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <span className="font-heading text-lg font-bold tracking-tight text-[#1F2A37]">
                Rescue<span className="text-[#2563EB]">AI</span>
              </span>
              <span className="hidden sm:inline-block ml-2 text-[10px] font-mono font-medium text-[#4B5563] uppercase tracking-wider bg-[#E8F0F8] px-2 py-0.5 rounded border border-[#D7E0EA]">
                Incident Command System
              </span>
            </div>
          </div>

          {/* Nav Actions */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={scrollToCommandStage}
              className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-[#D7E0EA] bg-white px-3.5 py-1.5 text-xs font-semibold text-[#4B5563] shadow-sm hover:bg-[#F6F8FB] hover:text-[#1F2A37] transition-all"
            >
              <span>Live Command Map</span>
            </button>

            {/* Primary CTA: Launch App */}
            <button
              type="button"
              onClick={handleLaunchApp}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold text-white shadow-md shadow-[#1D4ED8]/25 hover:bg-[#1E40AF] hover:shadow-[0_0_24px_rgba(229,72,77,0.35)] transition-all active:scale-95 cursor-pointer"
            >
              <span>Launch App</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 3. Hero Command Center Section */}
      <section className="relative z-10 pt-10 pb-16 sm:pt-14 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-center gap-8 lg:gap-12">
          {/* LEFT COLUMN: Calm, Trustworthy Hero Narrative */}
          <div className="lg:col-span-5 flex flex-col items-start text-left">
            {/* Trustworthy Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-[#D7E0EA] bg-white/85 px-3 py-1 text-xs font-mono font-medium text-[#2563EB] shadow-sm mb-5">
              <span className="h-2 w-2 rounded-full bg-[#0E9F8A] animate-pulse" />
              <span>EMERGENCY DISPATCH & TRIAGE HUB</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#1F2A37] font-heading leading-[1.15]">
              Calm, Coordinated Rescue When Every Second Matters.
            </h1>

            {/* Supporting Subheadline */}
            <p className="mt-4 text-base sm:text-lg text-[#4B5563] leading-relaxed font-normal">
              RescueAI unifies live spoken citizen distress signals, automatic geospatial triage, and verified responder dispatch into a clear, reliable emergency command platform.
            </p>

            {/* CTAs */}
            <div className="mt-7 flex flex-wrap items-center gap-3.5">
              {/* Primary CTA "Launch App" */}
              <button
                type="button"
                onClick={handleLaunchApp}
                className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-[#1D4ED8] px-6 sm:px-7 py-3 text-sm sm:text-base font-bold text-white shadow-lg shadow-[#1D4ED8]/25 hover:bg-[#1E40AF] hover:shadow-[0_0_24px_rgba(229,72,77,0.35)] transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                <span>Launch App</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              {/* Secondary CTA: White card-style button with slate border */}
              <button
                type="button"
                onClick={scrollToCommandStage}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#D7E0EA] bg-white/90 px-5 sm:px-6 py-3 text-sm font-semibold text-[#1F2A37] shadow-sm hover:bg-[#F6F8FB] hover:border-[#CBD5E1] transition-all duration-200 cursor-pointer"
              >
                <span>View Command Map</span>
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="mt-8 pt-6 border-t border-[#D7E0EA]/80 flex flex-wrap items-center gap-6 text-xs text-[#4B5563]">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-[#0E9F8A]" />
                <span className="font-medium">Gov ID Verified Responders</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-[#2563EB]" />
                <span className="font-medium">0.8s Speech Triage Latency</span>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: 3D Emergency City Map Hero Scene */}
          <div
            id="command-stage"
            className="lg:col-span-7 relative w-full rounded-2xl border border-[#D7E0EA] bg-white/70 p-3 sm:p-5 shadow-[0_16px_40px_rgba(75,85,99,0.08)] backdrop-blur-md"
          >
            {/* Map Header Status Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-[#D7E0EA]/80 text-xs">
              <div className="flex items-center gap-2">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E5484D] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#E5484D]" />
                </span>
                <span className="font-mono font-bold text-[#1F2A37] uppercase tracking-wide">
                  Active Incident Sector 4
                </span>
              </div>

              <div className="flex items-center gap-3 text-[11px] font-mono text-[#4B5563]">
                <span className="flex items-center gap-1 text-[#2563EB]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#2563EB]" />
                  Route Alpha: 6m ETA
                </span>
                <span className="flex items-center gap-1 text-[#0E9F8A]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#0E9F8A]" />
                  Hospital Corridor
                </span>
              </div>
            </div>

            {/* 3D City Map Canvas */}
            <div className="relative rounded-xl overflow-hidden border border-[#D7E0EA]/70 bg-gradient-to-b from-[#E8F0F8] to-[#DDE5EF] shadow-inner">
              <CityMapScene />

              {/* In-Map Floating Legend Pill */}
              <div className="absolute bottom-3 left-3 bg-white/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#D7E0EA] shadow-sm flex items-center gap-3 text-[10px] font-mono text-[#4B5563]">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#E5484D]" />
                  <span>Incident Marker</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#2563EB]" />
                  <span>Alpha Rescue Path</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#0E9F8A]" />
                  <span>Med-Evac Hub</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4. 2–3 Large Command Panels (Layered Supporting Depth) */}
        <div className="mt-12 sm:mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Panel 1: Controlled Incident Alert Ticket */}
          <div className="rounded-2xl border border-[#D7E0EA] bg-white/80 p-5 shadow-[0_12px_32px_rgba(75,85,99,0.06)] backdrop-blur-md space-y-3.5 transition-all hover:shadow-[0_16px_36px_rgba(75,85,99,0.1)]">
            <div className="flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-md bg-[#E5484D]/10 border border-[#E5484D]/25 px-2.5 py-1 font-mono font-bold text-[#E5484D] uppercase">
                <AlertCircle className="h-3.5 w-3.5" />
                Emergency Priority
              </span>
              <span className="font-mono text-[11px] text-[#4B5563]">REF: 8X7F2A</span>
            </div>

            <div className="rounded-xl bg-[#F6F8FB] p-3.5 border border-[#D7E0EA] space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1F2A37]">
                <Mic className="h-3.5 w-3.5 text-[#2563EB]" />
                <span>Victim Spoken Distress Audio</span>
              </div>
              <p className="text-xs text-[#4B5563] leading-relaxed italic">
                &ldquo;Trapped on the second floor, flood water rising fast into the rooms! 4 people here, please send help!&rdquo;
              </p>
            </div>

            <div className="flex items-center justify-between text-xs pt-1 border-t border-[#D7E0EA]/70 text-[#4B5563]">
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-[#E5484D]" />
                St. Jude Colony, Sector 4
              </span>
              <span className="font-mono text-[11px] text-[#0E9F8A] font-semibold">GPS LOCKED</span>
            </div>
          </div>

          {/* Panel 2: Trustworthy Unit Dispatch & Live Route Tracker */}
          <div className="rounded-2xl border border-[#D7E0EA] bg-white/80 p-5 shadow-[0_12px_32px_rgba(75,85,99,0.06)] backdrop-blur-md space-y-3.5 transition-all hover:shadow-[0_16px_36px_rgba(75,85,99,0.1)]">
            <div className="flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-md bg-[#2563EB]/10 border border-[#2563EB]/25 px-2.5 py-1 font-mono font-bold text-[#2563EB] uppercase">
                <Radio className="h-3.5 w-3.5" />
                Response Unit En Route
              </span>
              <span className="font-mono text-[11px] text-[#0E9F8A] font-bold">STATUS: ACTIVE</span>
            </div>

            <div className="rounded-xl bg-[#F6F8FB] p-3.5 border border-[#D7E0EA] space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#4B5563]">Assigned Unit:</span>
                <span className="font-bold text-[#1F2A37]">Alpha-Boat 04 (Evacuation)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#4B5563]">Authorized Lead:</span>
                <span className="font-mono text-[#2563EB] font-medium">GOV-RESCUE-7701</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#4B5563]">Estimated Arrival:</span>
                <span className="font-bold text-[#2563EB] flex items-center gap-1">
                  <Clock className="h-3 w-3" /> 6 Minutes (Live Countdown)
                </span>
              </div>
            </div>

            {/* Clear 3-Step Route Progress */}
            <div className="pt-1 space-y-1.5">
              <div className="flex justify-between text-[10px] font-mono text-[#4B5563]">
                <span className="text-[#2563EB] font-bold">1. Acknowledged ✓</span>
                <span className="text-[#2563EB] font-bold">2. Dispatched ✓</span>
                <span className="text-[#1F2A37] font-semibold">3. On Scene (6m)</span>
              </div>
              <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-[#2563EB] to-[#0E9F8A] h-full w-[68%]" />
              </div>
            </div>
          </div>

          {/* Panel 3: Command Center Multi-Hazard Hub */}
          <div className="rounded-2xl border border-[#D7E0EA] bg-white/80 p-5 shadow-[0_12px_32px_rgba(75,85,99,0.06)] backdrop-blur-md space-y-3.5 transition-all hover:shadow-[0_16px_36px_rgba(75,85,99,0.1)]">
            <div className="flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-md bg-[#0E9F8A]/10 border border-[#0E9F8A]/25 px-2.5 py-1 font-mono font-bold text-[#0E9F8A] uppercase">
                <ShieldCheck className="h-3.5 w-3.5" />
                Hospital & Sensor Matrix
              </span>
              <span className="font-mono text-[11px] text-[#4B5563]">ALL SYSTEMS NORMAL</span>
            </div>

            <div className="rounded-xl bg-[#F6F8FB] p-3.5 border border-[#D7E0EA] space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#4B5563]">City Trauma Hospital:</span>
                <span className="font-semibold text-[#0E9F8A]">14 ICU Beds Available</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#4B5563]">Weather Telemetry:</span>
                <span className="font-semibold text-[#1F2A37]">Precipitation 48mm/h</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#4B5563]">Civilian SOS Queue:</span>
                <span className="font-mono text-[#2563EB] font-semibold">14 Triaged (0 Pending)</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1 border-t border-[#D7E0EA]/70 text-[#4B5563]">
              <span className="font-mono text-[11px]">Base44 Data Mesh Sync</span>
              <span className="font-mono text-[11px] text-[#0E9F8A]">● ONLINE</span>
            </div>
          </div>
        </div>

        {/* 5. Minimal Trustworthy Footer */}
        <footer className="mt-16 pt-8 border-t border-[#D7E0EA] flex flex-wrap items-center justify-between text-xs text-[#4B5563]">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-[#2563EB]" />
            <span className="font-semibold text-[#1F2A37]">RescueAI Command Platform</span>
            <span>· Calm control during critical emergencies</span>
          </div>
          <div className="font-mono text-[11px] text-[#4B5563]">
            TLS 1.3 Encrypted · Gov-Issued Responder Verification Standard
          </div>
        </footer>
      </section>

      {/* Smooth Transition Overlay */}
      <div
        className={`fixed inset-0 bg-[#EEF2F7] pointer-events-none z-50 transition-opacity duration-300 ${
          isExiting ? 'opacity-100' : 'opacity-0'
        }`}
        aria-hidden="true"
      />
    </div>
  );
}
