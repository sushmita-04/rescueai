import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cached, cacheKey, fetchJson } from '../../shared/live.ts';

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const query = String(body?.query || '').trim().slice(0, 160);

    if (query.length < 3) {
      return Response.json({ results: [], error: 'Type at least 3 characters.' }, { status: 400 });
    }

    const data = await cached(base44, cacheKey(['geocode', query]), async () => {
      const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=jsonv2&limit=5&addressdetails=1`;
      const rows = await fetchJson(url);
      const results = (Array.isArray(rows) ? rows : [])
        .map((row: any) => ({
          display_name: String(row?.display_name || ''),
          short_name: String(row?.name || String(row?.display_name || '').split(',')[0] || ''),
          lat: Number(row?.lat),
          lng: Number(row?.lon),
          type: String(row?.type || row?.addresstype || '')
        }))
        .filter((row: any) => Number.isFinite(row.lat) && Number.isFinite(row.lng));
      return { results };
    });

    return Response.json(data);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Location search failed.' }, { status: 502 });
  }
}
