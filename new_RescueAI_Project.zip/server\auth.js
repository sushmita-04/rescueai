import express from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query, queryOne, newId } from './db.js';

const router = express.Router();

// In-memory login rate limiter: 10 attempts per 15 minutes per IP
const loginAttempts = new Map(); // ip -> [timestamps]
const LOGIN_MAX_ATTEMPTS = 10;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

function checkLoginRateLimit(ip) {
  const now = Date.now();
  const history = (loginAttempts.get(ip) || []).filter((t) => now - t < LOGIN_WINDOW_MS);
  if (history.length >= LOGIN_MAX_ATTEMPTS) {
    return false;
  }
  history.push(now);
  loginAttempts.set(ip, history);
  return true;
}

// Schemas
const RegisterSchema = z.object({
  email: z.string().email().transform((v) => v.toLowerCase().trim()),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
  full_name: z.string().optional(),
  team_code: z.string().optional()
});

const LoginSchema = z.object({
  email: z.string().optional(),
  identifier: z.string().optional(),
  gov_id: z.string().optional(),
  password: z.string().min(1, 'Password or passcode is required'),
  portal: z.string().optional()
});

const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8, 'New password must be at least 8 characters long')
});

// Middleware: attach user to req.user if logged in
export async function attachUser(req, res, next) {
  if (req.session?.userId) {
    try {
      const user = await queryOne(
        'SELECT id, email, gov_id, full_name, role, staff_type, created_date FROM users WHERE id = ?',
        [req.session.userId]
      );
      if (user) {
        req.user = user;
      } else {
        req.session.destroy(() => {});
      }
    } catch {
      // ignore
    }
  }
  next();
}

export function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
}

export function requireStaff(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const isStaff = req.user.role === 'admin' || req.user.role === 'rescue_team' || req.user.staff_type === 'rescue_team';
  if (!isStaff) {
    return res.status(403).json({ error: 'Rescue team or admin access required' });
  }
  next();
}

export function requireAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Administrator access required' });
  }
  next();
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const parse = RegisterSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: parse.error.errors[0]?.message || 'Invalid input' });
  }

  const { email, password, full_name, team_code } = parse.data;

  try {
    const existing = await queryOne('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return res.status(409).json({ error: 'An account with that email already exists' });
    }

    const hash = await bcrypt.hash(password, 10);
    const userId = newId('user');
    const now = new Date().toISOString();

    const isRescueTeam = Boolean(team_code && team_code.trim() === (process.env.RESCUE_TEAM_CODE || 'RESCUE2026'));
    const role = isRescueTeam ? 'rescue_team' : 'public';
    const staffType = isRescueTeam ? 'rescue_team' : '';

    await query(
      'INSERT INTO users (id, email, password_hash, full_name, role, staff_type, created_date, updated_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [userId, email, hash, full_name || '', role, staffType, now, now]
    );

    // Auto sign-in right after registration
    req.session.userId = userId;
    req.session.save((err) => {
      if (err) {
        return res.status(500).json({ error: 'Session could not be saved' });
      }
      return res.json({
        user: {
          id: userId,
          email,
          full_name: full_name || '',
          role,
          staff_type: staffType,
          created_date: now
        }
      });
    });
  } catch (err) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Could not complete registration' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
  if (!checkLoginRateLimit(clientIp)) {
    return res.status(429).json({ error: 'Too many login attempts. Please try again in 15 minutes.' });
  }

  const parse = LoginSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: parse.error.errors[0]?.message || 'Invalid input' });
  }

  const { email, identifier, gov_id, password, portal } = parse.data;
  const lookup = (gov_id || identifier || email || '').trim().toLowerCase();

  if (!lookup) {
    return res.status(400).json({
      error: portal === 'team'
        ? 'Government-Issued Responder ID is required'
        : 'Email address is required'
    });
  }

  try {
    const user = await queryOne(
      "SELECT id, email, gov_id, password_hash, full_name, role, staff_type, created_date FROM users WHERE LOWER(COALESCE(gov_id, '')) = ? OR LOWER(email) = ?",
      [lookup, lookup]
    );

    if (!user) {
      return res.status(401).json({
        error: portal === 'team'
          ? 'Invalid Government Responder ID or Passcode.'
          : 'Invalid email or password.'
      });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({
        error: portal === 'team'
          ? 'Invalid Government Responder ID or Passcode.'
          : 'Invalid email or password.'
      });
    }

    const isStaff = user.role === 'admin' || user.role === 'rescue_team' || user.staff_type === 'rescue_team';

    // Strictly enforce rescue team credentials on the Rescue Team login portal
    if (portal === 'team' && !isStaff) {
      return res.status(403).json({
        error: 'Access denied: This ID does not have Rescue Team authorization. Common users must sign in via SOS Login.'
      });
    }

    req.session.userId = user.id;
    req.session.save((err) => {
      if (err) {
        return res.status(500).json({ error: 'Session could not be saved' });
      }
      return res.json({
        user: {
          id: user.id,
          email: user.email,
          gov_id: user.gov_id || '',
          full_name: user.full_name || '',
          role: user.role,
          staff_type: user.staff_type || '',
          created_date: user.created_date
        }
      });
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Could not log in' });
  }
});

// GET /api/auth/auto-login (Direct 1-click access to Team Dashboard)
router.get('/auto-login', async (req, res) => {
  try {
    const user = await queryOne(
      "SELECT id, email, full_name, role, staff_type, created_date FROM users WHERE role = 'admin' LIMIT 1"
    );
    if (!user) {
      return res.status(500).send('Admin account not found');
    }
    req.session.userId = user.id;
    req.session.save((err) => {
      if (err) {
        return res.status(500).send('Could not save session');
      }
      const returnTo = typeof req.query.returnTo === 'string' && req.query.returnTo.startsWith('/')
        ? req.query.returnTo
        : '/team';
      return res.redirect(returnTo);
    });
  } catch (err) {
    return res.status(500).send('Auto login failed');
  }
});

// GET /api/auth/me
router.get('/me', (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  return res.json(req.user);
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    res.clearCookie('connect.sid');
    res.clearCookie('sessionId');
    return res.json({ ok: true });
  });
});

// POST /api/auth/change-password
router.post('/change-password', requireAuth, async (req, res) => {
  const parse = ChangePasswordSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: parse.error.errors[0]?.message || 'Invalid input' });
  }

  const { currentPassword, newPassword } = parse.data;

  try {
    const user = await queryOne('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    const match = await bcrypt.compare(currentPassword, user.password_hash);
    if (!match) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    const now = new Date().toISOString();
    await query('UPDATE users SET password_hash = ?, updated_date = ? WHERE id = ?', [newHash, now, req.user.id]);

    return res.json({ ok: true, message: 'Password changed successfully' });
  } catch (err) {
    console.error('Change password error:', err);
    return res.status(500).json({ error: 'Could not change password' });
  }
});

// POST /api/auth/reset-password-request
router.post('/reset-password-request', (req, res) => {
  // Always return success even if email not configured / found
  return res.json({ ok: true, message: 'If an account exists, a reset link will be sent.' });
});

// POST /api/auth/reset-password
router.post('/reset-password', (req, res) => {
  return res.status(400).json({ error: 'Password reset via email is not configured in this environment.' });
});

export default router;
