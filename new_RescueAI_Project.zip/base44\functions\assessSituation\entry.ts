import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const DISASTER_TYPES = ['flood', 'earthquake', 'fire', 'cyclone'];
const PHASES = ['Immediate (0-1 h)', 'Next 1-6 h', '6-24 h', 'Recovery (1-7 days)'];
const TEAM_SHARE = { low: 0.25, medium: 0.5, high: 0.8, critical: 1 };
const EXPOSURE = { flood: 0.08, cyclone: 0.1, earthquake: 0.12, fire: 0.01 };
const TYPE_TERMS = {
  flood: 'water rising flooding evacuation boats wading submerged rainfall',
  earthquake: 'collapse rubble aftershock structural trapped',
  fire: 'smoke burning flames evacuation wind',
  cyclone: 'wind storm surge landfall shelter debris gusts'
};
const STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'people', 'person', 'persons', 'after', 'near', 'area', 'that',
  'this', 'from', 'into', 'have', 'been', 'are', 'was', 'were', 'over', 'than', 'their', 'there',
  'about', 'around', 'also', 'very', 'more', 'some', 'which', 'will', 'when', 'they', 'them'
]);

function num(value: any, fallback: number) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function wholeNumber(value: any, minimum: number, maximum: number, fallback: number | null) {
  if (value === null || value === undefined || value === '' || typeof value === 'boolean') return fallback;
  const n = num(value, NaN);
  if (!Number.isFinite(n) || n < minimum || n > maximum) return fallback;
  return Math.round(n);
}

function severityFor(score: number) {
  if (score > 10) return 'critical';
  if (score > 7) return 'high';
  if (score >= 4) return 'medium';
  return 'low';
}

function sigmoid(x: number) {
  return 1 / (1 + Math.exp(-x));
}

function probabilitiesFor(score: number) {
  const spread = 0.9;
  const ge4 = sigmoid((score - 4) / spread);
  const ge7 = sigmoid((score - 7) / spread);
  const ge10 = sigmoid((score - 10) / spread);
  const pct: any = {
    low: Math.round((1 - ge4) * 100),
    medium: Math.round((ge4 - ge7) * 100),
    high: Math.round((ge7 - ge10) * 100),
    critical: Math.round(ge10 * 100)
  };
  const keys = ['low', 'medium', 'high', 'critical'];
  const diff = 100 - keys.reduce((sum, key) => sum + pct[key], 0);
  if (diff !== 0) {
    const largest = keys.reduce((best, key) => (pct[key] > pct[best] ? key : best), 'low');
    pct[largest] = Math.max(0, pct[largest] + diff);
  }
  return pct;
}

function weatherNote(rainfall: number) {
  const r = Math.round(rainfall);
  if (r < 20) return `Light rainfall (${r} mm in 24 h). Water levels should stay manageable, but keep watching upstream gauges.`;
  if (r < 100) return `Moderate rainfall (${r} mm in 24 h). Expect waterlogged roads and slower movement for rescue convoys.`;
  if (r < 250) return `Heavy rainfall (${r} mm in 24 h). Flash flooding and landslides are likely, so keep travel to essential rescue convoys only.`;
  return `Extreme rainfall (${r} mm in 24 h). Life-threatening flooding is expected, so move people to high ground immediately.`;
}

function tokenize(text: any) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((word) => word.length > 3 && !STOPWORDS.has(word));
}

function rankGuidelines(guidelines: any[], query: string) {
  const queryTokens = new Set(tokenize(query));
  return guidelines
    .map((guideline) => {
      const tokens = new Set(tokenize(`${guideline.title} ${guideline.text}`));
      let overlap = 0;
      queryTokens.forEach((token) => {
        if (tokens.has(token)) overlap += 1;
      });
      return { guideline, overlap };
    })
    .sort((a, b) => b.overlap - a.overlap || String(a.guideline.title).localeCompare(String(b.guideline.title)))
    .slice(0, 4)
    .map((entry) => ({
      title: String(entry.guideline.title || ''),
      text: String(entry.guideline.text || ''),
      disaster_type: String(entry.guideline.disaster_type || 'general')
    }));
}

function cleanStringList(value: any, max: number, length: number) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item) => typeof item === 'string' && item.trim().length > 0)
    .map((item) => item.trim().slice(0, length))
    .slice(0, max);
}

function normaliseTimeline(value: any) {
  if (!Array.isArray(value)) return null;
  const byPhase: any = {};
  value.forEach((entry: any) => {
    const phaseName = String(entry?.phase || '');
    const matched = PHASES.find((phase) => phase.toLowerCase() === phaseName.toLowerCase()) ||
      PHASES.find((phase) => phaseName.toLowerCase().includes(phase.split(' ')[0].toLowerCase()));
    if (!matched) return;
    const actions = (Array.isArray(entry?.actions) ? entry.actions : [])
      .map((action: any) => ({
        action: String(action?.action || '').trim().slice(0, 200),
        owner: String(action?.owner || 'Rescue team').trim().slice(0, 60),
        priority: ['high', 'medium', 'low'].includes(action?.priority) ? action.priority : 'medium'
      }))
      .filter((action: any) => action.action.length > 0);
    if (actions.length === 0) return;
    byPhase[matched] = byPhase[matched] || [];
    byPhase[matched] = byPhase[matched].concat(actions).slice(0, 5);
  });

  const ordered = PHASES.filter((phase) => byPhase[phase]?.length).map((phase) => ({
    phase,
    actions: byPhase[phase]
  }));
  if (ordered.length < 2) return null;
  return ordered;
}

function normalisePlan(candidate: any, hospitals: any[], resources: any) {
  if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) return null;

  const headline = typeof candidate.headline === 'string' ? candidate.headline.trim().slice(0, 200) : '';
  const severityReason = typeof candidate.severity_reason === 'string' ? candidate.severity_reason.trim().slice(0, 600) : '';
  const timeline = normaliseTimeline(candidate.timeline);
  if (!headline || !severityReason || !timeline) return null;

  const riskAlerts = (Array.isArray(candidate.risk_alerts) ? candidate.risk_alerts : [])
    .map((alert: any) => ({
      level: ['info', 'warning', 'danger'].includes(alert?.level) ? alert.level : 'info',
      text: String(alert?.text || '').trim().slice(0, 200)
    }))
    .filter((alert: any) => alert.text.length > 0)
    .slice(0, 6);

  let deployment = (Array.isArray(candidate.team_deployment) ? candidate.team_deployment : [])
    .map((row: any) => ({
      zone_or_task: String(row?.zone_or_task || '').trim().slice(0, 120),
      teams_assigned: Math.max(0, Math.round(num(row?.teams_assigned, 0)))
    }))
    .filter((row: any) => row.zone_or_task.length > 0)
    .slice(0, 6);

  const target = Math.max(0, Math.round(Number(resources.teams_to_deploy) || 0));
  const deployed = deployment.reduce((sum, row) => sum + row.teams_assigned, 0);
  if (deployment.length === 0 && target > 0) {
    deployment = [{ zone_or_task: 'Primary impact zone', teams_assigned: target }];
  } else if (target > 0 && deployed !== target) {
    deployment[deployment.length - 1].teams_assigned = Math.max(
      0,
      deployment[deployment.length - 1].teams_assigned + (target - deployed)
    );
  }

  const allowedNames = hospitals.map((hospital) => String(hospital.name || '').toLowerCase());
  const routing = (Array.isArray(candidate.hospital_routing) ? candidate.hospital_routing : [])
    .map((row: any) => ({
      hospital_name: String(row?.hospital_name || '').trim().slice(0, 140),
      role: String(row?.role || '').trim().slice(0, 80),
      reason: String(row?.reason || '').trim().slice(0, 240)
    }))
    .filter((row: any) => row.hospital_name && allowedNames.includes(row.hospital_name.toLowerCase()))
    .slice(0, 4);

  const planResources = {
    teams_to_deploy: Math.max(0, Math.round(num(candidate?.resources?.teams_to_deploy, resources.teams_to_deploy))),
    medical_units: Math.max(0, Math.round(num(candidate?.resources?.medical_units, resources.medical_units))),
    shelter_capacity: Math.max(0, Math.round(num(candidate?.resources?.shelter_capacity, resources.shelter_capacity))),
    water_litres_per_day: Math.max(0, Math.round(num(candidate?.resources?.water_litres_per_day, resources.water_litres_per_day))),
    food_packets_per_day: Math.max(0, Math.round(num(candidate?.resources?.food_packets_per_day, resources.food_packets_per_day)))
  };

  return {
    headline,
    severity_reason: severityReason,
    risk_alerts: riskAlerts,
    timeline,
    team_deployment: deployment,
    hospital_routing: routing,
    evacuation_advice: String(candidate.evacuation_advice || '').trim().slice(0, 600),
    public_message: String(candidate.public_message || '').trim().slice(0, 500),
    resources: planResources,
    success_metrics: cleanStringList(candidate.success_metrics, 3, 160),
    assumptions: cleanStringList(candidate.assumptions, 6, 220),
    guidelines_used: cleanStringList(candidate.guidelines_used, 4, 140)
  };
}

function rulePlan(ctx: any) {
  const {
    disasterType, location, severity, resources, weather, hospitals, affectedSource, injuredSource, guidelines
  } = ctx;

  const label = severity.charAt(0).toUpperCase() + severity.slice(1);
  const rain = Math.round(num(weather?.rainfall_last_24h, 0));
  const gusts = Math.round(num(weather?.wind_gusts, 0));
  const primary = hospitals[0];
  const secondary = hospitals[1];

  const alerts = [];
  if (weather?.weather_risk === 'high' || weather?.weather_risk === 'extreme') {
    alerts.push({ level: 'danger', text: `${rain} mm of rain in the last 24 h — flash flooding is likely.` });
  } else if (weather?.weather_risk === 'moderate') {
    alerts.push({ level: 'warning', text: `${rain} mm of rain recorded — expect waterlogged access roads.` });
  }
  if (gusts > 60) alerts.push({ level: 'danger', text: `Wind gusts of ${gusts} km/h — secure loose structures and halt boat operations if unsafe.` });
  if (num(weather?.apparent_temperature, 0) > 40) alerts.push({ level: 'warning', text: 'Feels-like temperature above 40 °C — plan water and shade for responders.' });
  if (affectedSource === 'estimated' || injuredSource === 'estimated') {
    alerts.push({ level: 'info', text: 'Casualty figures are estimates from population exposure — replace with field reports when available.' });
  }
  if (hospitals.length === 0) alerts.push({ level: 'warning', text: 'No hospital could be confirmed nearby — verify the receiving facility by radio.' });

  const timeline = [
    {
      phase: PHASES[0],
      actions: [
        { action: `Stand up an incident command post for ${location} and name one incident commander.`, owner: 'Local authority', priority: 'high' },
        { action: `Deploy ${resources.teams_to_deploy} rescue team(s) to the highest-density impact zone with cutting and flotation gear.`, owner: 'Rescue team', priority: 'high' },
        resources.medical_units > 0
          ? { action: `Send ${resources.medical_units} medical unit(s) to triage casualties at the assembly point.`, owner: 'Medical', priority: 'high' }
          : { action: 'Keep one medical unit on standby at the assembly point.', owner: 'Medical', priority: 'medium' },
        { action: 'Broadcast the public alert with shelter locations and a helpline number.', owner: 'Local authority', priority: 'medium' }
      ]
    },
    {
      phase: PHASES[1],
      actions: [
        { action: 'Search the priority buildings identified in the first sweep and mark each one searched.', owner: 'Rescue team', priority: 'high' },
        { action: primary ? `Start casualty transfer to ${primary.name} (${primary.distance_km} km).` : 'Confirm a receiving hospital and open a casualty transfer route.', owner: 'Medical', priority: 'high' },
        { action: 'Close flooded or debris-blocked routes and publish the diversion for responders.', owner: 'Police', priority: 'medium' }
      ]
    },
    {
      phase: PHASES[2],
      actions: [
        { action: `Open shelter capacity for about ${resources.shelter_capacity} people and register every arrival.`, owner: 'Local authority', priority: 'high' },
        { action: `Stage ${resources.water_litres_per_day} litres of water and ${resources.food_packets_per_day} food packets for the next 24 hours.`, owner: 'Logistics', priority: 'medium' },
        { action: 'Confirm every open SOS and assessment from the area is either resolved or assigned.', owner: 'Rescue team', priority: 'medium' }
      ]
    },
    {
      phase: PHASES[3],
      actions: [
        { action: 'Assess structural safety before letting residents return home.', owner: 'Local authority', priority: 'medium' },
        { action: 'Restore power, water and mobile coverage in the impact zone.', owner: 'Local authority', priority: 'medium' },
        { action: secondary ? `Resume routine services at ${secondary.name} and restock medical supplies.` : 'Restock medical supplies at the receiving facility.', owner: 'Medical', priority: 'low' }
      ]
    }
  ];

  const routing = hospitals.slice(0, 3).map((hospital: any, index: number) => ({
    hospital_name: hospital.name,
    role: index === 0 ? 'Primary casualty destination' : index === 1 ? 'Secondary overflow' : 'Specialist referral',
    reason: `${hospital.distance_km} km from the incident${hospital.emergency ? ', has an emergency department' : ''}.`
  }));

  const deployment = [
    { zone_or_task: 'Primary impact zone — rescue sweep', teams_assigned: Math.max(1, Math.ceil(resources.teams_to_deploy * 0.6)) },
    { zone_or_task: 'Evacuation and shelter transfer', teams_assigned: Math.max(0, Math.floor(resources.teams_to_deploy * 0.3)) },
    { zone_or_task: 'Logistics and medical support', teams_assigned: Math.max(0, resources.teams_to_deploy - Math.max(1, Math.ceil(resources.teams_to_deploy * 0.6)) - Math.floor(resources.teams_to_deploy * 0.3)) }
  ].filter((row) => row.teams_assigned > 0);

  const deployed = deployment.reduce((sum, row) => sum + row.teams_assigned, 0);
  const target = Math.max(0, resources.teams_to_deploy);
  if (deployment.length > 0 && deployed !== target) {
    deployment[deployment.length - 1].teams_assigned += target - deployed;
  }

  return {
    headline: `${label} severity ${disasterType} response for ${location}`,
    severity_reason: `A risk score of ${ctx.score} puts this incident in the ${severity} band, driven by ${ctx.peopleAffected} people affected, ${ctx.peopleInjured} injured and a damage score of ${ctx.damageScore}/10. Rainfall of ${rain} mm and ${gusts} km/h gusts are weighed against ${ctx.teamsAvailable} available teams.`,
    risk_alerts: alerts.slice(0, 6),
    timeline,
    team_deployment: deployment,
    hospital_routing: routing,
    evacuation_advice:
      weather?.weather_risk === 'high' || weather?.weather_risk === 'extreme'
        ? 'Move people to high ground on foot along marked routes, avoid low-lying underpasses and river crossings, and keep boats for the last stage of the evacuation.'
        : 'Evacuate on foot or by road away from the hazard, keep one mapped corridor open for ambulances and turn off gas and power before leaving.',
    public_message: `${label} ${disasterType} alert for ${location}. Move to the nearest shelter on high ground, carry water and medicines, and call the helpline if you are trapped. Rescue teams are being deployed — stay where you are if it is safe and make yourself visible.`,
    resources: {
      teams_to_deploy: resources.teams_to_deploy,
      medical_units: resources.medical_units,
      shelter_capacity: resources.shelter_capacity,
      water_litres_per_day: resources.water_litres_per_day,
      food_packets_per_day: resources.food_packets_per_day
    },
    success_metrics: [
      'All reported casualties triaged within 2 hours of first team arrival.',
      'Every at-risk household reached by a search sweep within 6 hours.',
      'Shelter, water and food in place for the full estimated displaced population within 24 hours.'
    ],
    assumptions: [
      affectedSource === 'estimated' ? 'People affected is a population-exposure estimate, not a field count.' : 'People affected was entered manually by the operator.',
      injuredSource === 'estimated' ? 'People injured is estimated at 2% of people affected.' : 'People injured came from the entered or extracted figure.',
      hospitals.length === 0 ? 'No nearby hospital was confirmed, so routing uses generic guidance.' : 'Hospital distances come from OpenStreetMap and may be road distances in reality.',
      'Team availability reflects what was entered at assessment time.'
    ],
    guidelines_used: guidelines.map((guideline: any) => guideline.title)
  };
}

const PLAN_SCHEMA = {
  type: 'object',
  properties: {
    headline: { type: 'string' },
    severity_reason: { type: 'string' },
    risk_alerts: {
      type: 'array',
      items: {
        type: 'object',
        properties: { level: { type: 'string', enum: ['info', 'warning', 'danger'] }, text: { type: 'string' } },
        required: ['level', 'text']
      }
    },
    timeline: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          phase: { type: 'string' },
          actions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                action: { type: 'string' },
                owner: { type: 'string' },
                priority: { type: 'string', enum: ['high', 'medium', 'low'] }
              },
              required: ['action', 'owner', 'priority']
            }
          }
        },
        required: ['phase', 'actions']
      }
    },
    team_deployment: {
      type: 'array',
      items: {
        type: 'object',
        properties: { zone_or_task: { type: 'string' }, teams_assigned: { type: 'number' } },
        required: ['zone_or_task', 'teams_assigned']
      }
    },
    hospital_routing: {
      type: 'array',
      items: {
        type: 'object',
        properties: { hospital_name: { type: 'string' }, role: { type: 'string' }, reason: { type: 'string' } },
        required: ['hospital_name', 'role', 'reason']
      }
    },
    evacuation_advice: { type: 'string' },
    public_message: { type: 'string' },
    resources: {
      type: 'object',
      properties: {
        teams_to_deploy: { type: 'number' },
        medical_units: { type: 'number' },
        shelter_capacity: { type: 'number' },
        water_litres_per_day: { type: 'number' },
        food_packets_per_day: { type: 'number' }
      },
      required: ['teams_to_deploy', 'medical_units', 'shelter_capacity', 'water_litres_per_day', 'food_packets_per_day']
    },
    success_metrics: { type: 'array', items: { type: 'string' } },
    assumptions: { type: 'array', items: { type: 'string' } },
    guidelines_used: { type: 'array', items: { type: 'string' } }
  },
  required: [
    'headline', 'severity_reason', 'risk_alerts', 'timeline', 'team_deployment', 'hospital_routing',
    'evacuation_advice', 'public_message', 'resources', 'success_metrics', 'assumptions', 'guidelines_used'
  ]
};

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    const disasterType = typeof body?.disaster_type === 'string' ? body.disaster_type.toLowerCase().trim() : '';
    if (!DISASTER_TYPES.includes(disasterType)) {
      return Response.json({ error: 'Choose a valid disaster type.' }, { status: 400 });
    }

    const location = typeof body?.location === 'string' ? body.location.trim().slice(0, 200) : '';
    if (!location) return Response.json({ error: 'Location is required.' }, { status: 400 });

    const damageScore = num(body?.damage_score, NaN);
    const teamsAvailable = wholeNumber(body?.teams_available, 0, 10000, null);

    if (!Number.isFinite(damageScore) || damageScore < 0 || damageScore > 10) {
      return Response.json({ error: 'Damage score must be between 0 and 10.' }, { status: 400 });
    }
    if (teamsAvailable === null) {
      return Response.json({ error: 'Rescue teams available must be 0 or more.' }, { status: 400 });
    }

    const weather = body?.weather && typeof body.weather === 'object' ? body.weather : {};
    const hospitals = (Array.isArray(body?.hospitals) ? body.hospitals : []).slice(0, 8);
    const news = (Array.isArray(body?.news) ? body.news : []).slice(0, 6);
    const population = num(body?.population, 0);

    let affectedSource = String(body?.affected_source || 'manual');
    let injuredSource = String(body?.injured_source || 'manual');
    let peopleAffected = wholeNumber(body?.people_affected, 0, 100000000, null);
    let peopleInjured = wholeNumber(body?.people_injured, 0, 100000000, null);
    const rawRainfall = body?.rainfall;
    let rainfall =
      rawRainfall === null || rawRainfall === undefined || rawRainfall === '' ? NaN : num(rawRainfall, NaN);

    if (!Number.isFinite(rainfall) || rainfall < 0) {
      rainfall = Math.max(0, num(weather?.rainfall_last_24h, 0));
    }

    if (peopleAffected === null) {
      if (population > 0) {
        peopleAffected = Math.max(50, Math.round(population * EXPOSURE[disasterType] * (0.4 + damageScore / 12.5)));
        affectedSource = 'estimated';
      } else {
        return Response.json(
          { error: 'People affected is required — there was no population data to estimate from.' },
          { status: 400 }
        );
      }
    }
    if (peopleInjured === null) {
      peopleInjured = Math.max(peopleAffected > 0 ? 1 : 0, Math.round(peopleAffected * 0.02));
      injuredSource = 'estimated';
    }
    if (peopleInjured > peopleAffected) peopleInjured = peopleAffected;

    const rainWeight = disasterType === 'flood' || disasterType === 'cyclone' ? 1 : 0.2;
    const rawScore =
      Math.log(1 + peopleAffected) * 0.45 +
      Math.log(1 + peopleInjured) * 0.55 +
      damageScore * 0.55 +
      (rainfall / 100) * rainWeight -
      Math.log(1 + teamsAvailable) * 0.45;
    const score = Math.round(Math.max(0, rawScore) * 100) / 100;
    const severity = severityFor(score);
    const probabilities = probabilitiesFor(score);

    const resources = {
      teams_to_deploy: teamsAvailable > 0 ? Math.max(1, Math.round(teamsAvailable * TEAM_SHARE[severity])) : 0,
      medical_units: Math.max(1, Math.ceil(peopleInjured / 150)),
      shelter_capacity: Math.round(peopleAffected * 0.6),
      water_litres_per_day: Math.round(peopleAffected * 15),
      food_packets_per_day: Math.round(peopleAffected * 3)
    };

    let guidelines: any[] = [];
    try {
      const page = await base44.entities.Guideline.filter(
        { disaster_type: { $in: [disasterType, 'general'] } },
        { limit: 60 }
      );
      const query = [
        disasterType,
        location,
        severity,
        TYPE_TERMS[disasterType] || '',
        weather?.weather_risk ? `${weather.weather_risk} rainfall` : '',
        'affected injured rainfall damage rescue teams'
      ].join(' ');
      guidelines = rankGuidelines(page?.items || [], query);
    } catch {
      guidelines = [];
    }

    const ctx = {
      disasterType,
      location,
      severity,
      score,
      probabilities,
      resources,
      weather,
      hospitals,
      guidelines,
      peopleAffected,
      peopleInjured,
      damageScore,
      teamsAvailable,
      affectedSource,
      injuredSource
    };

    const fallback = rulePlan(ctx);
    let plan = fallback;
    let planSource = 'rule';

    try {
      const guidelineText = guidelines
        .map((guideline, index) => `${index + 1}. ${guideline.title}: ${String(guideline.text).slice(0, 380)}`)
        .join('\n');
      const hospitalText = hospitals.length
        ? hospitals
            .map((hospital: any) => `- ${hospital.name} · ${hospital.distance_km} km · ${hospital.phone || 'no phone'} · ${hospital.emergency ? 'emergency department' : 'no emergency tag'}`)
            .join('\n')
        : 'None found.';
      const newsText = news.length ? news.map((item: any) => `- ${item.title} (${item.domain || 'source'})`).join('\n') : 'No recent articles.';

      const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `You are the operations planner for a disaster response team in India. Build an actionable rescue plan.

SITUATION
- Disaster: ${disasterType}
- Place: ${location}
- Modelled severity: ${severity} (risk score ${score}; probabilities low ${probabilities.low}%, medium ${probabilities.medium}%, high ${probabilities.high}%, critical ${probabilities.critical}%)
- People affected: ${peopleAffected} (source: ${ctx.affectedSource})
- People injured: ${peopleInjured} (source: ${ctx.injuredSource})
- Rainfall last 24 h: ${rainfall} mm; next 24 h: ${num(weather?.rainfall_next_24h, 0)} mm
- Weather now: ${weather?.condition || 'unknown'}, ${num(weather?.temperature, 0)} °C, wind ${num(weather?.wind_speed, 0)} km/h, gusts ${num(weather?.wind_gusts, 0)} km/h, risk ${weather?.weather_risk || 'unknown'}
- Population near the site: ${population || 'unknown'}
- Damage score: ${damageScore}/10
- Rescue teams available: ${teamsAvailable} (deploy exactly ${resources.teams_to_deploy})

NEARBY HOSPITALS (only these may be named)
${hospitalText}

RECENT NEWS HEADLINES
${newsText}

APPROVED GUIDELINES
${guidelineText || 'No guidelines retrieved.'}

INSTRUCTIONS
- Use ONLY the facts provided. Do not invent hospitals, phone numbers, road names or casualty figures.
- Only recommend hospitals from the list above, by exact name.
- Cite which guideline titles you used in guidelines_used.
- If data is missing, say so in assumptions.
- Be specific and concise: each action is one imperative sentence under 22 words with an owner (Rescue team, Medical, Police, Local authority, Logistics).
- team_deployment teams_assigned must sum exactly to ${resources.teams_to_deploy}.
- public_message must be a 2-3 sentence SMS-ready alert for residents.
- success_metrics: exactly 3 short measurable goals.`,
        response_json_schema: PLAN_SCHEMA
      });

      const normalised = normalisePlan(aiResult, hospitals, resources);
      if (normalised) {
        plan = normalised;
        planSource = 'ai';
      }
    } catch {
      plan = fallback;
      planSource = 'rule';
    }

    return Response.json({
      severity,
      score,
      probabilities,
      people_affected: peopleAffected,
      people_injured: peopleInjured,
      rainfall,
      resources: plan.resources,
      weather_note: weatherNote(rainfall),
      guidelines,
      plan,
      plan_source: planSource,
      summary: plan.headline,
      priority_actions: plan.timeline[0]?.actions.map((action: any) => action.action) || []
    });
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Could not analyse this situation.' }, { status: 500 });
  }
}
