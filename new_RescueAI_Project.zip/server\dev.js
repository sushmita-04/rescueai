import { spawn } from 'child_process';
import path from 'path';

console.log('Starting RescueAI backend server and Vite dev frontend...');

const isWindows = process.platform === 'win32';
if (isWindows) {
  const sysRoot = process.env.SystemRoot || 'C:\\Windows';
  process.env.ComSpec = path.join(sysRoot, 'System32', 'cmd.exe');
}
const nodeCmd = isWindows ? 'node.exe' : 'node';
const viteBin = path.resolve(process.cwd(), 'node_modules', 'vite', 'bin', 'vite.js');

// Backend server process
const apiPort = process.env.API_PORT || '5001';
const serverProcess = spawn(nodeCmd, ['server/index.js'], {
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: apiPort
  }
});

// Vite frontend process
// In Replit, webview listens on PORT (e.g. 3000 or 5173). Default to 5173 or 3000.
const vitePort = process.env.PORT && process.env.PORT !== apiPort ? process.env.PORT : '5173';
const viteProcess = spawn(nodeCmd, [viteBin, '--host', '0.0.0.0', '--port', vitePort], {
  stdio: 'inherit',
  env: {
    ...process.env,
    API_TARGET: `http://localhost:${apiPort}`
  }
});

function cleanup() {
  serverProcess.kill();
  viteProcess.kill();
  process.exit();
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('exit', cleanup);
