import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

dotenv.config();

let pgPool = null;
let sqliteDb = null;

export async function getDb() {
  const isPostgres = Boolean(process.env.DATABASE_URL);
  if (isPostgres) {
    if (!pgPool) {
      if (process.env.DATABASE_URL.includes('neon.tech')) {
        const { Pool, neonConfig } = await import('@neondatabase/serverless');
        const ws = (await import('ws')).default;
        neonConfig.webSocketConstructor = ws;
        pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
      } else {
        const { Pool } = await import('pg');
        const needsSsl =
          process.env.DATABASE_URL.includes('sslmode=require') ||
          (process.env.NODE_ENV === 'production' && !process.env.DATABASE_URL.includes('localhost'));

        pgPool = new Pool({
          connectionString: process.env.DATABASE_URL,
          ssl: needsSsl ? { rejectUnauthorized: false } : false
        });
      }
    }
    return { type: 'pg', pool: pgPool };
  } else {
    if (!sqliteDb) {
      const { DatabaseSync } = await import('node:sqlite');
      const dbPath = path.resolve(process.cwd(), 'rescueai.db');
      sqliteDb = new DatabaseSync(dbPath);
      try {
        sqliteDb.exec('PRAGMA journal_mode = WAL;');
        sqliteDb.exec('PRAGMA busy_timeout = 5000;');
      } catch (err) {
        // ignore
      }
    }
    return { type: 'sqlite', db: sqliteDb };
  }
}

// Unified query helper
export async function query(sql, params = []) {
  const db = await getDb();
  if (db.type === 'pg') {
    // Convert ? placeholders to $1, $2, etc. for pg
    let pIndex = 1;
    const pgSql = sql.replace(/\?/g, () => `$${pIndex++}`);
    try {
      const res = await db.pool.query(pgSql, params);
      return res.rows;
    } catch (err) {
      if (
        err.message &&
        (err.message.includes('not queryable') ||
          err.message.includes('closed') ||
          err.message.includes('Connection terminated') ||
          err.message.includes('Socket closed') ||
          err.message.includes('ECONNRESET'))
      ) {
        console.warn('Neon connection idle reset detected. Re-establishing connection...');
        pgPool = null;
        const freshDb = await getDb();
        const res = await freshDb.pool.query(pgSql, params);
        return res.rows;
      }
      throw err;
    }
  } else {
    const stmt = db.db.prepare(sql);
    if (sql.trim().toUpperCase().startsWith('SELECT') || sql.toUpperCase().includes('RETURNING')) {
      return stmt.all(...params);
    } else {
      stmt.run(...params);
      return [];
    }
  }
}

export async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

export function newId(prefix = '') {
  const hex = crypto.randomBytes(8).toString('hex');
  return prefix ? `${prefix}_${hex}` : hex;
}

const DEFAULT_GUIDELINES = [
  // Flood
  {
    disaster_type: 'flood',
    title: 'Move to Highest Solid Ground & Avoid Moving Water',
    text: 'Never attempt to walk or drive through moving flood water. 15 cm of moving water can knock you down, and 60 cm will sweep a car away. Seek upper floors or high ground immediately. In urban floods, avoid basements and underground parking where entrapment risk is fatal.'
  },
  {
    disaster_type: 'flood',
    title: 'Shut Off Gas, Electricity and Submerged Utilities',
    text: 'If safe to do so, disconnect main electrical switches and gas valves before floodwaters enter. Avoid touching electrical equipment if you are wet or standing in water. Submerged transformers can electrify standing water over a 15-meter radius.'
  },
  {
    disaster_type: 'flood',
    title: 'Purify Drinking Water and Guard Food Stocks',
    text: 'Floodwaters carry sewage, industrial chemicals, and leptospirosis. Boil drinking water vigorously for at least one minute or use chlorine purification tablets. Discard any food that came into contact with floodwater. Store rations above anticipated flood levels.'
  },
  {
    disaster_type: 'flood',
    title: 'Boat Rescue & Swift Water Safety Standards',
    text: 'All rescue boat occupants must wear certified personal flotation devices (PFDs). Approach stranded victims from upstream or slack water. Never tie rescue boats to fragile balconies or compromised trees. Beware submerged debris, fences, and open manholes.'
  },
  // Earthquake
  {
    disaster_type: 'earthquake',
    title: 'Drop, Cover, and Hold On Protocol',
    text: 'When shaking starts, immediately Drop to your hands and knees, take Cover under a sturdy table or desk, and Hold On until shaking stops. Protect your head and neck. If no shelter is nearby, drop against an interior wall and cover head with arms.'
  },
  {
    disaster_type: 'earthquake',
    title: 'Stay Clear of Windows, Facades, and Glass',
    text: 'If indoors, stay inside. Glass windows, heavy furniture, light fixtures, and architectural facades are prime falling hazards. If outside, move to an open area away from buildings, powerlines, and trees. Do not enter damaged structures.'
  },
  {
    disaster_type: 'earthquake',
    title: 'Structural Collapse & Rubble Void Search',
    text: 'In collapsed masonry, search for survival voids under concrete slabs, stairwells, and sturdy furniture. Use acoustic sensors and thermal imagers before heavy excavation. Shore up leaning walls with timber or hydraulic jacks before entering collapsed spaces.'
  },
  {
    disaster_type: 'earthquake',
    title: 'Prepare for Aftershocks & Gas Leaks',
    text: 'Secondary tremors often follow the main quake within minutes to days. Evacuate severely damaged buildings cautiously using stairs, never elevators. Smell for gas leaks—if detected, ventilate windows and extinguish all open flames immediately.'
  },
  // Fire
  {
    disaster_type: 'fire',
    title: 'Stay Low Under Smoke and Toxic Gases',
    text: 'Smoke and toxic carbon monoxide rise and kill faster than flames. Crawl on your hands and knees where air is cooler and cleaner. Cover your nose and mouth with a damp cloth if possible. Keep doors closed behind you to slow fire spread.'
  },
  {
    disaster_type: 'fire',
    title: 'Check Doors for Heat Before Opening',
    text: 'Feel the door handle and door surface with the back of your hand. If hot, do not open it—the fire is directly on the other side. Seek an alternate exit or seal gaps around the door with wet towels and signal rescuers at a window.'
  },
  {
    disaster_type: 'fire',
    title: 'Stop, Drop, and Roll for Clothing Fires',
    text: 'Do not run, as running fans flames. Drop immediately to the ground, cover your face with your hands, and roll back and forth to extinguish flames. Smother fire with heavy blankets or jackets if assisting others.'
  },
  {
    disaster_type: 'fire',
    title: 'Mass Burn Casualty Stabilization & Triage',
    text: 'Cool thermal burns with clean running water for at least 10 minutes. Do not apply ice, butter, or ointments. Cover burns with clean sterile non-adherent dressings. Prioritize inhalation injuries with airway stridor for immediate intubation and oxygen.'
  },
  // Cyclone
  {
    disaster_type: 'cyclone',
    title: 'Secure Strong Structural Shelter',
    text: 'Shelter in the strongest part of the building (interior room, hallway, or bathroom without windows) on the lowest floor above storm surge risk. Tape or shutter glass windows. Keep emergency battery radios tuned to disaster broadcast frequencies.'
  },
  {
    disaster_type: 'cyclone',
    title: 'Beware the Calm Eye of the Storm',
    text: 'If the wind abruptly dies down, you may be in the cyclone eye. Do not leave shelter—winds will return suddenly from the opposite direction with equal or greater ferocity. Remain in designated safe zones until official all-clear is issued.'
  },
  {
    disaster_type: 'cyclone',
    title: 'Storm Surge Inundation Evacuation Protocol',
    text: 'Coastal storm surges can rise 3 to 6 meters within minutes. Follow mandatory evacuation orders to designated cyclone relief centers located inland on elevated ground. Disconnect all external antennas and power lines before departing.'
  },
  {
    disaster_type: 'cyclone',
    title: 'Road Clearance & Downed Wire Safety',
    text: 'High-speed winds bring down live electric wires, trees, and mobile towers. Treat every downed wire as live and lethal. Keep a minimum 10-meter clearance. Deploy industrial chainsaws and heavy earthmovers to clear arterial ambulance lanes.'
  },
  // Landslide
  {
    disaster_type: 'landslide',
    title: 'Early Warning Signs of Slope Instability',
    text: 'Listen for unusual sounds like trees cracking, boulders knocking together, or sudden changes in stream water from clear to muddy. Watch for tilting utility poles, widening ground fissures, and jammed doors or windows indicating foundation movement.'
  },
  {
    disaster_type: 'landslide',
    title: 'Rapid Lateral Evacuation from Debris Flow Path',
    text: 'If a mudslide or rockfall approaches, run laterally across the slope away from the path of flow, never downhill in the direction of the slide. Seek shelter behind large trees or solid rock outcroppings if escape is impossible.'
  },
  {
    disaster_type: 'landslide',
    title: 'Earth Extrication & Slope Stabilization',
    text: 'In residential landslide burials, establish an uphill observation lookout for secondary slides. Use manual trenching tools and light excavators to prevent crushing buried survivors. Shore unstable cut slopes before deploying deep rescue teams.'
  },
  // Medical & Mass Casualty
  {
    disaster_type: 'medical',
    title: 'START Mass Casualty Triage Protocol',
    text: 'Triage victims into 4 color categories: Immediate/Red (airway compromise, severe hemorrhage, shock), Delayed/Yellow (fractures, controlled wounds), Minimal/Green (walking wounded), Expectant/Black (no respiration after airway repositioning).'
  },
  {
    disaster_type: 'medical',
    title: 'Field Hemorrhage & Trauma Stabilization',
    text: 'Apply high-and-tight arterial tourniquets for severe extremity bleeding; note time of application. Stabilize cervical spine and splint major bone fractures before transport. Administer warmed IV fluids and high-flow oxygen for critical patients.'
  },
  // General
  {
    disaster_type: 'general',
    title: 'Conserve Phone Battery and Use Text/Data',
    text: 'During mass casualty events, cellular voice networks become overwhelmed. Keep voice calls to life-and-death situations only; use text messages, SOS coordinates, or offline radios.'
  },
  {
    disaster_type: 'general',
    title: 'Incident Command System (ICS) Field Coordination',
    text: 'Establish a unified field command post outside the hazard perimeter. Assign distinct staging areas for rescue teams, ambulance triage, and civilian evacuees. Maintain regular 30-minute situation reports (SITREPs) with district authorities.'
  }
];

const DEFAULT_RESCUE_TEAMS = [
  {
    id: 'team_ndrf_10',
    name: 'NDRF 10th Battalion (Aquatic Disaster & Flood Response)',
    specialty: 'flood',
    base_location: 'Regional Coastal & Riverine Sector Base',
    status: 'available',
    personnel_count: 45,
    equipment: 'Motorized Inflatable Boats (IRB), Lifebuoys, Deep Submersible Pumps, Sonar Life Detectors, Satellite Comms',
    contact_phone: '+91-11-24363260',
    lead_officer: 'Commandant R. K. Verma'
  },
  {
    id: 'team_sdrf_usar',
    name: 'SDRF Urban Search and Rescue (USAR Structural Collapse Unit)',
    specialty: 'earthquake',
    base_location: 'Central Disaster Management HQ',
    status: 'available',
    personnel_count: 35,
    equipment: 'Hydraulic Spreaders & Cutters, Acoustic Shoring Detectors, Rotary Diamond Concrete Saws, Search Canines',
    contact_phone: '+91-11-23438091',
    lead_officer: 'Deputy Controller P. Sharma'
  },
  {
    id: 'team_fire_hazmat',
    name: 'State Fire & HazMat Rapid Emergency Battalion',
    specialty: 'fire',
    base_location: 'Metropolitan Fire Service Division',
    status: 'available',
    personnel_count: 30,
    equipment: 'Water-Foam High-Capacity Tenders, SCBA Breathing Packs, Thermal Imaging Cameras, Turntable Rescue Ladders',
    contact_phone: '+91-11-23412222',
    lead_officer: 'Chief Fire Officer M. Das'
  },
  {
    id: 'team_cyclone_taskforce',
    name: 'NDRF Coastal Cyclone & Storm Surge Evacuation Wing',
    specialty: 'cyclone',
    base_location: 'Bay of Bengal Coastal Sector Base',
    status: 'available',
    personnel_count: 40,
    equipment: 'High-Clearance Transport Tenders, Industrial Chainsaws, Storm Evac Amphibious Trucks, VHF Radio Rigs',
    contact_phone: '+91-11-24363261',
    lead_officer: 'Asst. Commandant S. Nair'
  },
  {
    id: 'team_landslide_corps',
    name: 'Civil Defense Mountain & Landslide Rope Rescue Corps',
    specialty: 'landslide',
    base_location: 'Sub-Division Foothill Response Station',
    status: 'available',
    personnel_count: 25,
    equipment: 'Heavy Earthmover Excavators, High-Angle Rope Rigging, Slope Extrication Stretchers, Drone Geo-Scanners',
    contact_phone: '+91-11-24363265',
    lead_officer: 'Major A. Bhattacharya'
  },
  {
    id: 'team_medical_qmru',
    name: 'Quick Medical Response & Mass Trauma Triage Unit (QMRU)',
    specialty: 'medical',
    base_location: 'District Civil Hospital Trauma Center',
    status: 'available',
    personnel_count: 22,
    equipment: 'Advanced Life Support (ALS) Ambulances, Mobile ICU Field Tents, Oxygen Concentrators, Automated Defibrillators',
    contact_phone: '+91-11-23438095',
    lead_officer: 'Dr. Neha Kulkarni, Chief Trauma Surgeon'
  }
];

export async function initDatabase() {
  const db = await getDb();

  if (db.type === 'pg') {
    // PostgreSQL schema
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT,
        role TEXT DEFAULT 'public',
        staff_type TEXT DEFAULT '',
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS session (
        sid VARCHAR NOT NULL COLLATE "default",
        sess JSON NOT NULL,
        expire TIMESTAMP(6) NOT NULL,
        CONSTRAINT session_pkey PRIMARY KEY (sid)
      );
      CREATE INDEX IF NOT EXISTS IDX_session_expire ON session (expire);

      CREATE TABLE IF NOT EXISTS sos_requests (
        id TEXT PRIMARY KEY,
        reference_id TEXT UNIQUE NOT NULL,
        tracking_token TEXT NOT NULL,
        name TEXT,
        phone TEXT,
        situation TEXT,
        location_text TEXT,
        lat REAL,
        lng REAL,
        people_count INTEGER DEFAULT 0,
        note TEXT,
        audio_url TEXT,
        audio_duration REAL DEFAULT 0,
        priority TEXT DEFAULT 'normal',
        status TEXT DEFAULT 'new',
        handled_by TEXT,
        acknowledged_by_id TEXT,
        acknowledged_by TEXT,
        acknowledged_at TIMESTAMPTZ,
        first_seen_at TIMESTAMPTZ,
        first_seen_by_id TEXT,
        first_seen_by TEXT,
        dispatched_at TIMESTAMPTZ,
        eta_minutes INTEGER,
        resolved_at TIMESTAMPTZ,
        outcome TEXT,
        resolution_note TEXT,
        latest_message TEXT,
        transcript TEXT,
        photo_urls TEXT,
        created_by_id TEXT,
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS sos_events (
        id TEXT PRIMARY KEY,
        sos_id TEXT NOT NULL,
        type TEXT NOT NULL,
        status_from TEXT,
        status_to TEXT,
        actor_user_id TEXT,
        actor_name TEXT,
        note TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS assessments (
        id TEXT PRIMARY KEY,
        disaster_type TEXT NOT NULL,
        location TEXT NOT NULL,
        lat REAL,
        lng REAL,
        people_affected REAL DEFAULT 0,
        people_injured REAL DEFAULT 0,
        rainfall REAL DEFAULT 0,
        damage_score REAL DEFAULT 0,
        teams_available REAL DEFAULT 0,
        population REAL DEFAULT 0,
        affected_source TEXT,
        injured_source TEXT,
        severity TEXT NOT NULL,
        score REAL DEFAULT 0,
        probabilities JSONB,
        summary TEXT,
        priority_actions JSONB,
        teams_to_deploy REAL DEFAULT 0,
        medical_units REAL DEFAULT 0,
        shelter_places REAL DEFAULT 0,
        weather_note TEXT,
        plan_source TEXT,
        plan JSONB,
        weather JSONB,
        data_sources JSONB,
        news JSONB,
        hospitals JSONB,
        done_actions JSONB,
        created_by_id TEXT,
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS team_requests (
        id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        organization TEXT,
        phone TEXT,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_by_id TEXT,
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS guidelines (
        id TEXT PRIMARY KEY,
        disaster_type TEXT NOT NULL,
        title TEXT NOT NULL,
        text TEXT NOT NULL,
        created_by_id TEXT,
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS rescue_teams (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        base_location TEXT NOT NULL,
        status TEXT DEFAULT 'available',
        personnel_count INTEGER DEFAULT 20,
        equipment TEXT,
        contact_phone TEXT,
        lead_officer TEXT,
        lat REAL,
        lng REAL,
        created_date TIMESTAMPTZ DEFAULT NOW(),
        updated_date TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS cache (
        id TEXT PRIMARY KEY,
        key TEXT UNIQUE NOT NULL,
        payload JSONB NOT NULL,
        expires_at TIMESTAMPTZ NOT NULL,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);
  } else {
    // SQLite schema
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT,
        role TEXT DEFAULT 'public',
        staff_type TEXT DEFAULT '',
        gov_id TEXT,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS sessions (
        sid TEXT PRIMARY KEY,
        sess TEXT NOT NULL,
        expire INTEGER NOT NULL
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS sos_requests (
        id TEXT PRIMARY KEY,
        reference_id TEXT UNIQUE NOT NULL,
        tracking_token TEXT NOT NULL,
        name TEXT,
        phone TEXT,
        situation TEXT,
        location_text TEXT,
        lat REAL,
        lng REAL,
        people_count INTEGER DEFAULT 0,
        note TEXT,
        audio_url TEXT,
        audio_duration REAL DEFAULT 0,
        priority TEXT DEFAULT 'normal',
        status TEXT DEFAULT 'new',
        handled_by TEXT,
        acknowledged_by_id TEXT,
        acknowledged_by TEXT,
        acknowledged_at TEXT,
        first_seen_at TEXT,
        first_seen_by_id TEXT,
        first_seen_by TEXT,
        dispatched_at TEXT,
        eta_minutes INTEGER,
        resolved_at TEXT,
        outcome TEXT,
        resolution_note TEXT,
        latest_message TEXT,
        transcript TEXT,
        photo_urls TEXT,
        created_by_id TEXT,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS sos_events (
        id TEXT PRIMARY KEY,
        sos_id TEXT NOT NULL,
        type TEXT NOT NULL,
        status_from TEXT,
        status_to TEXT,
        actor_user_id TEXT,
        actor_name TEXT,
        note TEXT,
        created_at TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS assessments (
        id TEXT PRIMARY KEY,
        disaster_type TEXT NOT NULL,
        location TEXT NOT NULL,
        lat REAL,
        lng REAL,
        people_affected REAL DEFAULT 0,
        people_injured REAL DEFAULT 0,
        rainfall REAL DEFAULT 0,
        damage_score REAL DEFAULT 0,
        teams_available REAL DEFAULT 0,
        population REAL DEFAULT 0,
        affected_source TEXT,
        injured_source TEXT,
        severity TEXT NOT NULL,
        score REAL DEFAULT 0,
        probabilities TEXT,
        summary TEXT,
        priority_actions TEXT,
        teams_to_deploy REAL DEFAULT 0,
        medical_units REAL DEFAULT 0,
        shelter_places REAL DEFAULT 0,
        weather_note TEXT,
        plan_source TEXT,
        plan TEXT,
        weather TEXT,
        data_sources TEXT,
        news TEXT,
        hospitals TEXT,
        done_actions TEXT,
        created_by_id TEXT,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS team_requests (
        id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        organization TEXT,
        phone TEXT,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_by_id TEXT,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS guidelines (
        id TEXT PRIMARY KEY,
        disaster_type TEXT NOT NULL,
        title TEXT NOT NULL,
        text TEXT NOT NULL,
        created_by_id TEXT,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS rescue_teams (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        base_location TEXT NOT NULL,
        status TEXT DEFAULT 'available',
        personnel_count INTEGER DEFAULT 20,
        equipment TEXT,
        contact_phone TEXT,
        lead_officer TEXT,
        lat REAL,
        lng REAL,
        created_date TEXT,
        updated_date TEXT
      );
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS cache (
        id TEXT PRIMARY KEY,
        key TEXT UNIQUE NOT NULL,
        payload TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        updated_at TEXT
      );
    `);
  }

  // Seed guidelines if empty or updated
  const countRow = await queryOne('SELECT COUNT(*) as cnt FROM guidelines');
  const count = Number(countRow?.cnt || 0);
  if (count < DEFAULT_GUIDELINES.length) {
    const now = new Date().toISOString();
    for (const g of DEFAULT_GUIDELINES) {
      const existing = await queryOne('SELECT id FROM guidelines WHERE title = ?', [g.title]);
      if (!existing) {
        await query(
          'INSERT INTO guidelines (id, disaster_type, title, text, created_date, updated_date) VALUES (?, ?, ?, ?, ?, ?)',
          [newId('guide'), g.disaster_type, g.title, g.text, now, now]
        );
      }
    }
  }

  // Seed actual rescue teams
  const teamCountRow = await queryOne('SELECT COUNT(*) as cnt FROM rescue_teams');
  const teamCount = Number(teamCountRow?.cnt || 0);
  if (teamCount < DEFAULT_RESCUE_TEAMS.length) {
    const now = new Date().toISOString();
    for (const t of DEFAULT_RESCUE_TEAMS) {
      const existing = await queryOne('SELECT id FROM rescue_teams WHERE id = ?', [t.id]);
      if (!existing) {
        await query(
          `INSERT INTO rescue_teams (
            id, name, specialty, base_location, status, personnel_count,
            equipment, contact_phone, lead_officer, created_date, updated_date
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            t.id,
            t.name,
            t.specialty,
            t.base_location,
            t.status,
            t.personnel_count,
            t.equipment,
            t.contact_phone,
            t.lead_officer,
            now,
            now
          ]
        );
      }
    }
  }

  // Bootstrap Admin if no admin exists
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@rescueai.local').trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD || 'RescueAdmin123!';

  const existingAdmin = await queryOne("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
  if (!existingAdmin) {
    const existingUser = await queryOne('SELECT id FROM users WHERE email = ?', [adminEmail]);
    const hash = await bcrypt.hash(adminPassword, 10);
    const now = new Date().toISOString();
    if (existingUser) {
      await query(
        "UPDATE users SET role = 'admin', staff_type = 'rescue_team', password_hash = ?, updated_date = ? WHERE id = ?",
        [hash, now, existingUser.id]
      );
    } else {
      await query(
        "INSERT INTO users (id, email, password_hash, full_name, role, staff_type, created_date, updated_date) VALUES (?, ?, ?, ?, 'admin', 'rescue_team', ?, ?)",
        [newId('user'), adminEmail, hash, 'Administrator', now, now]
      );
    }
  }

  // Ensure photo_urls column exists on sos_requests
  try {
    await query('ALTER TABLE sos_requests ADD COLUMN photo_urls TEXT');
  } catch {
    // column already exists
  }

  // Ensure gov_id column exists
  try {
    await query('ALTER TABLE users ADD COLUMN gov_id TEXT');
  } catch {
    // column already exists
  }

  // Bootstrap Dedicated Rescue Team account
  const teamEmail = (process.env.RESCUE_TEAM_EMAIL || 'team@rescueai.local').trim().toLowerCase();
  const teamPassword = process.env.RESCUE_TEAM_PASSWORD || 'RescueTeam2026!';
  const teamGovId = (process.env.RESCUE_TEAM_GOV_ID || 'GOV-RESCUE-7701').trim();
  const existingTeam = await queryOne("SELECT id FROM users WHERE email = ?", [teamEmail]);
  if (!existingTeam) {
    const teamHash = await bcrypt.hash(teamPassword, 10);
    const now = new Date().toISOString();
    await query(
      "INSERT INTO users (id, email, password_hash, full_name, role, staff_type, gov_id, created_date, updated_date) VALUES (?, ?, ?, ?, 'rescue_team', 'rescue_team', ?, ?, ?)",
      [newId('user'), teamEmail, teamHash, 'Rescue Team Responder', teamGovId, now, now]
    );
  } else {
    await query("UPDATE users SET gov_id = ? WHERE id = ? AND (gov_id IS NULL OR gov_id = '')", [teamGovId, existingTeam.id]);
  }

  // Set Government ID for Admin
  await query("UPDATE users SET gov_id = 'GOV-ADMIN-0001' WHERE email = ? AND (gov_id IS NULL OR gov_id = '')", [adminEmail]);
  await query("UPDATE users SET gov_id = 'GOV-RESCUE-8802' WHERE email = 'sen77600@gmail.com' AND (gov_id IS NULL OR gov_id = '')");

  // Migrate existing rescue team staff records to role 'rescue_team' if not admin
  await query(
    "UPDATE users SET role = 'rescue_team' WHERE staff_type = 'rescue_team' AND role != 'admin'"
  );
}
