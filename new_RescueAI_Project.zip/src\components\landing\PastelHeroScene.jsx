import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

/**
 * PastelHeroScene:
 * A premium, full-screen, light-themed, futuristic 3D visual experience.
 * Features:
 * - Beautiful pastel palette: pearl white, sky blue, lavender, mint, and soft coral
 * - A small, slowly rotating globe with delicate pastel continents
 * - Floating translucent glass spheres with gentle bobbing motion
 * - Elegant orbital rings and flowing 3D ribbons
 * - Soft glowing particles and interconnected light trails
 * - Soft daylight lighting, subtle iridescent gradients, and clean depth
 * - Gentle camera movement and mouse-based parallax
 * - WebGL capability check with graceful fallback
 * - Reduced motion support
 */

function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

function createPastelEarthTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // 1. Pearl White to Soft Sky-Blue Oceanic Gradient
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  oceanGrad.addColorStop(0, '#f0f7ff');
  oceanGrad.addColorStop(0.5, '#e0f0fe');
  oceanGrad.addColorStop(1, '#f0f7ff');
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 2. Subtle latitude & longitude grid lines in delicate lavender
  ctx.strokeStyle = 'rgba(196, 181, 253, 0.18)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= canvas.width; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y <= canvas.height; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // 3. Continental Landmasses in Pearl White & Soft Mint Shading
  const W = canvas.width;
  const H = canvas.height;
  const toXY = (lon, lat) => [((lon + 180) / 360) * W, ((90 - lat) / 180) * H];

  const drawPolygon = (coords) => {
    if (coords.length < 3) return;
    ctx.beginPath();
    const [startX, startY] = toXY(coords[0][0], coords[0][1]);
    ctx.moveTo(startX, startY);
    for (let i = 1; i < coords.length; i++) {
      const [x, y] = toXY(coords[i][0], coords[i][1]);
      ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.strokeStyle = 'rgba(110, 231, 183, 0.55)'; // Mint coastal rim
    ctx.lineWidth = 1.8;
    ctx.stroke();
  };

  const northAmerica = [
    [-168, 66], [-140, 70], [-100, 74], [-80, 70], [-60, 50],
    [-70, 42], [-76, 35], [-81, 25], [-97, 26], [-98, 19],
    [-88, 16], [-83, 10], [-77, 8], [-80, 9], [-92, 14],
    [-105, 20], [-115, 30], [-124, 38], [-124, 48], [-135, 57],
    [-160, 58], [-168, 66]
  ];

  const southAmerica = [
    [-77, 8], [-60, 5], [-50, -2], [-35, -5], [-37, -13],
    [-42, -22], [-50, -30], [-65, -45], [-70, -55], [-75, -50],
    [-72, -40], [-71, -30], [-76, -15], [-81, -5], [-77, 8]
  ];

  const europe = [
    [-10, 36], [0, 38], [15, 40], [25, 36], [28, 42],
    [32, 45], [40, 42], [50, 48], [40, 56], [30, 60],
    [25, 71], [15, 65], [5, 60], [-5, 58], [-5, 48],
    [-10, 44], [-10, 36]
  ];

  const africa = [
    [-6, 36], [10, 37], [25, 32], [32, 31], [35, 28],
    [43, 12], [51, 12], [42, -2], [40, -15], [32, -28],
    [27, -34], [18, -34], [12, -20], [10, -5], [2, 4],
    [-14, 11], [-17, 15], [-13, 28], [-6, 36]
  ];

  const asia = [
    [32, 45], [50, 48], [60, 55], [70, 73], [100, 78],
    [140, 72], [170, 65], [170, 60], [140, 50], [130, 38],
    [122, 30], [108, 20], [100, 10], [98, 3], [80, 8],
    [70, 20], [60, 25], [50, 30], [35, 32], [32, 45]
  ];

  const australia = [
    [114, -22], [125, -15], [136, -12], [142, -11], [150, -22],
    [153, -28], [150, -37], [138, -35], [130, -32], [116, -35],
    [113, -26], [114, -22]
  ];

  [northAmerica, southAmerica, europe, africa, asia, australia].forEach(drawPolygon);

  // 4. Delicate pastel micro-dots across landmasses
  ctx.fillStyle = 'rgba(167, 139, 250, 0.28)'; // Lavender dots
  for (let i = 0; i < 1800; i++) {
    const rx = Math.random() * canvas.width;
    const ry = Math.random() * canvas.height;
    const p = ctx.getImageData(rx, ry, 1, 1).data;
    if (p[0] > 240 && p[1] > 240 && p[2] > 240) {
      ctx.beginPath();
      ctx.arc(rx, ry, 1.1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.generateMipmaps = true;
  return texture;
}

export default function PastelHeroScene() {
  const mountRef = useRef(null);
  const [hasWebGL, setHasWebGL] = useState(true);

  useEffect(() => {
    if (!isWebGLAvailable()) {
      setHasWebGL(false);
      return;
    }

    const mount = mountRef.current;
    if (!mount) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const width = mount.clientWidth || window.innerWidth;
    const height = mount.clientHeight || window.innerHeight;

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.5, 7.5);

    // 2. WebGL Renderer with High Precision & Anti-Aliasing
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    mount.appendChild(renderer.domElement);

    // 3. Ambient Daylight & Soft Pastel Point Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.8);
    sunLight.position.set(6, 8, 7);
    scene.add(sunLight);

    // Pastel Accent Lights (Sky Blue, Lavender, Mint, Soft Coral)
    const skyBlueLight = new THREE.PointLight(0x7dd3fc, 2.2, 20);
    skyBlueLight.position.set(-5, 4, 3);
    scene.add(skyBlueLight);

    const lavenderLight = new THREE.PointLight(0xc4b5fd, 2.2, 20);
    lavenderLight.position.set(5, -3, 3);
    scene.add(lavenderLight);

    const mintLight = new THREE.PointLight(0xa7f3d0, 1.8, 18);
    mintLight.position.set(0, 6, -2);
    scene.add(mintLight);

    const coralLight = new THREE.PointLight(0xfda4af, 1.6, 18);
    coralLight.position.set(0, -5, 2);
    scene.add(coralLight);

    // 4. Main Scene Root Container
    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    // 5. Small, Slowly Rotating Globe (Radius: 1.35)
    const globeGroup = new THREE.Group();
    globeGroup.rotation.z = (23.5 * Math.PI) / 180;
    rootGroup.add(globeGroup);

    const globeRadius = 1.35;
    const earthGeo = new THREE.SphereGeometry(globeRadius, 64, 64);
    const earthTex = createPastelEarthTexture();
    const earthMat = new THREE.MeshStandardMaterial({
      map: earthTex,
      roughness: 0.35,
      metalness: 0.08,
      emissive: new THREE.Color(0xf0f7ff),
      emissiveIntensity: 0.25
    });
    const earthMesh = new THREE.Mesh(earthGeo, earthMat);
    globeGroup.add(earthMesh);

    // Delicate translucent pastel atmosphere rim
    const atmoGeo = new THREE.SphereGeometry(globeRadius * 1.06, 64, 64);
    const atmoMat = new THREE.MeshPhysicalMaterial({
      color: 0xbae6fd, // Sky blue
      transparent: true,
      opacity: 0.32,
      roughness: 0.1,
      transmission: 0.85,
      thickness: 0.5,
      side: THREE.BackSide
    });
    const atmoMesh = new THREE.Mesh(atmoGeo, atmoMat);
    globeGroup.add(atmoMesh);

    // 6. Floating Translucent Glass Spheres
    const glassSpheres = [];
    const sphereConfigs = [
      { radius: 0.42, color: 0xbae6fd, base: new THREE.Vector3(-2.6, 1.2, 0.8), speed: 0.9, phase: 0 },
      { radius: 0.32, color: 0xddd6fe, base: new THREE.Vector3(2.4, 1.5, -0.4), speed: 0.75, phase: 1.2 },
      { radius: 0.48, color: 0xa7f3d0, base: new THREE.Vector3(2.8, -1.1, 0.6), speed: 0.85, phase: 2.4 },
      { radius: 0.26, color: 0xfecdd3, base: new THREE.Vector3(-2.2, -1.6, -0.2), speed: 1.1, phase: 3.6 },
      { radius: 0.36, color: 0xffffff, base: new THREE.Vector3(0.3, 2.6, -0.8), speed: 0.7, phase: 4.8 },
      { radius: 0.22, color: 0x7dd3fc, base: new THREE.Vector3(-1.1, -2.4, 1.1), speed: 1.0, phase: 5.5 }
    ];

    sphereConfigs.forEach((cfg) => {
      const geo = new THREE.SphereGeometry(cfg.radius, 32, 32);
      const mat = new THREE.MeshPhysicalMaterial({
        color: cfg.color,
        roughness: 0.08,
        metalness: 0.05,
        transmission: 0.88,
        thickness: 0.65,
        ior: 1.45,
        transparent: true,
        opacity: 0.85
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(cfg.base);
      rootGroup.add(mesh);
      glassSpheres.push({ mesh, ...cfg });
    });

    // 7. Elegant Orbital Rings & Flowing 3D Ribbon
    const ringsGroup = new THREE.Group();
    rootGroup.add(ringsGroup);

    // Ring 1: Lavender Orbital Ring
    const ring1Geo = new THREE.RingGeometry(globeRadius * 1.55, globeRadius * 1.57, 64);
    const ring1Mat = new THREE.MeshBasicMaterial({
      color: 0xc4b5fd,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.5
    });
    const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
    ring1.rotation.x = Math.PI / 2.5;
    ring1.rotation.y = Math.PI / 7;
    ringsGroup.add(ring1);

    // Ring 2: Sky Blue Orbital Ring
    const ring2Geo = new THREE.RingGeometry(globeRadius * 1.85, globeRadius * 1.87, 64);
    const ring2Mat = new THREE.MeshBasicMaterial({
      color: 0x7dd3fc,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.42
    });
    const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2.rotation.x = Math.PI / 1.7;
    ring2.rotation.z = Math.PI / 4.5;
    ringsGroup.add(ring2);

    // Ring 3: Soft Coral Orbital Ring
    const ring3Geo = new THREE.RingGeometry(globeRadius * 2.15, globeRadius * 2.165, 64);
    const ring3Mat = new THREE.MeshBasicMaterial({
      color: 0xfda4af,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35
    });
    const ring3 = new THREE.Mesh(ring3Geo, ring3Mat);
    ring3.rotation.y = Math.PI / 2.3;
    ring3.rotation.z = Math.PI / 6;
    ringsGroup.add(ring3);

    // Flowing 3D Ribbon / Smooth Spline Tube
    const ribbonPoints = [];
    const ribbonSteps = 60;
    for (let i = 0; i <= ribbonSteps; i++) {
      const theta = (i / ribbonSteps) * Math.PI * 4;
      const r = 2.4 + Math.sin(theta * 1.5) * 0.45;
      const x = Math.sin(theta) * r;
      const z = Math.cos(theta) * r;
      const y = Math.sin(theta * 2.0) * 1.1;
      ribbonPoints.push(new THREE.Vector3(x, y, z));
    }
    const ribbonCurve = new THREE.CatmullRomCurve3(ribbonPoints, true);
    const ribbonGeo = new THREE.TubeGeometry(ribbonCurve, 120, 0.035, 8, true);
    const ribbonMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      emissive: new THREE.Color(0xe0e7ff),
      emissiveIntensity: 0.35,
      roughness: 0.15,
      metalness: 0.1,
      transmission: 0.7,
      transparent: true,
      opacity: 0.75
    });
    const ribbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
    rootGroup.add(ribbonMesh);

    // 8. Soft Glowing Particles & Interconnected Light Trails
    const particleCount = 220;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const radius = globeRadius * (1.3 + Math.random() * 2.5);
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      particlePositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = radius * Math.cos(phi);
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.026,
      transparent: true,
      opacity: 0.65
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    rootGroup.add(particles);

    // Interconnecting faint light trails between floating spheres
    const trailMat = new THREE.LineBasicMaterial({
      color: 0xc4b5fd,
      transparent: true,
      opacity: 0.28
    });
    const trailPositions = new Float32Array(sphereConfigs.length * 2 * 3);
    const trailGeo = new THREE.BufferGeometry();
    trailGeo.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
    const trailsLine = new THREE.LineSegments(trailGeo, trailMat);
    rootGroup.add(trailsLine);

    // 9. Interactive Parallax & Touch Handling
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const onPointerMove = (e) => {
      if (prefersReducedMotion) return;
      const cx = e.clientX || (e.touches && e.touches[0]?.clientX) || 0;
      const cy = e.clientY || (e.touches && e.touches[0]?.clientY) || 0;
      targetX = (cx / window.innerWidth - 0.5) * 0.45;
      targetY = (cy / window.innerHeight - 0.5) * 0.35;
    };

    window.addEventListener('mousemove', onPointerMove, { passive: true });
    window.addEventListener('touchmove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // 10. Animation Loop
    let animId;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      if (!prefersReducedMotion) {
        // Slow globe rotation
        globeGroup.rotation.y += 0.0016;

        // Gentle orbital rings & ribbon rotation
        ringsGroup.rotation.z += 0.0006;
        ribbonMesh.rotation.y -= 0.001;
        particles.rotation.y -= 0.0004;

        // Floating translucent spheres bobbing motion
        const positions = trailGeo.attributes.position.array;
        let lineIdx = 0;

        glassSpheres.forEach((s, idx) => {
          const deltaY = Math.sin(elapsedTime * s.speed + s.phase) * 0.18;
          s.mesh.position.y = s.base.y + deltaY;

          // Connect trails between neighboring spheres
          const nextSphere = glassSpheres[(idx + 1) % glassSpheres.length];
          positions[lineIdx++] = s.mesh.position.x;
          positions[lineIdx++] = s.mesh.position.y;
          positions[lineIdx++] = s.mesh.position.z;

          positions[lineIdx++] = nextSphere.mesh.position.x;
          positions[lineIdx++] = nextSphere.mesh.position.y;
          positions[lineIdx++] = nextSphere.mesh.position.z;
        });
        trailGeo.attributes.position.needsUpdate = true;

        // Camera gentle breathing motion & mouse parallax
        mouseX += (targetX - mouseX) * 0.04;
        mouseY += (targetY - mouseY) * 0.04;
        camera.position.x = mouseX * 1.2;
        camera.position.y = 0.5 + -mouseY * 0.9 + Math.sin(elapsedTime * 0.5) * 0.06;
        camera.lookAt(0, 0, 0);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('resize', onResize);

      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
      earthGeo.dispose();
      earthTex.dispose();
      earthMat.dispose();
      atmoGeo.dispose();
      atmoMat.dispose();
      ring1Geo.dispose();
      ring1Mat.dispose();
      ring2Geo.dispose();
      ring2Mat.dispose();
      ring3Geo.dispose();
      ring3Mat.dispose();
      ribbonGeo.dispose();
      ribbonMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      trailGeo.dispose();
      trailMat.dispose();
      glassSpheres.forEach((s) => {
        s.mesh.geometry.dispose();
        s.mesh.material.dispose();
      });
    };
  }, []);

  if (!hasWebGL) {
    return (
      <div className="rescue-landing-fallback">
        <div className="w-48 h-48 rounded-full bg-gradient-to-tr from-sky-200 via-indigo-100 to-rose-100 shadow-2xl" />
      </div>
    );
  }

  return <div ref={mountRef} className="rescue-landing-canvas-wrapper" aria-hidden="true" />;
}
