# RescueAI

Autonomous disaster response & rescue management web application built with React, Vite, Tailwind CSS, shadcn/ui, Express, and PostgreSQL (with zero-config SQLite local fallback).

Runs completely standalone without any Base44 account or external proprietary SDKs.

---

## Features

- **Public SOS Portal (`/sos`)**: One-click voice recording, location tagging, automatic priority computation, and submission rate limiting.
- **Live SOS Tracking (`/track/:reference_id`)**: Real-time status stepper (Sent → Team has seen it → Acknowledged → Help on the way → Resolved) with timestamps, team callsigns, ETAs, and team messages.
- **Rescue Team Portal (`/team`)**:
  - Live SOS queue with Server-Sent Events (SSE) instant updates and 3-second fallback polling.
  - Sound alert toggle on incoming emergency cases.
  - "Unacknowledged 5+ min" overdue badges sorting urgent calls to the top.
  - Case claiming ("Acknowledge") with conflict detection and takeover confirmation.
  - Dispatching with callsign and ETA tracking.
  - Team-to-sender quick messages and custom replies.
  - Resolution modal with outcomes and handover notes.
  - Full audit trail history per SOS.
- **Admin Management (`/admin`)**:
  - Review and approve/reject responder access requests.
  - Team member role management.
  - Real-time audit activity feed across all SOS events.
- **Situation Assessment (`/`)**:
  - Multi-hazard AI analysis (Flood, Earthquake, Fire, Cyclone).
  - Open-Meteo live rainfall and temperature data.
  - Overpass API local hospital discovery.
  - Nominatim population intelligence.
  - AI disaster action plan with Gemini (with automatic rule-based fallback).

---

## Configuration & Replit Secrets

Configure the following environment variables (in Replit Secrets or `.env` locally):

| Secret / Env Var | Required | Description |
|---|---|---|
| `SESSION_SECRET` | **Yes** | Strong secret string used to sign HTTP session cookies and audio playback tokens. |
| `ADMIN_EMAIL` | **Yes** | Email address for the first administrator account created on startup. |
| `ADMIN_PASSWORD` | **Yes** | Password for the initial administrator account (minimum 8 characters). |
| `GEMINI_API_KEY` | *Optional* | Google Gemini API key (`@google/genai`) for AI action plans and SOS voice transcription. (If omitted, automatic rule-based planning is used). |
| `DATABASE_URL` | *Optional* | PostgreSQL connection string. Provided automatically by Replit PostgreSQL. If not set (e.g. in local development), the server automatically uses a zero-config SQLite database. |
| `PORT` | *Optional* | Web server port (defaults to `5000` in production, `5173` for Vite in dev). |

---

## Initial Admin Setup

1. Add `ADMIN_EMAIL` and `ADMIN_PASSWORD` in your secrets/environment.
2. Start the server. On boot, if no administrator exists in the database, RescueAI automatically seeds the first admin user with `role: 'admin'` and `staff_type: 'rescue_team'`.
3. Open `/login` and sign in with those credentials to access `/admin` and `/team`.

---

## Running Locally

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development environment (Express backend on `5000` + Vite dev server on `5173`):
   ```bash
   npm run dev
   ```

3. Open `http://localhost:5173` in your browser.

---

## Deployment (Replit or VM)

For production hosting on Replit (Reserved VM or Autoscale) or any Node.js server:

1. Build the frontend client:
   ```bash
   npm run build
   ```

2. Start the production Express server:
   ```bash
   npm start
   ```

The Express server binds `0.0.0.0` and serves both the API endpoints (`/api/*`) and the static production SPA build from `dist/`.
