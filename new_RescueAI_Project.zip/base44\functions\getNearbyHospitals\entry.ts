import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cached, cacheKey, fetchJson, fetchWithTimeout, haversineKm, roundCoord } from '../../shared/live.ts';

function bbox(lat: number, lng: number, radiusKm: number) {
  const dLat = radiusKm / 111;
  const dLng = radiusKm / (111 * Math.max(0.2, Math.cos((lat * Math.PI) / 180)));
  return `${lng - dLng},${lat + dLat},${lng + dLng},${lat - dLat}`;
}

async function nominatimHospitals(lat: number, lng: number, radiusKm: number) {
  const url =
    'https://nominatim.openstreetmap.org/search?q=hospital&format=jsonv2&limit=40&extratags=1&addressdetails=1' +
    `&bounded=1&viewbox=${bbox(lat, lng, radiusKm)}`;

  const rows = await fetchJson(url);
  return (Array.isArray(rows) ? rows : [])
    .filter((row: any) => row?.type === 'hospital' || row?.category === 'amenity')
    .map((row: any) => {
      const name = String(row?.name || String(row?.display_name || '').split(',')[0] || '').trim();
      const hLat = Number(row?.lat);
      const hLng = Number(row?.lon);
      if (!name || !Number.isFinite(hLat) || !Number.isFinite(hLng)) return null;
      const address = row?.address || {};
      const extratags = row?.extratags || {};
      return {
        id: String(row?.osm_id ?? `${hLat},${hLng}`),
        name,
        lat: hLat,
        lng: hLng,
        distance_km: Math.round(haversineKm(lat, lng, hLat, hLng) * 10) / 10,
        phone: String(extratags.phone || extratags['contact:phone'] || '').trim(),
        emergency: extratags.emergency === 'yes',
        address: [
          address.house_number,
          address.road,
          address.suburb || address.city || address.town || address.village,
          address.postcode
        ]
          .filter(Boolean)
          .join(', '),
        website: String(extratags.website || extratags['contact:website'] || '').trim()
      };
    })
    .filter(Boolean)
    .sort((a: any, b: any) => a.distance_km - b.distance_km)
    .slice(0, 10);
}

async function overpassHospitals(lat: number, lng: number, radiusKm: number) {
  const query =
    '[out:json][timeout:25];' +
    `nwr(around:${Math.round(radiusKm * 1000)},${lat},${lng})[amenity=hospital];` +
    'out center tags 60;';
  const response = await fetchWithTimeout(
    'https://overpass-api.de/api/interpreter',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'data=' + encodeURIComponent(query)
    },
    12000
  );
  if (!response.ok) throw new Error(`Overpass responded ${response.status}`);
  const payload = await response.json();
  return (Array.isArray(payload?.elements) ? payload.elements : [])
    .map((element: any) => {
      const hLat = Number(element?.lat ?? element?.center?.lat);
      const hLng = Number(element?.lon ?? element?.center?.lon);
      const tags = element?.tags || {};
      const name = String(tags.name || '').trim();
      if (!name || !Number.isFinite(hLat) || !Number.isFinite(hLng)) return null;
      return {
        id: `${element?.type || 'n'}-${element?.id || `${hLat},${hLng}`}`,
        name,
        lat: hLat,
        lng: hLng,
        distance_km: Math.round(haversineKm(lat, lng, hLat, hLng) * 10) / 10,
        phone: String(tags.phone || tags['contact:phone'] || '').trim(),
        emergency: tags.emergency === 'yes',
        address: '',
        website: String(tags.website || tags['contact:website'] || '').trim()
      };
    })
    .filter(Boolean)
    .sort((a: any, b: any) => a.distance_km - b.distance_km)
    .slice(0, 10);
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const lat = Number(body?.lat);
    const lng = Number(body?.lng);
    const requested = Number(body?.radiusKm);
    const radiusKm = Number.isFinite(requested) && requested > 0 ? Math.min(80, requested) : 15;

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return Response.json({ error: 'Valid coordinates are required.' }, { status: 400 });
    }

    const data = await cached(
      base44,
      cacheKey(['hospitals', roundCoord(lat), roundCoord(lng), radiusKm]),
      async () => {
        const attempts = [...new Set([radiusKm, 30, 60].filter((value) => value >= radiusKm))];
        for (const attemptRadius of attempts) {
          let hospitals: any[] = [];
          let source = 'OpenStreetMap';
          try {
            hospitals = await overpassHospitals(lat, lng, attemptRadius);
            source = 'Overpass API';
          } catch {
            hospitals = [];
          }
          if (hospitals.length === 0) {
            try {
              hospitals = await nominatimHospitals(lat, lng, attemptRadius);
              source = 'OpenStreetMap';
            } catch {
              hospitals = [];
            }
          }
          if (hospitals.length > 0) {
            return {
              hospitals,
              radius_used: attemptRadius,
              requested_radius: radiusKm,
              source
            };
          }
        }
        return {
          hospitals: [],
          radius_used: attempts[attempts.length - 1] || radiusKm,
          requested_radius: radiusKm,
          source: 'OpenStreetMap',
          message: 'No hospitals found in OpenStreetMap near here'
        };
      }
    );

    return Response.json(data);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Hospital lookup failed.' }, { status: 502 });
  }
}
