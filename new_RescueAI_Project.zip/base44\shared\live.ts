export const USER_AGENT = 'RescueAI/1.0';
export const CACHE_TTL_SECONDS = 600;

export function roundCoord(value: unknown) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
}

export function cacheKey(parts: unknown[]) {
  return parts
    .map((part) => String(part ?? '').trim().toLowerCase())
    .join('|')
    .slice(0, 240);
}

export async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 15000) {
  const headers = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json',
    ...(options.headers || {})
  };
  return fetch(url, { ...options, headers, signal: AbortSignal.timeout(timeoutMs) });
}

export async function fetchJson(url: string, options: RequestInit = {}, timeoutMs = 15000, attempt = 0): Promise<any> {
  try {
    const response = await fetchWithTimeout(url, options, timeoutMs);
    if (!response.ok) throw new Error(`Upstream responded ${response.status}`);
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch {
      throw new Error('Upstream returned a non-JSON reply');
    }
  } catch (error) {
    if (attempt < 1) return fetchJson(url, options, timeoutMs, attempt + 1);
    throw error;
  }
}

async function findCacheRow(base44: any, key: string) {
  const page = await base44.asServiceRole.entities.Cache.filter({ key }, { limit: 1 });
  return page?.items?.[0] || null;
}

export async function readCache(base44: any, key: string) {
  try {
    const row = await findCacheRow(base44, key);
    if (!row) return null;
    if (new Date(row.expires_at).getTime() < Date.now()) return null;
    return { payload: row.payload || {}, updated_at: row.updated_at || null };
  } catch {
    return null;
  }
}

export async function writeCache(base44: any, key: string, payload: any) {
  const expires_at = new Date(Date.now() + CACHE_TTL_SECONDS * 1000).toISOString();
  try {
    const row = await findCacheRow(base44, key);
    if (row) {
      await base44.asServiceRole.entities.Cache.update(row.id, { payload, expires_at });
    } else {
      await base44.asServiceRole.entities.Cache.create({ key, payload, expires_at });
    }
  } catch {
    // a cache write must never break the response
  }
}

export async function cached(base44: any, key: string, loader: () => Promise<any>) {
  const hit = await readCache(base44, key);
  if (hit) {
    return { ...hit.payload, cached: true, updated_at: hit.updated_at || new Date().toISOString() };
  }
  const fresh = await loader();
  await writeCache(base44, key, fresh);
  return { ...fresh, cached: false, updated_at: new Date().toISOString() };
}

export async function reversePlace(base44: any, lat: number, lng: number) {
  const key = cacheKey(['reverse', roundCoord(lat), roundCoord(lng)]);
  return cached(base44, key, async () => {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=jsonv2&zoom=10&addressdetails=1&extratags=1`;
    const row = await fetchJson(url);
    const address = row?.address || {};
    const place =
      address.city ||
      address.town ||
      address.village ||
      address.suburb ||
      address.county ||
      address.state_district ||
      address.state ||
      '';
    const population = Number(row?.extratags?.population || 0) || null;
    const display =
      [place, address.state, address.country].filter(Boolean).join(', ') ||
      String(row?.display_name || '').split(',').slice(0, 2).join(', ');
    return {
      name: place || String(row?.display_name || '').split(',')[0] || '',
      display_name: display,
      city: address.city || address.town || address.village || '',
      district: address.county || address.state_district || '',
      state: address.state || '',
      country: address.country || '',
      population,
      lat,
      lng
    };
  });
}

export function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number) {
  const toRad = (value: number) => (value * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function clampNumber(value: unknown, fallback: number, min = 0, max = 100000000) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) return fallback;
  return n;
}

export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
