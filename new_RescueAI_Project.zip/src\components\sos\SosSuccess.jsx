import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import {
  Camera,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  Eye,
  MessageSquare,
  Phone,
  RefreshCw,
  ShieldCheck,
  Truck,
  WifiOff
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const STEPS = [
  { key: 'sent', label: 'Sent', hint: 'Your message is with the rescue queue', icon: Check },
  { key: 'seen', label: 'Team has seen it', hint: 'A team member opened your request', icon: Eye },
  { key: 'acknowledged', label: 'Acknowledged', hint: 'A responder has claimed your case', icon: CheckCircle2 },
  { key: 'dispatched', label: 'Help on the way', hint: 'Rescue team is moving towards you', icon: Truck },
  { key: 'resolved', label: 'Resolved', hint: 'The team has closed your request', icon: ShieldCheck }
];

export default function SosSuccess({ referenceId, trackingToken, onAnother }) {
  const { toast } = useToast();
  const [data, setData] = useState({
    status: 'new',
    priority: 'normal',
    timestamps: {},
    team: null,
    eta_minutes: null,
    latest_message: null,
    outcome: null
  });
  const [copied, setCopied] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);

  // Retrieve token from argument, query param, or localStorage
  const token =
    trackingToken ||
    new URLSearchParams(window.location.search).get('token') ||
    localStorage.getItem(`sos_token_${referenceId}`) ||
    '';

  useEffect(() => {
    if (referenceId && token) {
      localStorage.setItem(`sos_token_${referenceId}`, token);
    }
  }, [referenceId, token]);

  useEffect(() => {
    let active = true;

    const fetchTrack = async () => {
      if (!referenceId) return;
      const url = `/api/sos/track/${encodeURIComponent(referenceId)}?token=${encodeURIComponent(token)}`;
      try {
        const res = await fetch(url);
        if (!res.ok) {
          if (res.status === 403 || res.status === 404) {
            // unauthorized
            return;
          }
          throw new Error('Track check failed');
        }
        const json = await res.json();
        if (active) {
          setData(json);
          setIsReconnecting(false);
        }
      } catch (err) {
        if (active) {
          setIsReconnecting(true);
        }
      }
    };

    fetchTrack();
    const interval = setInterval(fetchTrack, 4000);

    // Optional SSE live stream
    let eventSource = null;
    try {
      eventSource = new EventSource(
        `/api/sos/track/${encodeURIComponent(referenceId)}?token=${encodeURIComponent(token)}`
      );
      eventSource.addEventListener('track_update', (e) => {
        try {
          const update = JSON.parse(e.data);
          if (active && update) {
            setData(update);
            setIsReconnecting(false);
          }
        } catch {}
      });
      eventSource.onerror = () => {
        if (active) setIsReconnecting(true);
      };
    } catch {}

    return () => {
      active = false;
      clearInterval(interval);
      if (eventSource) eventSource.close();
    };
  }, [referenceId, token]);

  // Determine which step is currently active
  // Statuses: 'new', 'acknowledged', 'dispatched', 'resolved'
  // Also 'seen' if status is 'new' but timestamps.first_seen_at is set!
  let currentStepIndex = 0;
  if (data.status === 'resolved') {
    currentStepIndex = 4;
  } else if (data.status === 'dispatched') {
    currentStepIndex = 3;
  } else if (data.status === 'acknowledged') {
    currentStepIndex = 2;
  } else if (data.timestamps?.first_seen_at) {
    currentStepIndex = 1;
  } else {
    currentStepIndex = 0;
  }

  const handleCopyLink = () => {
    const trackingUrl = `${window.location.origin}/track/${referenceId}?token=${encodeURIComponent(token)}`;
    navigator.clipboard.writeText(trackingUrl).then(() => {
      setCopied(true);
      toast({
        title: 'Tracking link copied',
        description: 'You can bookmark or share this link to track your SOS.'
      });
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const getStepTimestamp = (stepKey) => {
    const ts = data.timestamps || {};
    let iso = null;
    if (stepKey === 'sent') iso = ts.created_at;
    else if (stepKey === 'seen') iso = ts.first_seen_at;
    else if (stepKey === 'acknowledged') iso = ts.acknowledged_at;
    else if (stepKey === 'dispatched') iso = ts.dispatched_at;
    else if (stepKey === 'resolved') iso = ts.resolved_at;

    if (!iso) return null;
    try {
      return format(new Date(iso), 'HH:mm:ss');
    } catch {
      return null;
    }
  };

  return (
    <div className="mx-auto max-w-xl rounded-[16px] bg-white p-6 text-center shadow-soft ring-1 ring-black/5 sm:p-9">
      <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-sev-low/10 text-sev-low">
        <Check className="h-8 w-8" aria-hidden="true" />
      </span>

      <div className="flex items-center justify-center gap-2 mt-4">
        <h2 className="font-heading text-2xl text-ink sm:text-3xl">SOS active</h2>
        {isReconnecting && (
          <span className="inline-flex items-center gap-1 rounded-full bg-sev-medium/15 px-2.5 py-0.5 text-[11px] font-medium text-[#8A6410]">
            <RefreshCw className="h-3 w-3 animate-spin" />
            Reconnecting...
          </span>
        )}
      </div>

      <p className="mt-2 text-sm text-graphite">
        Keep this reference. Quote it if you call emergency dispatchers.
      </p>

      <div className="mt-4 flex flex-col items-center justify-center gap-2">
        <p className="select-all rounded-xl bg-canvas px-6 py-3 font-mono text-2xl tracking-[0.3em] text-ink sm:text-3xl">
          {referenceId}
        </p>

        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleCopyLink}
          className="mt-1 h-9 rounded-xl border-ink/15 text-xs font-medium text-steel hover:text-ink"
        >
          {copied ? <Check className="mr-1.5 h-3.5 w-3.5 text-sev-low" /> : <Copy className="mr-1.5 h-3.5 w-3.5" />}
          {copied ? 'Link copied!' : 'Copy tracking link'}
        </Button>
      </div>

      {/* Latest message from team */}
      {data.latest_message && (
        <div className="mt-6 rounded-xl border border-coral/30 bg-coral/5 p-4 text-left">
          <div className="flex items-center gap-2 text-xs font-semibold text-coral">
            <MessageSquare className="h-4 w-4" />
            Message from rescue team
          </div>
          <p className="mt-1.5 text-sm font-medium text-ink">{data.latest_message}</p>
        </div>
      )}

      {/* ETA banner */}
      {data.status === 'dispatched' && data.eta_minutes !== null && (
        <div className="mt-4 rounded-xl border border-steel/20 bg-steel/5 p-3 text-left flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-steel">
            <Truck className="h-4 w-4" />
            Estimated arrival time
          </div>
          <span className="font-heading text-base font-bold text-coral">
            ~{data.eta_minutes} mins
          </span>
        </div>
      )}

      {/* Outcome banner if resolved */}
      {data.status === 'resolved' && (
        <div className="mt-4 rounded-xl border border-sev-low/30 bg-sev-low/10 p-4 text-left">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sev-low">
            <ShieldCheck className="h-4 w-4" />
            Case Resolved
          </div>
          <p className="mt-1 text-sm text-ink">
            Rescue response completed
            {data.outcome ? ` · Outcome: ${data.outcome}` : ''}
          </p>
        </div>
      )}

      <ol className="mt-7 space-y-0 text-left" aria-live="polite">
        {STEPS.map((step, index) => {
          const done = index <= currentStepIndex;
          const active = index === currentStepIndex;
          const stepTime = getStepTimestamp(step.key);

          // Custom hint for steps
          let hint = step.hint;
          if (step.key === 'acknowledged' && data.team) {
            hint = `Claimed by ${data.team}`;
          } else if (step.key === 'dispatched' && data.team) {
            hint = `${data.team} en route${data.eta_minutes ? ` (ETA: ${data.eta_minutes} min)` : ''}`;
          }

          return (
            <li key={step.key} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span
                  className={cn(
                    'grid h-9 w-9 place-items-center rounded-full ring-1 transition-colors',
                    done ? 'bg-sev-low/10 text-sev-low ring-sev-low/30' : 'bg-canvas text-graphite/60 ring-ink/10'
                  )}
                >
                  <step.icon className="h-4 w-4" aria-hidden="true" />
                </span>
                {index < STEPS.length - 1 ? (
                  <span
                    className={cn('my-1 w-px flex-1 min-h-[24px]', done ? 'bg-sev-low/40' : 'bg-ink/10')}
                    aria-hidden="true"
                  />
                ) : null}
              </div>
              <div className={cn('pb-5 flex-1', index === STEPS.length - 1 && 'pb-0')}>
                <div className="flex items-baseline justify-between">
                  <p className={cn('text-sm font-semibold', done ? 'text-ink' : 'text-graphite/70')}>
                    {step.label}
                    {active ? (
                      <span className="ml-2 rounded-full bg-coral/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-coral">
                        now
                      </span>
                    ) : null}
                  </p>
                  {stepTime && (
                    <span className="text-[11px] font-mono text-graphite/80 flex items-center gap-1">
                      <Clock className="h-2.5 w-2.5" />
                      {stepTime}
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-xs text-graphite">{hint}</p>
              </div>
            </li>
          );
        })}
      </ol>

      {/* Uploaded Incident Photos Gallery */}
      {data.photos && data.photos.length > 0 && (
        <div className="mt-6 rounded-xl border border-steel/20 bg-canvas/70 p-3.5 text-left">
          <div className="flex items-center justify-between mb-2">
            <span className="flex items-center gap-1.5 text-xs font-semibold text-ink uppercase tracking-wide">
              <Camera className="h-3.5 w-3.5 text-coral" />
              Attached Photos ({data.photos.length})
            </span>
            <span className="text-[10px] text-graphite">Transmitted to rescue squad</span>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {data.photos.map((url, idx) => (
              <a
                key={idx}
                href={url}
                target="_blank"
                rel="noreferrer"
                className="group relative aspect-square overflow-hidden rounded-lg border border-steel/20 bg-white shadow-2xs hover:opacity-90"
              >
                <img
                  src={url}
                  alt={`Incident photo ${idx + 1}`}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <ExternalLink className="h-3.5 w-3.5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </a>
            ))}
          </div>
        </div>
      )}

      <p className="mt-4 text-[11px] text-graphite/80">
        Live tracker refreshes automatically.
      </p>

      {onAnother && (
        <Button
          type="button"
          onClick={onAnother}
          className="mt-6 h-11 w-full rounded-xl bg-coral text-sm font-semibold text-white hover:bg-[#D9614A]"
        >
          Send another SOS
        </Button>
      )}

      <a
        href="tel:112"
        className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-steel hover:text-ink"
      >
        <Phone className="h-3.5 w-3.5" aria-hidden="true" />
        Life-threatening? Call 112 immediately
      </a>
    </div>
  );
}
