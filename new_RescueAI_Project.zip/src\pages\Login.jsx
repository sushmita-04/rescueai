import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LogIn, Mail, Lock, ShieldCheck, LifeBuoy, Loader2, CreditCard, Shield } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login({ type: defaultType }) {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const typeParam = searchParams.get('type');
  const isTeam = defaultType === 'team' || typeParam === 'team' || location.pathname === '/team-login';

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [smtpConfigured, setSmtpConfigured] = useState(false);

  // Post-login destination
  const returnTo = safeReturnTo();

  useEffect(() => {
    base44.app.getPublicSettings().then((settings) => {
      setSmtpConfigured(Boolean(settings?.public_settings?.smtp_configured));
    }).catch(() => {});
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const loggedUser = await base44.auth.loginViaEmailPassword(identifier.trim(), password, isTeam ? 'team' : 'public');
      
      // Determine redirection based on authenticated role
      let destination = returnTo;
      const isStaff = loggedUser?.role === 'admin' || loggedUser?.role === 'rescue_team' || loggedUser?.staff_type === 'rescue_team';

      if (!destination || destination === '/') {
        destination = isStaff ? (isTeam ? '/team' : '/') : '/sos';
      }

      // Enforce rule: Common users can only access SOS
      if (!isStaff && (destination === '/team' || destination === '/admin' || destination === '/')) {
        destination = '/sos';
      }

      window.location.href = destination;
    } catch (err) {
      setError(err.message || (isTeam ? "Invalid Government Responder ID or Passcode" : "Invalid email or password"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      icon={isTeam ? ShieldCheck : LifeBuoy}
      title={isTeam ? "Rescue Team — Official Portal" : "Common People — SOS Login"}
      subtitle={
        isTeam
          ? "Authorized responders sign in using your Government-Issued Responder ID Number"
          : "Sign in to send emergency SOS and track rescue operations"
      }
      footer={
        <div className="space-y-2 text-center text-xs">
          {!isTeam ? (
            <p className="text-graphite">
              Don't have an SOS account?{" "}
              <Link
                to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
                className="text-primary font-medium hover:underline"
              >
                Create one
              </Link>
            </p>
          ) : (
            <p className="text-graphite">
              Official emergency responder portal. Access is restricted to government-registered rescue personnel.
            </p>
          )}

          <div className="pt-2 border-t border-black/5">
            {isTeam ? (
              <p className="text-graphite">
                Looking for public emergency SOS?{" "}
                <Link to="/login" className="font-semibold text-coral hover:underline">
                  Common People — SOS Login &rarr;
                </Link>
              </p>
            ) : (
              <p className="text-graphite">
                Are you an authorized emergency responder?{" "}
                <Link to="/team-login" className="font-semibold text-navy hover:underline">
                  Rescue Team — Team Login &rarr;
                </Link>
              </p>
            )}
          </div>
        </div>
      }
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm" role="alert">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="identifier">
            {isTeam ? "Government-Issued Responder ID Number" : "Email Address"}
          </Label>
          <div className="relative">
            {isTeam ? (
              <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            ) : (
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            )}
            <Input
              id="identifier"
              type={isTeam ? "text" : "email"}
              autoComplete={isTeam ? "username" : "email"}
              autoFocus
              placeholder={isTeam ? "e.g. GOV-RESCUE-7701" : "you@example.com"}
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">
              {isTeam ? "Official Security Passcode" : "Password"}
            </Label>
            {smtpConfigured && !isTeam && (
              <Link to="/forgot-password" className="text-xs text-primary hover:underline">
                Forgot password?
              </Link>
            )}
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>

        <Button type="submit" className="w-full h-12 font-medium bg-coral hover:bg-[#D9614A] text-white" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Verifying credentials...
            </>
          ) : (
            isTeam ? "Verify Government ID & Access" : "Sign in to SOS"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}
