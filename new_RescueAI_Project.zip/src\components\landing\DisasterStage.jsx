import React, { useEffect, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Compass,
  Flame,
  Radio,
  ShieldAlert,
  Waves,
  Wind,
  Zap
} from 'lucide-react';
import EarthGlobe from './EarthGlobe';

/**
 * Coordinated Disaster Scenarios:
 * 1. Flash Floods & Tsunami Inundation (water flow, rain streaks, boat evac)
 * 2. Cyclones & Severe Storms (storm winds, lightning pulses, radar vectors)
 * 3. Wildfires & Thermal Ridge Breaches (thermal glow, smoke haze, embers)
 * 4. Earthquakes & Structural Search (seismic scan, acoustic life detector)
 */
const DISASTER_SCENARIOS = [
  {
    id: 'flood',
    title: 'Flash Flood & Inundation',
    category: 'HYDROLOGICAL DISASTER',
    icon: Waves,
    accentColor: '#22D3EE',
    badgeColor: 'text-[#22D3EE] bg-[#22D3EE]/10 border-[#22D3EE]/30',
    location: 'Sector 4 Coastal Delta · St. Jude Basin',
    status: 'SURGE LEVEL +3.4M · BOAT SQUAD 04 DISPATCHED',
    telemetry: [
      { label: 'Flow Rate', value: '420 m³/s' },
      { label: 'Victims Located', value: '18 Evacuated' },
      { label: 'Units En Route', value: 'Alpha-Boat 04' }
    ],
    narrative: 'Rising flood waters detected in dense residential sector. Autonomous voice triage dispatched amphibious rescue units in 4.2 seconds.'
  },
  {
    id: 'storm',
    title: 'Cyclone & Supercell Storm',
    category: 'METEOROLOGICAL EMERGENCY',
    icon: Wind,
    accentColor: '#60A5FA',
    badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
    location: 'Eastern Maritime Corridor · Grid 12B',
    status: '145 KM/H SUSTAINED · MARITIME SHELTERS ONLINE',
    telemetry: [
      { label: 'Wind Velocity', value: '145 km/h' },
      { label: 'Precipitation', value: '180 mm/h' },
      { label: 'Radar Corridors', value: '6 Evac Clear' }
    ],
    narrative: 'High-velocity cyclonic eyewall approaching coast. AI predictive modeling calculated safe evacuation corridors before power grid disruption.'
  },
  {
    id: 'wildfire',
    title: 'Wildfire Perimeter Breach',
    category: 'THERMAL CRISIS EVENT',
    icon: Flame,
    accentColor: '#F97316',
    badgeColor: 'text-orange-400 bg-orange-500/10 border-orange-500/30',
    location: 'Northern Ridgeline & Valley Pass',
    status: 'FIRE SPREAD CONTAINED · AERIAL DROP ACTIVE',
    telemetry: [
      { label: 'Thermal Index', value: '880°C Core' },
      { label: 'Containment Line', value: '64% Secured' },
      { label: 'Air Tankers', value: 'Squadron 2 En Route' }
    ],
    narrative: 'Rapid wind shift directed wildfire toward mountain settlement. Automated distress beacons mobilized containment teams and aerial retardant drops.'
  },
  {
    id: 'earthquake',
    title: 'Seismic Structural Search',
    category: 'GEOPHYSICAL COLLAPSE',
    icon: AlertTriangle,
    accentColor: '#EF4444',
    badgeColor: 'text-red-400 bg-red-500/10 border-red-500/30',
    location: 'Metro Fault Zone 7 · District Central',
    status: 'MAGNITUDE 6.8 · ACOUSTIC SENSORS LOCKED',
    telemetry: [
      { label: 'Seismic Shock', value: 'M 6.8 Depth 12km' },
      { label: 'Acoustic Hits', value: '4 Signs of Life' },
      { label: 'K9 & Drone Teams', value: '8 Teams Deployed' }
    ],
    narrative: 'Post-quake structural triage activated acoustic frequency sensors, pinpointing trapped survivors through rubble without network infrastructure.'
  }
];

export default function DisasterStage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const canvasRef = useRef(null);

  // Auto-cycle through disaster scenarios every 6.5s
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % DISASTER_SCENARIOS.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  const scenario = DISASTER_SCENARIOS[currentIndex];

  // Lightweight 2D canvas for atmospheric particles (rain, embers, radar ripples)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId;
    let width = (canvas.width = canvas.clientWidth);
    let height = (canvas.height = canvas.clientHeight);

    const onResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.clientWidth;
      height = canvas.height = canvas.clientHeight;
    };
    window.addEventListener('resize', onResize);

    // Weather particles
    const particles = Array.from({ length: 32 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      length: 10 + Math.random() * 15,
      speedY: 2 + Math.random() * 4,
      speedX: (Math.random() - 0.5) * 1.5,
      radius: 1 + Math.random() * 2,
      opacity: 0.2 + Math.random() * 0.5,
      angle: Math.random() * Math.PI * 2
    }));

    // Distant lightning flash timer for storms
    let flashOpacity = 0;
    let nextFlashTime = Date.now() + 4000;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const activeType = DISASTER_SCENARIOS[currentIndex].id;

      // 1. Distant lightning illumination for storm / cyclone
      if (activeType === 'storm' || activeType === 'flood') {
        const now = Date.now();
        if (now > nextFlashTime) {
          flashOpacity = 0.12;
          nextFlashTime = now + 5000 + Math.random() * 4000;
        }
        if (flashOpacity > 0.005) {
          ctx.fillStyle = `rgba(147, 197, 253, ${flashOpacity})`;
          ctx.fillRect(0, 0, width, height);
          flashOpacity *= 0.88;
        }
      }

      // 2. Weather particles animation
      particles.forEach((p) => {
        if (activeType === 'flood' || activeType === 'storm') {
          // Rain streaks
          p.y += p.speedY * 1.8;
          p.x += 0.8;
          if (p.y > height) {
            p.y = -p.length;
            p.x = Math.random() * width;
          }
          ctx.strokeStyle = `rgba(186, 230, 253, ${p.opacity * 0.4})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + 1.2, p.y + p.length);
          ctx.stroke();
        } else if (activeType === 'wildfire') {
          // Floating warm embers drifting upward
          p.y -= p.speedY * 0.5;
          p.angle += 0.04;
          p.x += Math.sin(p.angle) * 0.7;
          if (p.y < -10) {
            p.y = height + 10;
            p.x = Math.random() * width;
          }
          ctx.fillStyle = `rgba(251, 146, 60, ${p.opacity * 0.6})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();
        } else if (activeType === 'earthquake') {
          // Soft seismic dust motes
          p.y += (Math.random() - 0.48) * 0.6;
          p.x += (Math.random() - 0.5) * 0.6;
          ctx.fillStyle = `rgba(239, 68, 68, ${p.opacity * 0.35})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * 0.8, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
    };
  }, [currentIndex]);

  const IconComponent = scenario.icon;

  return (
    <div className="relative w-full max-w-xl lg:max-w-2xl mx-auto flex flex-col items-center">
      {/* 1. Atmospheric Canvas Overlay for subtle weather particles */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
        aria-hidden="true"
      />

      {/* 2. Ambient Volumetric Glow Behind Stage */}
      <div
        className="absolute -top-12 left-1/2 -translate-x-1/2 w-[90%] h-[340px] pointer-events-none blur-[90px] rounded-full transition-colors duration-1000 -z-10"
        style={{
          background: `radial-gradient(circle, ${scenario.accentColor}25 0%, rgba(239,68,68,0.15) 50%, transparent 80%)`
        }}
        aria-hidden="true"
      />

      {/* 3. The Smaller 3D Earth Globe (Strictly 22-30% of desktop viewport) */}
      <div className="relative z-20 w-[270px] h-[270px] sm:w-[330px] sm:h-[330px] lg:w-[380px] lg:h-[380px] flex items-center justify-center">
        {/* Subtle circular backing frame */}
        <div className="absolute inset-3 rounded-full border border-white/[0.08] bg-[#030614]/40 backdrop-blur-sm -z-10 shadow-[0_0_50px_rgba(3,7,20,0.85)]" />
        <EarthGlobe activeScenarioIndex={currentIndex} />
      </div>

      {/* 4. Coordinated Disaster Response Command Panel */}
      <div className="relative z-20 w-full -mt-6 sm:-mt-8 rounded-2xl border border-white/[0.12] bg-[#070C1E]/85 p-4 sm:p-5 shadow-[0_20px_50px_rgba(2,4,10,0.9),0_0_35px_-5px_rgba(239,68,68,0.25)] backdrop-blur-xl transition-all duration-700">
        {/* Scenario Switcher Tabs */}
        <div className="flex items-center justify-between gap-1.5 border-b border-white/[0.08] pb-3 mb-3.5 overflow-x-auto no-scrollbar">
          {DISASTER_SCENARIOS.map((item, idx) => {
            const ItemIcon = item.icon;
            const isActive = idx === currentIndex;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-300 ${
                  isActive
                    ? 'bg-white/10 text-white shadow-sm border border-white/15'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <ItemIcon
                  className="h-3.5 w-3.5 transition-colors"
                  style={{ color: isActive ? item.accentColor : '#94A3B8' }}
                />
                <span className="hidden sm:inline">{item.title.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Live Active Scenario Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider border ${scenario.badgeColor}`}
            >
              <Radio className="h-3 w-3 animate-pulse" />
              {scenario.category}
            </span>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
            LIVE TELEMETRY
          </span>
        </div>

        {/* Scenario Title & Location */}
        <div className="mb-3">
          <h2 className="text-sm sm:text-base font-bold text-white font-heading flex items-center gap-2">
            <IconComponent className="h-4 w-4" style={{ color: scenario.accentColor }} />
            <span>{scenario.title}</span>
          </h2>
          <p className="text-[11px] text-slate-300 font-mono mt-0.5 truncate">
            📍 {scenario.location}
          </p>
        </div>

        {/* Real-time Telemetry Metrics Strip */}
        <div className="grid grid-cols-3 gap-2 p-2 rounded-xl bg-black/40 border border-white/[0.06] mb-3">
          {scenario.telemetry.map((t, i) => (
            <div key={i} className="text-center sm:text-left sm:px-1.5">
              <span className="block text-[9px] font-mono uppercase text-slate-400 truncate">
                {t.label}
              </span>
              <span className="text-[11px] sm:text-xs font-bold text-white tracking-tight">
                {t.value}
              </span>
            </div>
          ))}
        </div>

        {/* Narrative Benefit Statement */}
        <p className="text-xs text-slate-300 leading-relaxed font-light">
          {scenario.narrative}
        </p>

        {/* Live Status Strip */}
        <div className="mt-3 pt-2.5 border-t border-white/[0.06] flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span className="text-white font-semibold truncate max-w-[240px] sm:max-w-none">
            ⚡ {scenario.status}
          </span>
          <span className="text-slate-400 hidden sm:inline">CYCLE 6.5s</span>
        </div>
      </div>
    </div>
  );
}
