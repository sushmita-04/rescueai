import { useState, useEffect } from 'react';
import { formatDistanceToNow, format } from 'date-fns';
import {
  AlertTriangle,
  Camera,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  History,
  Image,
  MapPin,
  MessageSquare,
  Phone,
  Quote,
  RotateCcw,
  Send,
  ShieldCheck,
  Truck,
  Users,
  ZoomIn
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import SosAudio from '@/components/team/SosAudio';
import { PRIORITY_META, STATUS_LABELS } from '@/lib/severity';
import { SITUATIONS } from '@/lib/sos';
import { cn } from '@/lib/utils';

const situationLabel = (value) =>
  SITUATIONS.find((item) => item.value === value)?.label || 'Emergency';

const QUICK_REPLIES = [
  'Stay where you are, help is on the way.',
  'Move to higher ground immediately.',
  'Keep your phone line free, dispatch will call you.',
  'Rescue team is responding to your location.'
];

export default function SosCard({
  sos,
  onAcknowledge,
  onDispatch,
  onResolve,
  onReopen,
  onSeen,
  onSendMessage,
  flash
}) {
  const [expanded, setExpanded] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [events, setEvents] = useState([]);
  const [loadingEvents, setLoadingEvents] = useState(false);

  // Message modal state
  const [msgOpen, setMsgOpen] = useState(false);
  const [messageText, setMessageText] = useState('');
  const [sendingMsg, setSendingMsg] = useState(false);

  // Overdue calculation (> 5 min in 'new')
  const createdMs = sos.created_date ? new Date(sos.created_date).getTime() : Date.now();
  const isOverdue = sos.status === 'new' && Date.now() - createdMs > 5 * 60 * 1000;

  const meta = PRIORITY_META[sos.priority] || PRIORITY_META.normal;
  const resolved = sos.status === 'resolved';
  const hasCoords = typeof sos.lat === 'number' && typeof sos.lng === 'number';

  const [selectedImage, setSelectedImage] = useState(null);

  let incidentPhotos = [];
  try {
    if (sos.photo_urls) {
      const parsed = typeof sos.photo_urls === 'string' ? JSON.parse(sos.photo_urls) : sos.photo_urls;
      if (Array.isArray(parsed)) incidentPhotos = parsed;
      else if (typeof parsed === 'string' && parsed) incidentPhotos = [parsed];
    } else if (Array.isArray(sos.photos)) {
      incidentPhotos = sos.photos;
    }
  } catch {
    if (typeof sos.photo_urls === 'string' && sos.photo_urls.trim()) {
      incidentPhotos = [sos.photo_urls.trim()];
    }
  }

  // Mark as seen when expanded or mounted if unread
  const handleToggleExpand = () => {
    const next = !expanded;
    setExpanded(next);
    if (next && onSeen && !sos.first_seen_at) {
      onSeen(sos.id);
    }
  };

  const handleOpenHistory = async () => {
    const next = !historyOpen;
    setHistoryOpen(next);
    if (next && events.length === 0) {
      setLoadingEvents(true);
      try {
        const res = await fetch(`/api/team/sos/${sos.id}/events`, { credentials: 'include' });
        const json = await res.json();
        setEvents(json.items || []);
      } catch {
        // ignore
      } finally {
        setLoadingEvents(false);
      }
    }
  };

  const handleSendQuickReply = async (text) => {
    setSendingMsg(true);
    try {
      await onSendMessage?.(sos, text);
      setMsgOpen(false);
      setMessageText('');
    } finally {
      setSendingMsg(false);
    }
  };

  return (
    <article
      onClick={() => {
        if (!sos.first_seen_at && onSeen) {
          onSeen(sos.id);
        }
      }}
      className={cn(
        'rounded-[16px] border-l-4 bg-white p-4 shadow-soft ring-1 ring-black/5 transition-all sm:p-5',
        meta.border,
        resolved && 'opacity-60',
        flash && 'animate-flash ring-2 ring-coral'
      )}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className={cn('rounded-full px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider ring-1', meta.chip)}>
          {meta.label}
        </span>

        {isOverdue && (
          <span className="inline-flex items-center gap-1 rounded-full bg-sev-critical/15 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-sev-critical ring-1 ring-sev-critical/30 animate-pulse">
            <AlertTriangle className="h-3 w-3" />
            Unacknowledged 5+ min
          </span>
        )}

        <span className="rounded-md bg-canvas px-2 py-0.5 font-mono text-[11px] tracking-widest text-steel">
          {sos.reference_id}
        </span>

        {sos.first_seen_at && (
          <span className="text-[10px] text-graphite/80 italic">
            Seen by {sos.first_seen_by || 'team'}
          </span>
        )}

        <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-graphite">
          <Clock className="h-3 w-3" aria-hidden="true" />
          {sos.created_date ? formatDistanceToNow(new Date(sos.created_date), { addSuffix: true }) : 'just now'}
        </span>
      </div>

      <div className="mt-2 flex items-start justify-between">
        <h3 className="font-heading text-lg leading-snug text-ink">
          {situationLabel(sos.situation)}
          {sos.name ? <span className="text-graphite"> · {sos.name}</span> : null}
        </h3>

        <button
          type="button"
          onClick={handleToggleExpand}
          className="text-xs text-steel hover:text-ink flex items-center gap-1 py-1 px-2 rounded-lg hover:bg-canvas transition-colors"
        >
          {expanded ? 'Less' : 'Details'}
          {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
      </div>

      <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-graphite">
        <span className="inline-flex items-center gap-1">
          <Users className="h-3.5 w-3.5" aria-hidden="true" />
          {sos.people_count || 0} with them
        </span>
        {sos.phone ? (
          <a href={`tel:${sos.phone}`} className="inline-flex items-center gap-1 font-medium text-steel hover:text-coral">
            <Phone className="h-3.5 w-3.5" aria-hidden="true" />
            {sos.phone}
          </a>
        ) : null}
        {sos.status !== 'new' ? (
          <span className="rounded-full bg-canvas px-2 py-0.5 text-[11px] font-medium text-steel">
            {STATUS_LABELS[sos.status] || sos.status}
            {sos.handled_by ? ` · ${sos.handled_by}` : ''}
            {sos.eta_minutes ? ` (ETA: ${sos.eta_minutes}m)` : ''}
          </span>
        ) : null}
      </div>

      {sos.location_text ? (
        <p className="mt-2.5 flex items-start gap-1.5 text-sm text-ink/80">
          <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-steel" aria-hidden="true" />
          {sos.location_text}
        </p>
      ) : null}

      {hasCoords ? (
        <a
          href={`https://www.google.com/maps?q=${sos.lat},${sos.lng}`}
          target="_blank"
          rel="noreferrer"
          className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-coral hover:underline"
        >
          <ExternalLink className="h-3 w-3" aria-hidden="true" />
          Open map ({Number(sos.lat).toFixed(4)}, {Number(sos.lng).toFixed(4)})
        </a>
      ) : null}

      {/* Voice Audio Player */}
      {sos.audio_url ? (
        <SosAudio fileUri={sos.audio_url} duration={sos.audio_duration} />
      ) : (
        <p className="mt-3 rounded-lg bg-canvas px-3 py-2 text-[11px] text-graphite">
          No voice message attached
        </p>
      )}

      {/* Voice-to-Text Transcription & Calculated Severity */}
      {sos.transcript ? (
        <div className="mt-3 rounded-xl border border-steel/20 bg-canvas/70 p-3 shadow-xs">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-steel">
              <Quote className="h-3.5 w-3.5 text-coral" aria-hidden="true" />
              Transcribed Voice (Speech-to-Text)
            </span>
            <span className={cn('rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1', meta.chip)}>
              {meta.label} Severity
            </span>
          </div>
          <p className="rounded-lg bg-white p-2.5 text-xs font-medium leading-relaxed text-ink shadow-xs border border-steel/10">
            &ldquo;{sos.transcript}&rdquo;
          </p>
          <div className="mt-1.5 flex items-center justify-between text-[10px] text-graphite">
            <span>Triage severity calculated from voice message keywords</span>
            <span className="font-semibold text-ink uppercase">Action Priority: {meta.label}</span>
          </div>
        </div>
      ) : null}

      {/* Incident Photos Preview Gallery */}
      {incidentPhotos.length > 0 && (
        <div className="mt-3 rounded-xl border border-steel/20 bg-canvas/70 p-3 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-steel">
              <Camera className="h-3.5 w-3.5 text-coral" aria-hidden="true" />
              Attached Incident Photos ({incidentPhotos.length})
            </span>
            <span className="text-[10px] text-graphite">Click image to inspect</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {incidentPhotos.map((url, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedImage(url)}
                className="group relative aspect-square overflow-hidden rounded-lg border border-steel/20 bg-slate-100 text-left transition hover:border-coral focus:outline-none focus:ring-2 focus:ring-coral/40"
              >
                <img
                  src={url}
                  alt={`Incident ${idx + 1}`}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                  <ZoomIn className="h-4 w-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Lightbox Modal to inspect photo in high resolution */}
      <Dialog open={Boolean(selectedImage)} onOpenChange={(open) => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-2xl p-3 bg-black/95 text-white border-white/10">
          <div className="flex items-center justify-between px-2 pt-1 pb-2">
            <DialogTitle className="text-sm font-semibold text-white flex items-center gap-2">
              <Camera className="h-4 w-4 text-coral" />
              Incident Photo Inspection
            </DialogTitle>
          </div>
          {selectedImage && (
            <div className="relative max-h-[75vh] overflow-hidden rounded-lg flex items-center justify-center bg-black">
              <img
                src={selectedImage}
                alt="Enlarged incident evidence"
                className="max-h-[72vh] w-auto max-w-full object-contain rounded-md"
              />
            </div>
          )}
          <DialogFooter className="px-2 pt-2 flex items-center justify-between sm:justify-between">
            {selectedImage && (
              <a
                href={selectedImage}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-coral hover:underline"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                Open original photo
              </a>
            )}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setSelectedImage(null)}
              className="h-8 rounded-lg border-white/20 text-white hover:bg-white/10"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {sos.note ? (
        <p className="mt-2 rounded-lg bg-canvas px-3 py-2 text-xs leading-relaxed text-graphite">
          <span className="font-semibold text-ink">Note: </span>
          {sos.note}
        </p>
      ) : null}

      {sos.latest_message && (
        <div className="mt-2 rounded-lg border border-coral/20 bg-coral/5 px-3 py-2 text-xs">
          <span className="font-semibold text-coral">Sent to sender: </span>
          {sos.latest_message}
        </div>
      )}

      {/* Expandable Details: History Audit Trail */}
      {expanded && (
        <div className="mt-4 border-t border-ink/10 pt-3">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={handleOpenHistory}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-steel hover:text-ink"
            >
              <History className="h-3.5 w-3.5" />
              {historyOpen ? 'Hide History' : 'Show History (Audit Trail)'}
            </button>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setMsgOpen(true)}
              className="h-8 rounded-lg text-xs"
            >
              <MessageSquare className="mr-1 h-3 w-3" />
              Message sender
            </Button>
          </div>

          {historyOpen && (
            <div className="mt-3 rounded-xl bg-canvas p-3">
              {loadingEvents ? (
                <p className="text-xs text-graphite">Loading events...</p>
              ) : events.length === 0 ? (
                <p className="text-xs text-graphite">No events recorded yet.</p>
              ) : (
                <ul className="space-y-2">
                  {events.map((ev) => (
                    <li key={ev.id} className="text-xs flex items-start justify-between gap-2 border-b border-ink/5 pb-1 last:border-0">
                      <div>
                        <span className="font-semibold text-ink capitalize">{ev.type.replace('_', ' ')}</span>
                        <span className="text-graphite"> by {ev.actor_name || 'System'}</span>
                        {ev.note && <p className="text-graphite/80 italic">{ev.note}</p>}
                      </div>
                      <span className="font-mono text-[10px] text-graphite shrink-0">
                        {ev.created_at ? format(new Date(ev.created_at), 'HH:mm:ss') : ''}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      )}

      {/* Workflow Action Buttons */}
      <div className="mt-4 flex flex-wrap gap-2">
        {sos.status === 'new' ? (
          <Button
            type="button"
            onClick={() => onAcknowledge(sos)}
            className="h-10 flex-1 rounded-xl bg-coral text-sm font-semibold text-white hover:bg-[#D9614A]"
          >
            Acknowledge case
          </Button>
        ) : sos.status === 'acknowledged' ? (
          <Button
            type="button"
            onClick={() => onDispatch(sos)}
            className="h-10 flex-1 rounded-xl bg-steel text-sm font-semibold text-white hover:bg-navy"
          >
            <Truck className="mr-1.5 h-4 w-4" aria-hidden="true" />
            Dispatch team
          </Button>
        ) : sos.status === 'dispatched' ? (
          <Button
            type="button"
            onClick={() => onResolve(sos)}
            className="h-10 flex-1 rounded-xl bg-sev-low text-sm font-semibold text-white hover:bg-[#23897C]"
          >
            <ShieldCheck className="mr-1.5 h-4 w-4" aria-hidden="true" />
            Mark resolved
          </Button>
        ) : (
          <Button
            type="button"
            variant="outline"
            onClick={() => onReopen(sos)}
            className="h-10 flex-1 rounded-xl border-ink/15 text-sm font-medium text-steel"
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
            Reopen case
          </Button>
        )}

        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setMsgOpen(true)}
          className="h-10 rounded-xl border-ink/15 text-xs text-steel hover:text-ink px-3"
          title="Send a quick update to the sender"
        >
          <MessageSquare className="h-4 w-4" />
        </Button>
      </div>

      {/* Message Modal */}
      <Dialog open={msgOpen} onOpenChange={setMsgOpen}>
        <DialogContent className="rounded-[16px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading">Send message to sender</DialogTitle>
            <DialogDescription>
              This message appears immediately on their live tracking screen.
            </DialogDescription>
          </DialogHeader>

          <div className="mt-3 space-y-3">
            <div>
              <p className="text-xs font-medium text-graphite mb-1.5">Quick replies:</p>
              <div className="flex flex-col gap-1.5">
                {QUICK_REPLIES.map((text) => (
                  <button
                    key={text}
                    type="button"
                    onClick={() => setMessageText(text)}
                    className="text-left rounded-lg bg-canvas p-2 text-xs font-medium text-steel hover:bg-coral/10 hover:text-coral transition-colors"
                  >
                    "{text}"
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="custom-msg" className="text-xs font-medium text-ink">
                Or type custom message (max 200 chars):
              </label>
              <Textarea
                id="custom-msg"
                maxLength={200}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Type instructions or updates..."
                className="mt-1 h-20 rounded-xl text-xs"
              />
              <p className="text-[10px] text-right text-graphite mt-1">
                {messageText.length} / 200 chars
              </p>
            </div>
          </div>

          <DialogFooter className="mt-4 gap-2">
            <Button type="button" variant="outline" onClick={() => setMsgOpen(false)} className="rounded-xl">
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!messageText.trim() || sendingMsg}
              onClick={() => handleSendQuickReply(messageText.trim())}
              className="rounded-xl bg-coral text-white hover:bg-[#D9614A]"
            >
              <Send className="mr-1.5 h-3.5 w-3.5" />
              Send to sender
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </article>
  );
}
