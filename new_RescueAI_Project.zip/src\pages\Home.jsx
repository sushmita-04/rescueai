import { useCallback, useMemo, useRef, useState } from 'react';
import { Lock, ShieldAlert } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import AppShell from '@/components/AppShell';
import AssessForm from '@/components/assess/AssessForm';
import ResultsCard from '@/components/assess/ResultsCard';
import LivePanel from '@/components/assess/LivePanel';
import { useToast } from '@/components/ui/use-toast';

const PILLS = ['Live APIs', 'ML Severity', 'AI Planner', 'Voice SOS'];

const KINDS = ['weather', 'hospitals', 'population', 'news'];

const emptyLive = () =>
  KINDS.reduce((acc, kind) => ({ ...acc, [kind]: { status: 'idle', data: null, error: '' } }), {});

function runFetcher(kind, query) {
  if (kind === 'weather') {
    return base44.functions.invoke('getWeather', { lat: query.lat, lng: query.lng });
  }
  if (kind === 'hospitals') {
    return base44.functions.invoke('getNearbyHospitals', { lat: query.lat, lng: query.lng, radiusKm: 15 });
  }
  if (kind === 'population') {
    return base44.functions.invoke('getPopulation', {
      lat: query.lat,
      lng: query.lng,
      place_name: query.placeName
    });
  }
  return base44.functions.invoke('getDisasterNews', {
    disaster_type: query.disaster_type,
    place_name: query.placeName
  });
}

const sameSpot = (a, b) =>
  Number.isFinite(a?.lat) &&
  Number.isFinite(b?.lat) &&
  Math.round(a.lat * 100) === Math.round(b.lat * 100) &&
  Math.round(a.lng * 100) === Math.round(b.lng * 100);

export default function Home() {
  const { user, isAuthenticated, authChecked } = useAuth();
  const { toast } = useToast();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [doneActions, setDoneActions] = useState([]);
  const [assessmentId, setAssessmentId] = useState(null);
  const [live, setLive] = useState(emptyLive);
  const [impact, setImpact] = useState(null);
  const [dismissed, setDismissed] = useState({});
  const resultsRef = useRef(null);
  const lastQueryRef = useRef(null);

  const extractImpact = useCallback(async (articles) => {
    if (!articles?.length) {
      setImpact(null);
      return;
    }
    try {
      const response = await base44.functions.invoke('extractImpactFromNews', {
        headlines: articles.slice(0, 6).map((item) => item.title)
      });
      setImpact(response?.data || null);
    } catch {
      setImpact(null);
    }
  }, []);

  const loadKind = useCallback(
    async (kind, query) => {
      setLive((current) => ({ ...current, [kind]: { status: 'loading', data: null, error: '' } }));
      try {
        const response = await runFetcher(kind, query);
        const data = response?.data;
        if (!data || data.error) throw new Error(data?.error || 'The service did not respond.');
        setLive((current) => ({ ...current, [kind]: { status: 'ok', data, error: '' } }));
        if (kind === 'news') extractImpact(data.articles || []);
      } catch (err) {
        setLive((current) => ({
          ...current,
          [kind]: { status: 'error', data: null, error: err?.message || 'Could not load this data.' }
        }));
      }
    },
    [extractImpact]
  );

  const handleLiveQuery = useCallback(
    (query, kinds) => {
      const clean = {
        lat: Number(query.lat),
        lng: Number(query.lng),
        placeName: String(query.placeName || ''),
        disaster_type: String(query.disaster_type || 'flood')
      };
      lastQueryRef.current = clean;
      kinds.forEach((kind) => loadKind(kind, clean));
    },
    [loadKind]
  );

  const handleRetry = (kind) => {
    if (lastQueryRef.current) loadKind(kind, lastQueryRef.current);
  };

  const handleDismiss = (kind) => setDismissed((current) => ({ ...current, [kind]: true }));

  const liveData = useMemo(
    () => ({
      weather: live.weather.status === 'ok' ? live.weather.data : null,
      population: live.population.status === 'ok' ? live.population.data : null,
      impact
    }),
    [live, impact]
  );

  const liveHospitals = live.hospitals.status === 'ok' ? live.hospitals.data?.hospitals || [] : [];

  const liveUsable = (kind, coords) => {
    const query = lastQueryRef.current;
    return live[kind].status === 'ok' && sameSpot(query, coords);
  };

  const fetchOrLive = async (kind, query, coords) => {
    if (liveUsable(kind, coords)) return live[kind].data;
    try {
      const response = await runFetcher(kind, query);
      const data = response?.data;
      if (!data || data.error) return null;
      return data;
    } catch {
      return null;
    }
  };

  const toggleAction = (actionText, isDone) => {
    const next = isDone
      ? doneActions.filter((action) => action !== actionText)
      : [...doneActions, actionText];
    setDoneActions(next);
    if (assessmentId) {
      base44.entities.Assessment.update(assessmentId, { done_actions: next }).catch(() => {});
    }
  };

  const handleAssess = async (values) => {
    setLoading(true);
    setError('');

    try {
      let coords =
        Number.isFinite(values.lat) && Number.isFinite(values.lng)
          ? { lat: Number(values.lat), lng: Number(values.lng) }
          : null;
      let placeName = values.placeName || values.location;

      if (!coords) {
        try {
          const geo = await base44.functions.invoke('geocodeSearch', { query: values.location });
          const first = geo?.data?.results?.[0];
          if (first && Number.isFinite(first.lat) && Number.isFinite(first.lng)) {
            coords = { lat: first.lat, lng: first.lng };
            placeName = first.short_name || first.display_name || values.location;
          }
        } catch {
          // location lookup is best-effort; analysis continues without live context
        }
      }

      const query = {
        lat: coords?.lat,
        lng: coords?.lng,
        placeName,
        disaster_type: values.disaster_type
      };

      const [weather, hospitalsData, newsData, populationData] = await Promise.all([
        coords ? fetchOrLive('weather', query, coords) : Promise.resolve(null),
        coords ? fetchOrLive('hospitals', query, coords) : Promise.resolve(null),
        fetchOrLive('news', query, coords),
        coords ? fetchOrLive('population', query, coords) : Promise.resolve(null)
      ]);

      const news = (newsData?.articles || []).slice(0, 6);

      let peopleAffected = values.people_affected;
      let peopleInjured = values.people_injured;
      let affectedSource = ['news', 'estimated'].includes(values.affected_source)
        ? values.affected_source
        : 'manual';
      let injuredSource = ['news', 'estimated'].includes(values.injured_source)
        ? values.injured_source
        : 'manual';

      if ((peopleAffected === null || peopleInjured === null) && news.length > 0) {
        let extracted = liveUsable('news', coords) ? impact : null;
        if (!extracted) {
          try {
            const response = await base44.functions.invoke('extractImpactFromNews', {
              headlines: news.map((item) => item.title)
            });
            extracted = response?.data;
          } catch {
            extracted = null;
          }
        }
        if (peopleAffected === null && extracted?.affected > 0) {
          peopleAffected = extracted.affected;
          affectedSource = 'news';
        }
        if (peopleInjured === null && extracted?.injured > 0) {
          peopleInjured = extracted.injured;
          injuredSource = 'news';
        }
      }

      const rainfall =
        values.rainfall !== null && values.rainfall !== undefined
          ? values.rainfall
          : weather?.rainfall_last_24h ?? 0;

      const payload = {
        disaster_type: values.disaster_type,
        location: values.location,
        lat: coords?.lat,
        lng: coords?.lng,
        people_affected: peopleAffected,
        people_injured: peopleInjured,
        rainfall,
        damage_score: values.damage_score,
        teams_available: values.teams_available,
        affected_source: affectedSource,
        injured_source: injuredSource,
        weather: weather || {},
        hospitals: hospitalsData?.hospitals || [],
        news,
        population: populationData?.population ?? 0
      };

      const response = await base44.functions.invoke('assessSituation', payload);
      const data = response?.data;
      if (!data || data.error) {
        throw new Error(data?.error || 'The assessment service did not respond.');
      }

      const record = await base44.entities.Assessment.create({
        disaster_type: payload.disaster_type,
        location: payload.location,
        lat: payload.lat,
        lng: payload.lng,
        people_affected: data.people_affected,
        people_injured: data.people_injured,
        rainfall: data.rainfall,
        damage_score: payload.damage_score,
        teams_available: payload.teams_available,
        population: payload.population,
        affected_source: affectedSource,
        injured_source: injuredSource,
        severity: data.severity,
        score: data.score,
        probabilities: data.probabilities,
        summary: data.summary,
        priority_actions: data.priority_actions,
        teams_to_deploy: data.resources?.teams_to_deploy ?? 0,
        medical_units: data.resources?.medical_units ?? 0,
        shelter_places: data.resources?.shelter_capacity ?? 0,
        weather_note: data.weather_note,
        plan_source: data.plan_source,
        plan: data.plan,
        weather: weather || null,
        hospitals: (hospitalsData?.hospitals || []).slice(0, 5),
        news: news.slice(0, 5),
        data_sources: {
          weather: weather?.provider || 'unavailable',
          hospitals: hospitalsData?.source || 'unavailable',
          news: newsData?.source || 'unavailable',
          population: populationData?.source || 'unavailable'
        }
      }).catch(() => null);

      setAssessmentId(record?.id ?? null);
      setDoneActions(record?.done_actions || []);
      setResult({ ...data, input: payload });

      toast({
        title: 'Rescue plan ready',
        description: `${data.severity} severity · ${data.resources?.teams_to_deploy ?? 0} team(s) to deploy`
      });

      if (window.innerWidth < 1024) {
        setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
      }
    } catch (err) {
      const message =
        err?.response?.data?.error || err?.message || 'Something went wrong. Please try again.';
      setError(message);
      toast({ variant: 'destructive', title: 'Could not analyse', description: message });
    } finally {
      setLoading(false);
    }
  };

  if (!authChecked) {
    return (
      <AppShell>
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <div className="h-8 w-48 rounded bg-slate-200 animate-pulse" />
          <div className="mt-6 h-64 w-full rounded-2xl bg-slate-100 animate-pulse" />
        </div>
      </AppShell>
    );
  }

  if (!isAuthenticated) {
    return (
      <AppShell>
        <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-16 text-center sm:py-24">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-steel shadow-soft ring-1 ring-black/5">
            <Lock className="h-6 w-6 text-navy" aria-hidden="true" />
          </span>
          <h1 className="mt-5 font-heading text-2xl text-ink sm:text-3xl">
            Rescue Team Sign-In Required
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-graphite">
            The Situation Assessment engine and disaster prediction tools are reserved for authorized rescue team responders.
          </p>
          <div className="mt-6 flex flex-col items-center gap-2">
            <a
              href="/team-login?returnTo=/"
              className="inline-flex h-11 items-center justify-center rounded-xl bg-coral px-6 text-sm font-semibold text-white hover:bg-[#D9614A]"
            >
              Rescue Team Login
            </a>
          </div>
        </div>
      </AppShell>
    );
  }

  const isStaff = user?.role === 'admin' || user?.role === 'rescue_team' || user?.staff_type === 'rescue_team';
  if (!isStaff) {
    return (
      <AppShell>
        <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-16 text-center sm:py-24">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-steel shadow-soft ring-1 ring-black/5">
            <ShieldAlert className="h-6 w-6 text-coral" aria-hidden="true" />
          </span>
          <h1 className="mt-5 font-heading text-2xl text-ink sm:text-3xl">
            Assess is Restricted to Rescue Team
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-graphite">
            Common user accounts are authorized for the Emergency SOS portal. Situation Assessment is restricted to emergency responders.
          </p>
          <div className="mt-6 flex flex-col items-center gap-2">
            <a
              href="/sos"
              className="inline-flex h-11 items-center justify-center rounded-xl bg-coral px-6 text-sm font-semibold text-white hover:bg-[#D9614A]"
            >
              Go to SOS Emergency Portal
            </a>
          </div>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <section className="bg-gradient-to-br from-navy via-[#1F2C44] to-steel text-white">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-coral">
            Disaster response intelligence
          </p>
          <h1 className="mt-3 max-w-3xl text-3xl leading-[1.1] sm:text-5xl">
            Faster insight, smarter rescue plans.
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/75 sm:text-base">
            Describe a disaster and get a severity prediction, ranked emergency guidelines and a
            rescue plan a team can act on in seconds. When someone is stuck, send a voice SOS.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {PILLS.map((pill) => (
              <span
                key={pill}
                className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-medium text-white/80"
              >
                {pill}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
          <AssessForm
            onSubmit={handleAssess}
            loading={loading}
            liveData={liveData}
            liveHospitals={liveHospitals}
            onLiveQuery={handleLiveQuery}
          />
          <div ref={resultsRef} className="space-y-6 scroll-mt-20">
            <LivePanel
              live={live}
              dismissed={dismissed}
              onRetry={handleRetry}
              onDismiss={handleDismiss}
            />
            <ResultsCard
              result={result}
              loading={loading}
              error={error}
              doneActions={doneActions}
              onToggleAction={toggleAction}
            />
          </div>
        </div>
      </section>
    </AppShell>
  );
}