import { useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import AppShell from '@/components/AppShell';
import TeamGate from '@/components/team/TeamGate';
import TeamDashboard from '@/components/team/TeamDashboard';
import { Skeleton } from '@/components/ui/skeleton';

function GateSkeleton() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Skeleton className="h-8 w-48" />
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[0, 1, 2, 3].map((index) => (
          <Skeleton key={index} className="h-24 rounded-[16px]" />
        ))}
      </div>
      <Skeleton className="mt-6 h-40 w-full rounded-[16px]" />
    </div>
  );
}

export default function Team() {
  const { user, isAuthenticated, isLoadingAuth, authChecked, navigateToLogin, logout, checkUserAuth } =
    useAuth();

  // Pick up admin approvals made while this account was signed in.
  useEffect(() => {
    if (isAuthenticated) {
      checkUserAuth(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!authChecked) {
    return (
      <AppShell>
        <GateSkeleton />
      </AppShell>
    );
  }

  if (!isAuthenticated) {
    return (
      <AppShell>
        <TeamGate
          variant="signed-out"
          onSignIn={() => {
            window.location.href = '/team-login?returnTo=/team';
          }}
        />
      </AppShell>
    );
  }

  const isStaff = user?.role === 'admin' || user?.role === 'rescue_team' || user?.staff_type === 'rescue_team';
  if (!isStaff) {
    return (
      <AppShell>
        <TeamGate
          variant="forbidden"
          user={user}
          onLogout={() => {
            logout(false);
            window.location.replace('/login');
          }}
        />
      </AppShell>
    );
  }

  return (
    <AppShell>
      <TeamDashboard />
    </AppShell>
  );
}
