import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, ArrowRight, Clock, KeyRound, Loader2, RotateCw, Search, ShieldAlert } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppShell from '@/components/AppShell';
import VoiceRecorder from '@/components/sos/VoiceRecorder';
import PhotoPicker from '@/components/sos/PhotoPicker';
import SosDetails from '@/components/sos/SosDetails';
import SosSuccess from '@/components/sos/SosSuccess';
import WhileYouWait from '@/components/sos/WhileYouWait';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import {
  MAX_AUDIO_BYTES,
  MAX_NOTE_LENGTH,
  calculateSeverityFromText,
  computePriority,
  generateReferenceId
} from '@/lib/sos';
import { PRIORITY_META } from '@/lib/severity';
import { cn } from '@/lib/utils';

const INITIAL_VALUES = {
  situation: '',
  name: '',
  phone: '',
  people_count: '',
  location_text: '',
  note: '',
  lat: null,
  lng: null
};

export default function Sos() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [values, setValues] = useState(INITIAL_VALUES);
  const [recording, setRecording] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [geoState, setGeoState] = useState('idle');
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [sent, setSent] = useState(null);

  // Stored last SOS reference
  const [lastRef, setLastRef] = useState('');
  const [trackInput, setTrackInput] = useState('');

  const combinedText = [recording?.transcript, values.note].filter(Boolean).join(' ');
  const liveCalculatedSeverity = combinedText || values.situation
    ? calculateSeverityFromText(combinedText, values.situation, values.people_count)
    : null;
  const liveSeverityMeta = liveCalculatedSeverity ? (PRIORITY_META[liveCalculatedSeverity] || PRIORITY_META.normal) : null;

  useEffect(() => {
    const saved = localStorage.getItem('last_sos_ref');
    if (saved) setLastRef(saved);
  }, []);

  const shareLocation = () => {
    if (!navigator.geolocation) {
      setGeoState('error');
      return;
    }
    setGeoState('loading');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setValues((current) => ({
          ...current,
          lat: position.coords.latitude,
          lng: position.coords.longitude
        }));
        setGeoState('granted');
        toast({ title: 'Location added', description: 'Your coordinates will be sent with the SOS.' });
      },
      () => {
        setGeoState('error');
        toast({
          variant: 'destructive',
          title: 'Location unavailable',
          description: 'Allow location access, or type a landmark instead.'
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  };

  const handleSend = async () => {
    const nextErrors = {};
    const people = values.people_count === '' ? 0 : Number(values.people_count);

    if (values.people_count !== '' && (!Number.isInteger(people) || people < 0)) {
      nextErrors.people_count = 'Whole number, 0 or more.';
    }
    if (values.phone.trim() && !/^[0-9+\-\s()]{6,20}$/.test(values.phone.trim())) {
      nextErrors.phone = 'Use digits, spaces, +, - or brackets.';
    }
    if (values.note.length > MAX_NOTE_LENGTH) {
      nextErrors.note = `Keep the note under ${MAX_NOTE_LENGTH} characters.`;
    }

    const hasDetails =
      Boolean(recording?.blob) ||
      Boolean(recording?.transcript?.trim()) ||
      Boolean(values.situation) ||
      Boolean(values.location_text.trim()) ||
      values.lat !== null ||
      Boolean(values.note.trim()) ||
      photos.length > 0;

    if (!hasDetails) {
      nextErrors.form = 'Record a voice message, attach a photo, or add your location so the team can find you.';
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSending(true);
    setSubmitError('');

    try {
      let audioUrl = '';

      if (recording?.blob) {
        if (recording.blob.size > MAX_AUDIO_BYTES) {
          throw new Error('That recording is larger than 10 MB. Please record a shorter message.');
        }
        const type = recording.mimeType || 'audio/webm';
        const extension = type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm';
        const file = new File([recording.blob], `sos-${Date.now()}.${extension}`, { type });
        const uploaded = await base44.integrations.Core.UploadPrivateFile({ file });
        audioUrl = uploaded?.file_uri || '';
        if (!audioUrl) throw new Error('The voice message could not be uploaded.');
      }

      // Upload incident photos if any
      let photoUrls = [];
      if (photos.length > 0) {
        const formData = new FormData();
        photos.forEach((p) => {
          if (p.file) {
            formData.append('photos', p.file);
          }
        });

        try {
          const uploadRes = await fetch('/api/sos/upload-photo', {
            method: 'POST',
            body: formData
          });
          if (uploadRes.ok) {
            const uploadJson = await uploadRes.json();
            photoUrls = uploadJson.urls || [];
          }
        } catch (uploadErr) {
          console.warn('Photo upload warning:', uploadErr);
        }
      }

      const transcriptText = (recording?.transcript || '').trim();

      const payload = {
        name: values.name.trim(),
        phone: values.phone.trim(),
        situation: values.situation || 'other',
        location_text: values.location_text.trim(),
        people_count: people,
        note: values.note.trim(),
        transcript: transcriptText,
        audio_url: audioUrl,
        audio_duration: recording?.seconds || 0,
        photo_urls: photoUrls,
        lat: values.lat,
        lng: values.lng
      };

      const res = await fetch('/api/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to submit SOS');
      }

      const created = await res.json();
      const reference = created.reference_id;
      const trackingToken = created.tracking_token;

      // Save to localStorage for quick tracking
      localStorage.setItem('last_sos_ref', reference);
      if (trackingToken) {
        localStorage.setItem(`sos_token_${reference}`, trackingToken);
      }
      setLastRef(reference);

      setSent({ id: created.id, reference_id: reference, tracking_token: trackingToken });
      toast({ title: 'SOS sent', description: `Reference ${reference}` });

      if (audioUrl) {
        base44.functions.invoke('transcribeSos', { sos_id: created.id }).catch(() => {});
      }
    } catch (err) {
      const message =
        err?.response?.data?.error || err?.message || 'We could not send your SOS. Please try again.';
      setSubmitError(message);
      toast({ variant: 'destructive', title: 'SOS not sent', description: message });
    } finally {
      setSending(false);
    }
  };

  const resetAll = () => {
    setSent(null);
    setValues(INITIAL_VALUES);
    setRecording(null);
    setPhotos([]);
    setGeoState('idle');
    setErrors({});
    setSubmitError('');
  };

  const handleTrackSubmit = (e) => {
    e.preventDefault();
    const clean = trackInput.trim().toUpperCase();
    if (/^[A-Z0-9]{8}$/.test(clean)) {
      navigate(`/track/${clean}`);
    } else {
      toast({ variant: 'destructive', title: 'Invalid reference', description: 'Enter an 8-character reference code.' });
    }
  };

  return (
    <AppShell showSosFab={false}>
      <section className="bg-gradient-to-br from-navy via-[#1F2C44] to-steel text-white">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-12">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-coral">Voice SOS</p>
          <h1 className="mt-2 max-w-2xl text-3xl leading-tight sm:text-4xl">
            Send a voice message to the rescue team.
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/75">
            Record what is happening, share where you are, and the team sees it on their dashboard
            straight away.
          </p>
          <p className="mt-4 inline-flex max-w-xl items-start gap-2 rounded-xl bg-white/5 px-3 py-2 text-xs leading-relaxed text-white/70 ring-1 ring-white/10">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-coral" aria-hidden="true" />
            The microphone needs your permission, and recording only works on a secure (HTTPS)
            connection.
          </p>

          {/* Quick link to last SOS */}
          {lastRef && !sent && (
            <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <div className="flex items-center gap-2 text-xs">
                <Clock className="h-4 w-4 text-coral" />
                <span>Your last SOS: <strong className="font-mono text-sm tracking-wider text-white">{lastRef}</strong></span>
              </div>
              <Link
                to={`/track/${lastRef}`}
                className="inline-flex items-center gap-1 rounded-lg bg-white/20 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/30 transition-colors"
              >
                Track status
                <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          )}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
        {sent ? (
          <SosSuccess
            referenceId={sent.reference_id}
            trackingToken={sent.tracking_token}
            onAnother={resetAll}
          />
        ) : (
          <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
            <div className="space-y-6">
              <div className="rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5 sm:p-7">
                <h2 className="font-heading text-xl text-ink sm:text-2xl">Stuck? Send a voice message</h2>
                <p className="mt-1 text-sm text-graphite">
                  Say where you are and what is happening. Speak clearly if you can.
                </p>
                <div className="mt-6">
                  <VoiceRecorder onChange={setRecording} />
                </div>
              </div>

              {/* Photo Upload Option */}
              <PhotoPicker photos={photos} onPhotosChange={setPhotos} disabled={sending} />

              <WhileYouWait />
            </div>

            <div>
              <SosDetails
                values={values}
                onChange={setValues}
                errors={errors}
                geoState={geoState}
                onShareLocation={shareLocation}
              />

              {errors.form ? (
                <div className="mt-4 flex items-start gap-2.5 rounded-xl bg-sev-critical/5 p-3 ring-1 ring-sev-critical/20" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-sev-critical" aria-hidden="true" />
                  <p className="text-xs leading-relaxed text-sev-critical">{errors.form}</p>
                </div>
              ) : null}

              {submitError ? (
                <div className="mt-4 flex items-start gap-3 rounded-xl bg-sev-critical/5 p-3 ring-1 ring-sev-critical/20" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-sev-critical" aria-hidden="true" />
                  <div className="flex-1">
                    <p className="text-xs leading-relaxed text-sev-critical">{submitError}</p>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={handleSend}
                      disabled={sending}
                      className="mt-2 h-8 rounded-lg border-sev-critical/30 text-xs text-sev-critical"
                    >
                      <RotateCw className="mr-1.5 h-3 w-3" aria-hidden="true" />
                      Retry
                    </Button>
                  </div>
                </div>
              ) : null}

              {liveCalculatedSeverity && (
                <div className="mt-4 flex items-center justify-between rounded-xl bg-canvas p-3 ring-1 ring-black/5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-graphite">Calculated Severity:</span>
                    <span className={cn('rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider ring-1', liveSeverityMeta.chip)}>
                      {liveSeverityMeta.label}
                    </span>
                  </div>
                  <span className="text-[11px] text-graphite">
                    Live voice & keyword analysis
                  </span>
                </div>
              )}

              <Button
                type="button"
                onClick={handleSend}
                disabled={sending}
                className="mt-4 h-14 w-full rounded-xl bg-[#C1121F] text-base font-semibold text-white shadow-lift transition-colors hover:bg-[#A50F1A] disabled:opacity-70"
              >
                {sending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                    Sending your SOS…
                  </>
                ) : (
                  'Send SOS to rescue team'
                )}
              </Button>
              <p className="mt-2 text-center text-[11px] text-graphite">
                Your voice message and location are shared with the rescue team.
              </p>

              {/* Track an existing SOS by reference */}
              <div className="mt-8 rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5">
                <h3 className="text-sm font-semibold text-ink flex items-center gap-1.5">
                  <Search className="h-4 w-4 text-steel" />
                  Track an existing SOS
                </h3>
                <p className="mt-1 text-xs text-graphite">
                  Have a reference number from a previous request? Enter it here to see live response updates.
                </p>
                <form onSubmit={handleTrackSubmit} className="mt-3 flex gap-2">
                  <Input
                    placeholder="e.g. 7K4PX9WZ"
                    value={trackInput}
                    onChange={(e) => setTrackInput(e.target.value.toUpperCase())}
                    maxLength={8}
                    className="h-10 rounded-xl font-mono text-sm tracking-wider"
                  />
                  <Button
                    type="submit"
                    variant="outline"
                    className="h-10 rounded-xl border-ink/15 text-xs font-semibold text-steel hover:text-ink shrink-0"
                  >
                    Track
                  </Button>
                </form>
              </div>
            </div>
          </div>
        )}
      </section>
    </AppShell>
  );
}
