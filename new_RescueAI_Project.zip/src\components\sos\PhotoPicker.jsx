import React, { useRef, useState, useEffect } from 'react';
import { Camera, ImagePlus, X, RefreshCw, Check, AlertCircle, FlipHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

const MAX_PHOTOS = 4;
const MAX_FILE_SIZE = 8 * 1024 * 1024; // 8MB

/**
 * PhotoPicker:
 * - "Take Photo with Camera": Opens a live camera viewfinder (webcam/phone camera) with real-time stream and capture shutter.
 * - "Upload from Gallery / Files": Opens the native device file/gallery picker.
 */
export default function PhotoPicker({ photos = [], onPhotosChange, disabled = false }) {
  const fileInputRef = useRef(null);

  // Live Camera state
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [cameraStream, setCameraStream] = useState(null);
  const [facingMode, setFacingMode] = useState('environment'); // 'environment' (back) or 'user' (front)
  const [cameraError, setCameraError] = useState('');
  const [capturedBlob, setCapturedBlob] = useState(null);
  const [capturedPreview, setCapturedPreview] = useState('');
  const [isCapturing, setIsCapturing] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Stop active camera stream helper
  const stopStream = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  };

  // Start live camera stream
  const startCamera = async (mode = facingMode) => {
    stopStream();
    setCameraError('');
    setCapturedBlob(null);
    setCapturedPreview('');

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access is not supported by your current browser.');
      }

      const constraints = {
        video: {
          facingMode: { ideal: mode },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setCameraStream(stream);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
    } catch (err) {
      console.warn('Camera stream error:', err);
      let msg = 'Unable to access live camera. Please grant camera permission in your browser.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Camera permission was denied. Please allow camera access in your browser settings.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No camera device found on this system.';
      }
      setCameraError(msg);
    }
  };

  // Open live camera modal
  const handleOpenLiveCamera = () => {
    setIsCameraOpen(true);
    startCamera(facingMode);
  };

  // Close live camera modal
  const handleCloseCamera = () => {
    stopStream();
    if (capturedPreview && capturedPreview.startsWith('blob:')) {
      URL.revokeObjectURL(capturedPreview);
    }
    setCapturedBlob(null);
    setCapturedPreview('');
    setIsCameraOpen(false);
    setCameraError('');
  };

  // Flip camera between front and back
  const handleToggleFacingMode = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    startCamera(nextMode);
  };

  // Shutter: Take snapshot from live video stream
  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;

    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;

    let canvas = canvasRef.current;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvasRef.current = canvas;
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // If front camera, flip horizontally for natural mirror image
    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, 0, 0, width, height);

    setIsCapturing(true);
    setTimeout(() => setIsCapturing(false), 200);

    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const previewUrl = URL.createObjectURL(blob);
        setCapturedBlob(blob);
        setCapturedPreview(previewUrl);
        // Pause video while reviewing
        video.pause();
      },
      'image/jpeg',
      0.88
    );
  };

  // Retake photo: resume live stream
  const handleRetake = () => {
    if (capturedPreview && capturedPreview.startsWith('blob:')) {
      URL.revokeObjectURL(capturedPreview);
    }
    setCapturedBlob(null);
    setCapturedPreview('');
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  // Accept and add photo to list
  const handleAcceptPhoto = () => {
    if (!capturedBlob) return;

    const fileName = `live-photo-${Date.now()}.jpg`;
    const file = new File([capturedBlob], fileName, { type: 'image/jpeg' });

    const newPhoto = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      file,
      previewUrl: capturedPreview,
      name: fileName
    };

    onPhotosChange([...photos, newPhoto]);

    // If slots remain, user can take another or close
    if (photos.length + 1 >= MAX_PHOTOS) {
      handleCloseCamera();
    } else {
      setCapturedBlob(null);
      setCapturedPreview('');
      if (videoRef.current) {
        videoRef.current.play().catch(() => {});
      }
    }
  };

  // Bind video element when stream is ready
  useEffect(() => {
    if (isCameraOpen && cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
      videoRef.current.play().catch(() => {});
    }
  }, [isCameraOpen, cameraStream]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopStream();
    };
  }, []);

  // Handle file picker selection from gallery
  const handleGalleryFiles = (files) => {
    if (!files || files.length === 0) return;

    const remainingSlots = MAX_PHOTOS - photos.length;
    if (remainingSlots <= 0) return;

    const selectedFiles = Array.from(files).slice(0, remainingSlots);
    const validPhotos = [];

    for (const file of selectedFiles) {
      if (!file.type.startsWith('image/')) {
        continue;
      }
      if (file.size > MAX_FILE_SIZE) {
        alert(`Photo "${file.name}" is over 8MB. Please choose a smaller photo.`);
        continue;
      }
      const previewUrl = URL.createObjectURL(file);
      validPhotos.push({
        id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        file,
        previewUrl,
        name: file.name
      });
    }

    if (validPhotos.length > 0) {
      onPhotosChange([...photos, ...validPhotos]);
    }
  };

  const handleFileInputChange = (e) => {
    handleGalleryFiles(e.target.files);
    e.target.value = '';
  };

  const removePhoto = (id) => {
    const target = photos.find((p) => p.id === id);
    if (target && target.previewUrl && target.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(target.previewUrl);
    }
    onPhotosChange(photos.filter((p) => p.id !== id));
  };

  const canAddMore = photos.length < MAX_PHOTOS && !disabled;

  return (
    <div className="rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5 sm:p-7">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-xl text-ink sm:text-2xl flex items-center gap-2">
            <Camera className="h-5 w-5 text-coral" aria-hidden="true" />
            Attach Incident Photos
          </h2>
          <p className="mt-1 text-sm text-graphite">
            Take a live photo or select from your gallery (up to {MAX_PHOTOS} photos).
          </p>
        </div>
        {photos.length > 0 && (
          <span className="rounded-full bg-coral/10 px-3 py-1 text-xs font-semibold text-coral ring-1 ring-coral/20">
            {photos.length} / {MAX_PHOTOS}
          </span>
        )}
      </div>

      {/* Hidden Gallery Input (Gallery / Files only, no capture attribute) */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFileInputChange}
        disabled={disabled || !canAddMore}
      />

      {/* Photos Thumbnail Grid */}
      <div className="mt-4">
        {photos.length > 0 && (
          <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {photos.map((item, index) => (
              <div
                key={item.id}
                className="group relative aspect-square overflow-hidden rounded-xl border border-steel/20 bg-slate-100 shadow-xs"
              >
                <img
                  src={item.previewUrl}
                  alt={`Emergency upload ${index + 1}`}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                {!disabled && (
                  <button
                    type="button"
                    onClick={() => removePhoto(item.id)}
                    aria-label={`Remove photo ${index + 1}`}
                    className="absolute right-1.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-black/70 text-white shadow-sm transition hover:bg-coral"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
                <div className="absolute bottom-1 left-1.5 rounded bg-black/60 px-1.5 py-0.5 text-[10px] font-medium text-white">
                  Photo {index + 1}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Buttons: Live Camera Shutter vs Gallery File Explorer */}
        {canAddMore ? (
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {/* Live Camera Button */}
            <Button
              type="button"
              variant="outline"
              disabled={disabled}
              onClick={handleOpenLiveCamera}
              className="h-11 rounded-xl border-dashed border-coral/60 bg-coral/5 text-xs font-semibold text-coral hover:bg-coral/10 hover:border-coral transition"
            >
              <Camera className="mr-2 h-4 w-4 text-coral" />
              Take Live Photo with Camera
            </Button>

            {/* Gallery / File Explorer Button */}
            <Button
              type="button"
              variant="outline"
              disabled={disabled}
              onClick={() => fileInputRef.current?.click()}
              className="h-11 rounded-xl border-dashed border-steel/30 bg-canvas text-xs font-semibold text-ink hover:bg-white hover:border-steel/60 transition"
            >
              <ImagePlus className="mr-2 h-4 w-4 text-steel" />
              Upload from Gallery / Files
            </Button>
          </div>
        ) : (
          <p className="text-center text-xs text-graphite py-1">
            Maximum of {MAX_PHOTOS} photos attached. Click the &times; on any thumbnail to replace it.
          </p>
        )}
      </div>

      {/* LIVE CAMERA VIEWFINDER MODAL */}
      <Dialog open={isCameraOpen} onOpenChange={(open) => !open && handleCloseCamera()}>
        <DialogContent className="max-w-lg p-0 overflow-hidden bg-slate-950 text-white border-white/10 sm:rounded-2xl">
          <DialogHeader className="p-4 bg-slate-900 border-b border-white/10 flex flex-row items-center justify-between space-y-0">
            <DialogTitle className="text-sm font-semibold text-white flex items-center gap-2">
              <Camera className="h-4 w-4 text-coral" />
              Live Emergency Camera
            </DialogTitle>
            <div className="flex items-center gap-2">
              {/* Flip camera between front/back */}
              {!capturedPreview && !cameraError && (
                <button
                  type="button"
                  onClick={handleToggleFacingMode}
                  title="Switch Front/Back Camera"
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white hover:bg-white/20 transition"
                >
                  <FlipHorizontal className="h-4 w-4" />
                </button>
              )}
            </div>
          </DialogHeader>

          {/* Viewfinder Area */}
          <div className="relative aspect-[4/3] w-full bg-black flex items-center justify-center overflow-hidden">
            {cameraError ? (
              <div className="p-6 text-center max-w-sm">
                <AlertCircle className="mx-auto h-10 w-10 text-sev-critical mb-2" />
                <p className="text-sm text-slate-200">{cameraError}</p>
                <div className="mt-4 flex justify-center gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => startCamera(facingMode)}
                    className="border-white/20 text-white hover:bg-white/10 text-xs"
                  >
                    <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                    Retry Camera
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    onClick={() => {
                      handleCloseCamera();
                      fileInputRef.current?.click();
                    }}
                    className="bg-coral text-white hover:bg-[#D9614A] text-xs"
                  >
                    Use Gallery Instead
                  </Button>
                </div>
              </div>
            ) : capturedPreview ? (
              /* Review Captured Snapshot */
              <div className="relative h-full w-full">
                <img
                  src={capturedPreview}
                  alt="Captured emergency evidence"
                  className="h-full w-full object-cover"
                />
                <div className="absolute top-2 left-2 rounded-full bg-black/60 px-2.5 py-1 text-[11px] font-medium text-white flex items-center gap-1.5">
                  <Check className="h-3.5 w-3.5 text-sev-low" />
                  Photo Ready
                </div>
              </div>
            ) : (
              /* Live Video Stream */
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={cn(
                    'h-full w-full object-cover',
                    facingMode === 'user' && 'scale-x-[-1]'
                  )}
                />
                {/* Viewfinder crosshair overlay */}
                <div className="pointer-events-none absolute inset-6 border border-white/25 rounded-xl flex items-center justify-center">
                  <div className="h-4 w-4 border-t-2 border-l-2 border-coral absolute top-0 left-0 rounded-tl" />
                  <div className="h-4 w-4 border-t-2 border-r-2 border-coral absolute top-0 right-0 rounded-tr" />
                  <div className="h-4 w-4 border-b-2 border-l-2 border-coral absolute bottom-0 left-0 rounded-bl" />
                  <div className="h-4 w-4 border-b-2 border-r-2 border-coral absolute bottom-0 right-0 rounded-br" />
                </div>

                {/* Shutter flash effect */}
                {isCapturing && (
                  <div className="absolute inset-0 bg-white animate-fade-out" />
                )}
              </>
            )}
          </div>

          {/* Shutter & Action Footer */}
          <div className="p-4 bg-slate-900 border-t border-white/10 flex items-center justify-between">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleCloseCamera}
              className="border-white/20 text-white hover:bg-white/10 text-xs"
            >
              Cancel
            </Button>

            {!cameraError && (
              <>
                {capturedPreview ? (
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleRetake}
                      className="border-white/20 text-white hover:bg-white/10 text-xs"
                    >
                      <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                      Retake
                    </Button>

                    <Button
                      type="button"
                      size="sm"
                      onClick={handleAcceptPhoto}
                      className="bg-coral text-white hover:bg-[#D9614A] text-xs font-semibold px-4"
                    >
                      <Check className="mr-1.5 h-3.5 w-3.5" />
                      Attach Photo
                    </Button>
                  </div>
                ) : (
                  /* Shutter button */
                  <button
                    type="button"
                    onClick={handleCaptureSnapshot}
                    aria-label="Capture live photo"
                    className="group relative flex h-16 w-16 items-center justify-center rounded-full bg-white/20 p-1 transition hover:scale-105 active:scale-95"
                  >
                    <div className="h-12 w-12 rounded-full bg-coral group-hover:bg-[#ff6457] transition shadow-md flex items-center justify-center">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                  </button>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
