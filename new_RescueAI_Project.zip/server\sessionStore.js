import session from 'express-session';
import { query, queryOne } from './db.js';

/**
 * UniversalSessionStore:
 * Seamlessly stores Express sessions in Neon PostgreSQL (table: session)
 * or SQLite (table: sessions) without connection-drop bugs.
 */
export async function createSessionStore() {
  const isPg = Boolean(process.env.DATABASE_URL);
  const tableName = isPg ? 'session' : 'sessions';
  const Store = session.Store;

  class DatabaseSessionStore extends Store {
    constructor() {
      super();
    }

    async get(sid, callback) {
      try {
        const row = await queryOne(`SELECT sess, expire FROM ${tableName} WHERE sid = ?`, [sid]);
        if (!row) return callback(null, null);

        const expireTime = isPg ? new Date(row.expire).getTime() : Number(row.expire);
        if (expireTime < Date.now()) {
          await query(`DELETE FROM ${tableName} WHERE sid = ?`, [sid]);
          return callback(null, null);
        }

        const sess = typeof row.sess === 'string' ? JSON.parse(row.sess) : row.sess;
        callback(null, sess);
      } catch (err) {
        callback(err);
      }
    }

    async set(sid, sess, callback) {
      try {
        const maxAge = sess.cookie?.maxAge || 86400000;
        const sessStr = JSON.stringify(sess);

        if (isPg) {
          const expire = new Date(Date.now() + maxAge).toISOString();
          await query(
            'INSERT INTO session (sid, sess, expire) VALUES (?, ?::json, ?::timestamptz) ON CONFLICT (sid) DO UPDATE SET sess = EXCLUDED.sess, expire = EXCLUDED.expire',
            [sid, sessStr, expire]
          );
        } else {
          const expire = Date.now() + maxAge;
          const existing = await queryOne('SELECT sid FROM sessions WHERE sid = ?', [sid]);
          if (existing) {
            await query('UPDATE sessions SET sess = ?, expire = ? WHERE sid = ?', [sessStr, expire, sid]);
          } else {
            await query('INSERT INTO sessions (sid, sess, expire) VALUES (?, ?, ?)', [sid, sessStr, expire]);
          }
        }
        callback(null);
      } catch (err) {
        callback(err);
      }
    }

    async destroy(sid, callback) {
      try {
        await query(`DELETE FROM ${tableName} WHERE sid = ?`, [sid]);
        callback(null);
      } catch (err) {
        callback(err);
      }
    }

    async touch(sid, sess, callback) {
      try {
        const maxAge = sess.cookie?.maxAge || 86400000;
        if (isPg) {
          const expire = new Date(Date.now() + maxAge).toISOString();
          await query('UPDATE session SET expire = ?::timestamptz WHERE sid = ?', [expire, sid]);
        } else {
          const expire = Date.now() + maxAge;
          await query('UPDATE sessions SET expire = ? WHERE sid = ?', [expire, sid]);
        }
        callback(null);
      } catch (err) {
        callback(err);
      }
    }
  }

  return new DatabaseSessionStore();
}
