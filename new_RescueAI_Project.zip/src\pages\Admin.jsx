import { useCallback, useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Activity, Check, Loader2, ShieldCheck, UserX, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppShell from '@/components/AppShell';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

function toItems(response) {
  if (Array.isArray(response)) return response;
  return response?.items || [];
}

const STATUS_CHIP = {
  pending: 'bg-sev-medium/15 text-[#8A6410] ring-sev-medium/30',
  approved: 'bg-sev-low/10 text-sev-low ring-sev-low/25',
  rejected: 'bg-sev-critical/10 text-sev-critical ring-sev-critical/25'
};

export default function Admin() {
  const { user, isAuthenticated, isLoadingAuth, authChecked, navigateToLogin } = useAuth();
  const { toast } = useToast();
  const [requests, setRequests] = useState(null);
  const [members, setMembers] = useState(null);
  const [activity, setActivity] = useState(null);
  const [busyId, setBusyId] = useState('');

  const isAdmin = Boolean(isAuthenticated && user?.role === 'admin');

  const load = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const [requestPage, usersResponse] = await Promise.all([
        base44.entities.TeamRequest.filter({}, { sort: '-created_date', limit: 100 }),
        base44.entities.User.list({ limit: 200 })
      ]);
      const allUsers = toItems(usersResponse);
      const userMap = new Map(allUsers.map((row) => [row.id, row]));
      setRequests(
        toItems(requestPage).map((row) => ({
          ...row,
          requester_email: userMap.get(row.created_by_id)?.email || ''
        }))
      );
      setMembers(allUsers.filter((row) => row.role === 'admin' || row.staff_type === 'rescue_team'));
    } catch (err) {
      setRequests([]);
      setMembers([]);
      toast({
        variant: 'destructive',
        title: 'Could not load admin data',
        description: err?.message || 'Please try again.'
      });
    }
  }, [isAdmin, toast]);

  const loadActivity = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const res = await fetch('/api/team/events', { credentials: 'include' });
      const json = await res.json();
      setActivity(json.items || []);
    } catch {
      setActivity([]);
    }
  }, [isAdmin]);

  useEffect(() => {
    load();
    loadActivity();
  }, [load, loadActivity]);

  const approve = async (request) => {
    setBusyId(request.id);
    try {
      await base44.entities.User.update(request.created_by_id, { staff_type: 'rescue_team' });
      await base44.entities.TeamRequest.update(request.id, { status: 'approved' });
      toast({
        title: 'Access granted',
        description: `${request.full_name} can now open the rescue team dashboard.`
      });
      await load();
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Could not approve',
        description: err?.message || 'Please try again.'
      });
    } finally {
      setBusyId('');
    }
  };

  const reject = async (request) => {
    setBusyId(request.id);
    try {
      await base44.entities.TeamRequest.update(request.id, { status: 'rejected' });
      toast({ title: 'Request rejected' });
      await load();
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Could not reject',
        description: err?.message || 'Please try again.'
      });
    } finally {
      setBusyId('');
    }
  };

  const removeAccess = async (member) => {
    setBusyId(member.id);
    try {
      await base44.entities.User.update(member.id, { staff_type: '' });
      toast({
        title: 'Access removed',
        description: `${member.full_name || member.email} no longer has rescue team access.`
      });
      await load();
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Could not remove access',
        description: err?.message || 'Please try again.'
      });
    } finally {
      setBusyId('');
    }
  };

  if (isLoadingAuth || !authChecked) {
    return (
      <AppShell showSosFab={false}>
        <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
          <Skeleton className="h-10 w-56" />
          <Skeleton className="mt-6 h-32 w-full rounded-[16px]" />
          <Skeleton className="mt-4 h-32 w-full rounded-[16px]" />
        </div>
      </AppShell>
    );
  }

  const gate = (message) => (
    <AppShell showSosFab={false}>
      <div className="mx-auto max-w-lg px-4 py-16 text-center sm:py-24">
        <ShieldCheck className="mx-auto h-10 w-10 text-steel" aria-hidden="true" />
        <h1 className="mt-4 font-heading text-2xl text-ink sm:text-3xl">Admins only</h1>
        <p className="mt-2 text-sm leading-relaxed text-graphite">{message}</p>
        {!isAuthenticated ? (
          <Button
            type="button"
            onClick={navigateToLogin}
            className="mt-5 h-11 rounded-xl bg-coral px-6 text-sm font-semibold text-white hover:bg-[#D9614A]"
          >
            Sign in
          </Button>
        ) : null}
      </div>
    </AppShell>
  );

  if (!isAuthenticated) {
    return gate('Sign in with an administrator account to manage rescue team access.');
  }

  if (!isAdmin) {
    return gate('Your account does not have administrator access to this page.');
  }

  const sortedRequests = [...(requests || [])].sort((a, b) =>
    (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1)
  );

  return (
    <AppShell showSosFab={false}>
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-10">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-coral">
          Administration
        </p>
        <h1 className="mt-1 font-heading text-2xl text-ink sm:text-3xl">Rescue Operations Admin</h1>

        <Tabs defaultValue="access" className="mt-6">
          <TabsList className="grid w-full max-w-xs grid-cols-2 rounded-xl bg-white p-1 shadow-soft ring-1 ring-black/5">
            <TabsTrigger value="access" className="rounded-lg text-sm">
              Team Access
            </TabsTrigger>
            <TabsTrigger value="activity" className="rounded-lg text-sm">
              Activity Audit
            </TabsTrigger>
          </TabsList>

          <TabsContent value="access" className="mt-6 space-y-8">
            <section>
              <h2 className="text-sm font-semibold text-ink">Access requests</h2>
              {requests === null ? (
                <div className="mt-3 space-y-3">
                  <Skeleton className="h-28 w-full rounded-[16px]" />
                  <Skeleton className="h-28 w-full rounded-[16px]" />
                </div>
              ) : sortedRequests.length === 0 ? (
                <p className="mt-3 rounded-[16px] bg-white p-6 text-center text-sm text-graphite shadow-soft ring-1 ring-black/5">
                  No access requests yet. Responders can request access from the Rescue Team page.
                </p>
              ) : (
                <ul className="mt-3 space-y-3">
                  {sortedRequests.map((request) => (
                    <li key={request.id} className="rounded-[16px] bg-white p-4 shadow-soft ring-1 ring-black/5">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-semibold text-ink">{request.full_name}</p>
                        <span
                          className={cn(
                            'rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ring-1',
                            STATUS_CHIP[request.status] || 'bg-canvas text-graphite ring-ink/10'
                          )}
                        >
                          {request.status}
                        </span>
                        {request.requester_email ? (
                          <span className="text-xs text-graphite">{request.requester_email}</span>
                        ) : null}
                      </div>
                      <p className="mt-1 text-xs text-graphite">
                        {[request.organization, request.phone].filter(Boolean).join(' · ') ||
                          'No organization or phone given'}
                      </p>
                      {request.reason ? (
                        <p className="mt-2 rounded-lg bg-canvas px-3 py-2 text-xs leading-relaxed text-ink/80">
                          {request.reason}
                        </p>
                      ) : null}
                      {request.status === 'pending' ? (
                        <div className="mt-3 flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            disabled={busyId === request.id}
                            onClick={() => approve(request)}
                            className="h-9 rounded-lg bg-sev-low text-white hover:bg-[#23897C]"
                          >
                            {busyId === request.id ? (
                              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                            ) : (
                              <Check className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                            )}
                            Approve
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            disabled={busyId === request.id}
                            onClick={() => reject(request)}
                            className="h-9 rounded-lg border-sev-critical/30 text-sev-critical"
                          >
                            <X className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                            Reject
                          </Button>
                        </div>
                      ) : null}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section>
              <h2 className="text-sm font-semibold text-ink">Team members</h2>
              {members === null ? (
                <div className="mt-3 space-y-2">
                  <Skeleton className="h-14 w-full rounded-xl" />
                  <Skeleton className="h-14 w-full rounded-xl" />
                </div>
              ) : members.length === 0 ? (
                <p className="mt-3 rounded-[16px] bg-white p-6 text-center text-sm text-graphite shadow-soft ring-1 ring-black/5">
                  No team members yet.
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {members.map((member) => (
                    <li
                      key={member.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white px-4 py-3 shadow-soft ring-1 ring-black/5"
                    >
                      <div>
                        <p className="text-sm font-medium text-ink">{member.full_name || member.email}</p>
                        <p className="text-[11px] text-graphite">
                          {member.email}
                          {member.role === 'admin' ? ' · admin' : ' · rescue team'}
                        </p>
                      </div>
                      {member.staff_type === 'rescue_team' ? (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={busyId === member.id}
                          onClick={() => removeAccess(member)}
                          className="h-8 rounded-lg text-xs"
                        >
                          {busyId === member.id ? (
                            <Loader2 className="mr-1.5 h-3 w-3 animate-spin" aria-hidden="true" />
                          ) : (
                            <UserX className="mr-1.5 h-3 w-3" aria-hidden="true" />
                          )}
                          Remove access
                        </Button>
                      ) : null}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-ink">Audit Trail Activity Across All SOS</h2>
              <Button type="button" size="sm" variant="outline" onClick={loadActivity} className="h-8 rounded-lg text-xs">
                Refresh
              </Button>
            </div>

            {activity === null ? (
              <div className="space-y-2">
                <Skeleton className="h-16 w-full rounded-xl" />
                <Skeleton className="h-16 w-full rounded-xl" />
              </div>
            ) : activity.length === 0 ? (
              <p className="rounded-[16px] bg-white p-8 text-center text-sm text-graphite shadow-soft ring-1 ring-black/5">
                No activity events logged yet.
              </p>
            ) : (
              <div className="rounded-[16px] bg-white p-4 shadow-soft ring-1 ring-black/5">
                <ul className="divide-y divide-ink/5">
                  {activity.map((ev) => (
                    <li key={ev.id} className="py-3 flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-canvas text-steel">
                            {ev.reference_id || 'SOS'}
                          </span>
                          <span className="font-medium text-xs text-ink capitalize">
                            {ev.type?.replace('_', ' ')}
                          </span>
                          <span className="text-xs text-graphite">
                            by {ev.actor_name || 'System'}
                          </span>
                        </div>
                        {ev.note && <p className="mt-1 text-xs text-ink/80">{ev.note}</p>}
                      </div>
                      <span className="font-mono text-[11px] text-graphite shrink-0">
                        {ev.created_at ? format(new Date(ev.created_at), 'dd MMM HH:mm:ss') : ''}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}
