import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * High-performance, cinematic Three.js 3D Earth scene for RescueAI.
 * Features:
 * - High-detail procedural continent map with tactical data-matrix dot grid & glowing coastlines
 * - Realistic day/night terminator lighting with deep oceanic specularity
 * - Electric-blue atmospheric Fresnel rim glow shader
 * - Pulsing emergency distress beacons (red radar pulses & vertical light beams)
 * - Animated 3D Great-Circle rescue paths with traveling light pulses
 * - Drifting stardust particles in deep space
 * - Smooth mouse parallax with inertial damping (lerp) & touch drag support
 * - Reduced motion support
 */

// Major global coordinates for emergency distress beacons
const EMERGENCY_NODES = [
  { name: 'Tokyo', lat: 35.68, lng: 139.76, severity: 'critical' },
  { name: 'New York', lat: 40.71, lng: -74.0, severity: 'critical' },
  { name: 'London', lat: 51.51, lng: -0.13, severity: 'warning' },
  { name: 'Mumbai', lat: 19.07, lng: 72.88, severity: 'critical' },
  { name: 'Sydney', lat: -33.87, lng: 151.21, severity: 'warning' },
  { name: 'Cairo', lat: 30.04, lng: 31.24, severity: 'critical' },
  { name: 'São Paulo', lat: -23.55, lng: -46.63, severity: 'warning' },
  { name: 'San Francisco', lat: 37.77, lng: -122.42, severity: 'critical' },
  { name: 'Jakarta', lat: -6.2, lng: 106.85, severity: 'critical' },
  { name: 'Nairobi', lat: -1.29, lng: 36.82, severity: 'warning' }
];

// Active rescue coordination paths connecting nodes
const RESCUE_ARCS = [
  [1, 7], // New York <-> San Francisco
  [7, 0], // San Francisco <-> Tokyo
  [0, 8], // Tokyo <-> Jakarta
  [8, 3], // Jakarta <-> Mumbai
  [3, 5], // Mumbai <-> Cairo
  [5, 2], // Cairo <-> London
  [2, 1], // London <-> New York
  [1, 6], // New York <-> São Paulo
  [8, 4], // Jakarta <-> Sydney
  [5, 9]  // Cairo <-> Nairobi
];

function latLngToVector3(lat, lng, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

/**
 * Generates an ultra-crisp, procedural equirectangular world continent texture
 * on an offscreen HTML5 canvas. Features glowing coastlines, landmass fill,
 * tactical grid dots, and illuminated metropolis points.
 */
function createEarthCanvasTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // 1. Deep oceanic gradient base
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  oceanGrad.addColorStop(0, '#030818');
  oceanGrad.addColorStop(0.5, '#020512');
  oceanGrad.addColorStop(1, '#030818');
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 2. Subtle latitude & longitude graticule grid
  ctx.strokeStyle = 'rgba(34, 211, 238, 0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= canvas.width; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y <= canvas.height; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // 3. Simplified Continental Polygons (Normalized 0..1 to canvas dimensions)
  const W = canvas.width;
  const H = canvas.height;

  // Projection conversion: lon (-180..180) -> x (0..W), lat (90..-90) -> y (0..H)
  const toXY = (lon, lat) => [((lon + 180) / 360) * W, ((90 - lat) / 180) * H];

  const drawPolygon = (coords, fillStyle, strokeStyle) => {
    if (coords.length < 3) return;
    ctx.beginPath();
    const [startX, startY] = toXY(coords[0][0], coords[0][1]);
    ctx.moveTo(startX, startY);
    for (let i = 1; i < coords.length; i++) {
      const [x, y] = toXY(coords[i][0], coords[i][1]);
      ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = fillStyle;
    ctx.fill();
    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      ctx.lineWidth = 1.6;
      ctx.stroke();
    }
  };

  // Major continental landmass approximations (Longitude, Latitude)
  // North America
  const northAmerica = [
    [-168, 66], [-140, 70], [-100, 74], [-80, 70], [-60, 50],
    [-70, 42], [-76, 35], [-81, 25], [-97, 26], [-98, 19],
    [-88, 16], [-83, 10], [-77, 8], [-80, 9], [-92, 14],
    [-105, 20], [-115, 30], [-124, 38], [-124, 48], [-135, 57],
    [-160, 58], [-168, 66]
  ];

  // South America
  const southAmerica = [
    [-77, 8], [-60, 5], [-50, -2], [-35, -5], [-37, -13],
    [-42, -22], [-50, -30], [-65, -45], [-70, -55], [-75, -50],
    [-72, -40], [-71, -30], [-76, -15], [-81, -5], [-77, 8]
  ];

  // Europe
  const europe = [
    [-10, 36], [0, 38], [15, 40], [25, 36], [28, 42],
    [32, 45], [40, 42], [50, 48], [40, 56], [30, 60],
    [25, 71], [15, 65], [5, 60], [-5, 58], [-5, 48],
    [-10, 44], [-10, 36]
  ];

  // Africa
  const africa = [
    [-6, 36], [10, 37], [25, 32], [32, 31], [35, 28],
    [43, 12], [51, 12], [42, -2], [40, -15], [32, -28],
    [27, -34], [18, -34], [12, -20], [10, -5], [2, 4],
    [-14, 11], [-17, 15], [-13, 28], [-6, 36]
  ];

  // Asia
  const asia = [
    [32, 45], [50, 48], [60, 55], [70, 73], [100, 78],
    [140, 72], [170, 65], [170, 60], [140, 50], [130, 38],
    [122, 30], [108, 20], [100, 10], [98, 3], [80, 8],
    [70, 20], [60, 25], [50, 30], [35, 32], [32, 45]
  ];

  // Australia
  const australia = [
    [114, -22], [125, -15], [136, -12], [142, -11], [150, -22],
    [153, -28], [150, -37], [138, -35], [130, -32], [116, -35],
    [113, -26], [114, -22]
  ];

  // Render landmasses with tactical fill & electric cyan glow rim
  const landFill = '#0C1630';
  const landStroke = 'rgba(34, 211, 238, 0.45)';

  [northAmerica, southAmerica, europe, africa, asia, australia].forEach((poly) => {
    drawPolygon(poly, landFill, landStroke);
  });

  // 4. Tactical Data Matrix: populate land areas with glowing micro-dots
  ctx.fillStyle = 'rgba(56, 189, 248, 0.28)';
  for (let i = 0; i < 2200; i++) {
    const rx = Math.random() * canvas.width;
    const ry = Math.random() * canvas.height;
    const p = ctx.getImageData(rx, ry, 1, 1).data;
    // Check if point lands on continent (blue channel > 20 and dark)
    if (p[0] === 12 && p[1] === 22 && p[2] === 48) {
      ctx.beginPath();
      ctx.arc(rx, ry, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 5. City night lights (clusters of golden-white micro lights)
  const cityClusters = [
    [-74, 40.7], [-122, 37.7], [-0.1, 51.5], [2.3, 48.8],
    [77.2, 28.6], [72.8, 19.0], [139.7, 35.7], [121.5, 31.2],
    [151.2, -33.9], [-46.6, -23.5], [31.2, 30.0]
  ];

  cityClusters.forEach(([lon, lat]) => {
    const [cx, cy] = toXY(lon, lat);
    for (let c = 0; c < 14; c++) {
      const ox = cx + (Math.random() - 0.5) * 22;
      const oy = cy + (Math.random() - 0.5) * 16;
      ctx.fillStyle = c === 0 ? 'rgba(255, 255, 255, 0.95)' : 'rgba(251, 191, 36, 0.65)';
      ctx.beginPath();
      ctx.arc(ox, oy, c === 0 ? 2 : 1, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.generateMipmaps = true;
  return texture;
}

export default function EarthScene() {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // Respect reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const width = mount.clientWidth || window.innerWidth;
    const height = mount.clientHeight || window.innerHeight;

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x02040a, 0.08);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7.2);

    // 2. WebGL Renderer with High-Precision Depth & Anti-Aliasing
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    mount.appendChild(renderer.domElement);

    // 3. Lighting: Cinematic Day/Night Crescent Terminator + Emergency Red Rim
    const ambientLight = new THREE.AmbientLight(0x0a1024, 1.8);
    scene.add(ambientLight);

    // Main primary sunlight (electric cyan-white from top right)
    const sunLight = new THREE.DirectionalLight(0xdbeafe, 3.2);
    sunLight.position.set(6, 4, 5);
    scene.add(sunLight);

    // Emergency red rim light (subtle red glow from shadow bottom-left)
    const emergencyRimLight = new THREE.DirectionalLight(0xef4444, 2.0);
    emergencyRimLight.position.set(-6, -3, -2);
    scene.add(emergencyRimLight);

    // Subtle blue fill light
    const fillLight = new THREE.PointLight(0x0284c7, 2.5, 20);
    fillLight.position.set(0, -5, 3);
    scene.add(fillLight);

    // 4. Main Globe Hierarchy
    const globeRadius = 2.0;
    const globeGroup = new THREE.Group();
    globeGroup.rotation.z = (23.5 * Math.PI) / 180; // Realistic axial tilt
    scene.add(globeGroup);

    // Earth Sphere Core
    const earthGeometry = new THREE.SphereGeometry(globeRadius, 64, 64);
    const earthTexture = createEarthCanvasTexture();
    const earthMaterial = new THREE.MeshStandardMaterial({
      map: earthTexture,
      roughness: 0.55,
      metalness: 0.2,
      emissive: new THREE.Color(0x020818),
      emissiveIntensity: 0.6
    });
    const earthMesh = new THREE.Mesh(earthGeometry, earthMaterial);
    globeGroup.add(earthMesh);

    // 5. Electric-Blue Atmospheric Fresnel Glow Shader
    const atmosphereVertexShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `;

    const atmosphereFragmentShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      uniform vec3 glowColor;
      void main() {
        vec3 viewDir = normalize(-vPosition);
        float intensity = pow(1.0 - max(dot(viewDir, vNormal), 0.0), 2.4);
        gl_FragColor = vec4(glowColor, intensity * 0.9);
      }
    `;

    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: atmosphereVertexShader,
      fragmentShader: atmosphereFragmentShader,
      uniforms: {
        glowColor: { value: new THREE.Color(0x22d3ee) }
      },
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false
    });

    const atmosphereMesh = new THREE.Mesh(
      new THREE.SphereGeometry(globeRadius * 1.15, 64, 64),
      atmosphereMaterial
    );
    globeGroup.add(atmosphereMesh);

    // Inner subtle glow shell
    const innerGlowMaterial = new THREE.ShaderMaterial({
      vertexShader: atmosphereVertexShader,
      fragmentShader: `
        varying vec3 vNormal;
        varying vec3 vPosition;
        void main() {
          vec3 viewDir = normalize(-vPosition);
          float intensity = pow(1.0 - max(dot(viewDir, vNormal), 0.0), 3.5);
          gl_FragColor = vec4(0.2, 0.6, 1.0, intensity * 0.45);
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.FrontSide,
      transparent: true,
      depthWrite: false
    });
    const innerGlowMesh = new THREE.Mesh(
      new THREE.SphereGeometry(globeRadius * 1.015, 64, 64),
      innerGlowMaterial
    );
    globeGroup.add(innerGlowMesh);

    // 6. Emergency Markers (Pulsing Red Beacons & Distress Beams)
    const beaconRings = [];
    const beaconGroup = new THREE.Group();
    globeGroup.add(beaconGroup);

    EMERGENCY_NODES.forEach((node) => {
      const pos = latLngToVector3(node.lat, node.lng, globeRadius);
      const normal = pos.clone().normalize();

      // Glowing central beacon dot
      const markerGeo = new THREE.SphereGeometry(0.038, 16, 16);
      const markerMat = new THREE.MeshBasicMaterial({
        color: node.severity === 'critical' ? 0xff2233 : 0xf97316
      });
      const markerMesh = new THREE.Mesh(markerGeo, markerMat);
      markerMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.015)));
      beaconGroup.add(markerMesh);

      // Vertical distress light beam shooting upward
      const beamHeight = 0.35;
      const beamGeo = new THREE.CylinderGeometry(0.003, 0.018, beamHeight, 8);
      const beamMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending
      });
      const beamMesh = new THREE.Mesh(beamGeo, beamMat);
      beamMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
      beamMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(beamHeight / 2)));
      beaconGroup.add(beamMesh);

      // Expanding radar pulse rings
      for (let r = 0; r < 2; r++) {
        const ringGeo = new THREE.RingGeometry(0.02, 0.05, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xef4444,
          transparent: true,
          opacity: 0.8,
          side: THREE.DoubleSide,
          blending: THREE.AdditiveBlending,
          depthWrite: false
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.02)));
        ringMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
        beaconGroup.add(ringMesh);

        beaconRings.push({
          mesh: ringMesh,
          initialScale: 0.2 + r * 0.5,
          scale: 0.2 + r * 0.5,
          speed: 0.018 + (r % 2) * 0.005,
          maxScale: 2.4
        });
      }
    });

    // 7. Animated 3D Great-Circle Rescue Arcs
    const arcPulses = [];
    const arcsGroup = new THREE.Group();
    globeGroup.add(arcsGroup);

    RESCUE_ARCS.forEach(([idxA, idxB], arcIndex) => {
      const nodeA = EMERGENCY_NODES[idxA];
      const nodeB = EMERGENCY_NODES[idxB];
      if (!nodeA || !nodeB) return;

      const pA = latLngToVector3(nodeA.lat, nodeA.lng, globeRadius);
      const pB = latLngToVector3(nodeB.lat, nodeB.lng, globeRadius);

      // Arc apex: elevation above globe surface proportional to distance
      const distance = pA.distanceTo(pB);
      const midPoint = pA.clone().add(pB).multiplyScalar(0.5);
      const elevation = globeRadius + distance * 0.28;
      midPoint.normalize().multiplyScalar(elevation);

      const curve = new THREE.QuadraticBezierCurve3(pA, midPoint, pB);
      const points = curve.getPoints(48);
      const arcGeometry = new THREE.BufferGeometry().setFromPoints(points);

      // Luminous cyan-blue rescue trajectory line
      const arcMaterial = new THREE.LineBasicMaterial({
        color: arcIndex % 2 === 0 ? 0x22d3ee : 0x6d5ef8,
        transparent: true,
        opacity: 0.45,
        blending: THREE.AdditiveBlending
      });
      const arcLine = new THREE.Line(arcGeometry, arcMaterial);
      arcsGroup.add(arcLine);

      // Traveling Rescue Pulse (Glowing moving light packet)
      const pulseGeo = new THREE.SphereGeometry(0.035, 12, 12);
      const pulseMat = new THREE.MeshBasicMaterial({
        color: arcIndex % 2 === 0 ? 0x38bdf8 : 0xef4444,
        blending: THREE.AdditiveBlending
      });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      arcsGroup.add(pulseMesh);

      arcPulses.push({
        curve,
        mesh: pulseMesh,
        progress: (arcIndex * 0.15) % 1.0,
        speed: 0.0035 + (arcIndex % 3) * 0.0012
      });
    });

    // 8. Stardust Particles in Deep Space
    const particleCount = 650;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const pRadius = globeRadius * (1.3 + Math.random() * 2.8);
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      particlePositions[i * 3] = pRadius * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = pRadius * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = pRadius * Math.cos(phi);
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.024,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // 9. Interactive Mouse Parallax & Touch Handling
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;
    let isDragging = false;
    let previousPointerX = 0;
    let previousPointerY = 0;

    const handlePointerMove = (e) => {
      if (prefersReducedMotion) return;
      const clientX = e.clientX || (e.touches && e.touches[0]?.clientX) || 0;
      const clientY = e.clientY || (e.touches && e.touches[0]?.clientY) || 0;

      if (isDragging) {
        const deltaX = clientX - previousPointerX;
        const deltaY = clientY - previousPointerY;
        globeGroup.rotation.y += deltaX * 0.005;
        globeGroup.rotation.x += deltaY * 0.005;
        previousPointerX = clientX;
        previousPointerY = clientY;
      } else {
        targetX = (clientX / window.innerWidth - 0.5) * 0.6;
        targetY = (clientY / window.innerHeight - 0.5) * 0.4;
      }
    };

    const handlePointerDown = (e) => {
      isDragging = true;
      previousPointerX = e.clientX || (e.touches && e.touches[0]?.clientX) || 0;
      previousPointerY = e.clientY || (e.touches && e.touches[0]?.clientY) || 0;
    };

    const handlePointerUp = () => {
      isDragging = false;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchstart', handlePointerDown, { passive: true });
    window.addEventListener('touchend', handlePointerUp);

    // 10. Smooth Window Resize Observer
    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 11. Main 60FPS Animation Loop
    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Smooth auto-rotation of Earth
      if (!isDragging && !prefersReducedMotion) {
        globeGroup.rotation.y += 0.0022;

        // Mouse Parallax with Damped Inertial Lerp
        mouseX += (targetX - mouseX) * 0.04;
        mouseY += (targetY - mouseY) * 0.04;
        camera.position.x = mouseX * 1.5;
        camera.position.y = -mouseY * 1.2;
        camera.lookAt(0, 0, 0);

        // Gentle space particle drift
        particles.rotation.y -= 0.0006;
      }

      // Animate pulsing emergency beacon rings
      beaconRings.forEach((ring) => {
        ring.scale += ring.speed;
        if (ring.scale > ring.maxScale) {
          ring.scale = ring.initialScale;
        }
        ring.mesh.scale.set(ring.scale, ring.scale, ring.scale);
        const opacityProgress = (ring.scale - ring.initialScale) / (ring.maxScale - ring.initialScale);
        ring.mesh.material.opacity = Math.max(0, 0.85 * (1.0 - opacityProgress));
      });

      // Animate traveling rescue pulses along curves
      arcPulses.forEach((pulse) => {
        pulse.progress += pulse.speed;
        if (pulse.progress > 1.0) pulse.progress = 0;
        const currentPoint = pulse.curve.getPoint(pulse.progress);
        pulse.mesh.position.copy(currentPoint);
      });

      renderer.render(scene, camera);
    };

    animate();

    // Cleanup resources on unmount
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('touchend', handlePointerUp);
      window.removeEventListener('resize', handleResize);

      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
      earthGeometry.dispose();
      earthMaterial.dispose();
      earthTexture.dispose();
      atmosphereMaterial.dispose();
      innerGlowMaterial.dispose();
      particleGeo.dispose();
      particleMat.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full pointer-events-auto cursor-grab active:cursor-grabbing select-none"
      style={{ touchAction: 'none' }}
      aria-hidden="true"
    />
  );
}
