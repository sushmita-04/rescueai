import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

export default async function (req) {
  try {
    const body = await req.json().catch(() => ({}));
    const sosId = typeof body?.sos_id === 'string' ? body.sos_id.trim() : '';
    if (!sosId) return Response.json({ error: 'Missing sos id.' }, { status: 400 });

    const base44 = createClientFromRequest(req);
    const record = await base44.asServiceRole.entities.SOSRequest.get(sosId);
    if (!record) return Response.json({ error: 'not_found' }, { status: 404 });
    if (!record.audio_url) return Response.json({ skipped: true, reason: 'no_audio' });
    if (record.transcript) return Response.json({ transcript: record.transcript, cached: true });

    const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
      file_uri: record.audio_url,
      expires_in: 300
    });
    const audioUrl = signed?.signed_url;
    if (!audioUrl) return Response.json({ skipped: true, reason: 'unreachable_audio' });

    const raw = await base44.asServiceRole.integrations.Core.TranscribeAudio({ audio_url: audioUrl });
    const spoken = (typeof raw === 'string' ? raw : raw?.text || '').trim().slice(0, 2000);
    if (!spoken) return Response.json({ skipped: true, reason: 'empty_transcript' });

    let summary = spoken.slice(0, 300);
    try {
      const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `This is the transcript of a voice SOS from a disaster zone. Summarise it for a rescue dispatcher in one or two short sentences. Keep place names, numbers of people and landmarks. Reply with plain text only, no preamble.

Transcript: ${spoken}`
      });
      if (typeof aiResult === 'string' && aiResult.trim()) {
        summary = aiResult.trim().slice(0, 400);
      }
    } catch (error) {
      summary = spoken.slice(0, 300);
    }

    await base44.asServiceRole.entities.SOSRequest.update(sosId, { transcript: summary });
    return Response.json({ transcript: summary });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
