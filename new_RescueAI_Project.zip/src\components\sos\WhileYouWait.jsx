import { Battery, Hand, Megaphone, MoveRight } from 'lucide-react';

const TIPS = [
  { icon: Hand, title: 'Stay calm', text: 'Slow breaths. Help is on the way once your message is received.' },
  { icon: Battery, title: 'Save battery', text: 'Lower screen brightness and close apps you do not need.' },
  { icon: Megaphone, title: 'Signal at intervals', text: 'Tap on pipes or shout every few minutes so rescuers can hear you.' },
  { icon: MoveRight, title: 'Move only if safe', text: 'Stay put unless your current spot is becoming dangerous.' }
];

export default function WhileYouWait() {
  return (
    <div className="mt-6 rounded-xl bg-canvas p-4 ring-1 ring-ink/5">
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-graphite">While you wait</p>
      <ul className="mt-3 space-y-2.5">
        {TIPS.map((tip) => (
          <li key={tip.title} className="flex gap-2.5">
            <tip.icon className="mt-0.5 h-4 w-4 shrink-0 text-steel" aria-hidden="true" />
            <p className="text-xs leading-relaxed text-graphite">
              <span className="font-semibold text-ink">{tip.title}. </span>
              {tip.text}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}
