import React from 'react';
import { Lock, ShieldAlert, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function TeamGate({ variant, onSignIn, user, onLogout }) {
  const signedOut = variant === 'signed-out';

  if (signedOut) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-16 text-center sm:py-24">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-steel shadow-soft ring-1 ring-black/5">
          <Lock className="h-6 w-6 text-navy" aria-hidden="true" />
        </span>

        <h1 className="mt-5 font-heading text-2xl text-ink sm:text-3xl">
          Rescue Team Sign-In Required
        </h1>

        <p className="mt-3 text-sm leading-relaxed text-graphite">
          SOS distress messages contain live coordinates and audio recordings. The incoming dispatch
          queue is restricted to authorized rescue team members.
        </p>

        <div className="mt-6 flex flex-col items-center gap-3">
          <Button
            type="button"
            onClick={onSignIn}
            className="h-11 rounded-xl bg-coral px-6 text-sm font-semibold text-white hover:bg-[#D9614A]"
          >
            Rescue Team Login
          </Button>
        </div>
      </div>
    );
  }

  // Forbidden: Common User accessing Rescue Team pages
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-14 text-center sm:py-20">
      <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-steel shadow-soft ring-1 ring-black/5">
        <ShieldAlert className="h-6 w-6 text-coral" aria-hidden="true" />
      </span>

      <h1 className="mt-5 font-heading text-2xl text-ink sm:text-3xl">
        Rescue Team Access Required
      </h1>
      <p className="mt-3 text-sm leading-relaxed text-graphite">
        Your current account is registered as a common citizen user. The Rescue Team Dashboard is restricted to authorized emergency responders.
      </p>

      <div className="mt-6 flex flex-col items-center gap-3">
        <a
          href="/sos"
          className="inline-flex h-11 items-center justify-center rounded-xl bg-coral px-6 text-sm font-semibold text-white hover:bg-[#D9614A]"
        >
          Go to SOS Emergency Portal
        </a>

        <a
          href="/team-login?returnTo=/team"
          className="text-xs font-semibold text-navy hover:underline"
        >
          Sign in with Rescue Team credentials &rarr;
        </a>
      </div>

      <Button
        type="button"
        variant="outline"
        onClick={onLogout}
        className="mt-6 rounded-xl text-sm font-medium text-steel"
      >
        <LogOut className="mr-1.5 h-4 w-4" aria-hidden="true" />
        Logout
      </Button>
    </div>
  );
}
