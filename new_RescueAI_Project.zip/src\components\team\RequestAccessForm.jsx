import { useState } from 'react';
import { Loader2, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { base44 } from '@/api/base44Client';

export default function RequestAccessForm({ user, onSubmitted }) {
  const [values, setValues] = useState({
    full_name: user?.full_name || '',
    organization: '',
    phone: '',
    reason: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const update = (key, value) => {
    setValues((current) => ({ ...current, [key]: value }));
    setError('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (submitting) return;
    if (!values.full_name.trim() || !values.reason.trim()) {
      setError('Full name and reason are required.');
      return;
    }
    setSubmitting(true);
    try {
      const record = await base44.entities.TeamRequest.create({
        full_name: values.full_name.trim(),
        organization: values.organization.trim(),
        phone: values.phone.trim(),
        reason: values.reason.trim(),
        status: 'pending'
      });
      onSubmitted?.(record);
    } catch (err) {
      setError(err?.message || 'Could not send your request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-[16px] bg-white p-5 text-left shadow-soft ring-1 ring-black/5"
    >
      <h2 className="font-heading text-lg text-ink">Request rescue team access</h2>
      <p className="mt-1 text-xs leading-relaxed text-graphite">
        An administrator reviews every request. You will get access as soon as yours is approved.
      </p>

      <div className="mt-4 space-y-3">
        <div>
          <Label htmlFor="request-name" className="text-sm">
            Full name
          </Label>
          <Input
            id="request-name"
            className="mt-1.5 h-11 rounded-xl"
            value={values.full_name}
            onChange={(event) => update('full_name', event.target.value)}
            autoComplete="name"
          />
        </div>
        <div>
          <Label htmlFor="request-organization" className="text-sm">
            Organization
          </Label>
          <Input
            id="request-organization"
            className="mt-1.5 h-11 rounded-xl"
            value={values.organization}
            onChange={(event) => update('organization', event.target.value)}
            placeholder="Fire service, NDRF unit, NGO…"
          />
        </div>
        <div>
          <Label htmlFor="request-phone" className="text-sm">
            Phone
          </Label>
          <Input
            id="request-phone"
            className="mt-1.5 h-11 rounded-xl"
            value={values.phone}
            onChange={(event) => update('phone', event.target.value)}
            inputMode="tel"
            placeholder="+91…"
          />
        </div>
        <div>
          <Label htmlFor="request-reason" className="text-sm">
            Reason
          </Label>
          <Textarea
            id="request-reason"
            className="mt-1.5 min-h-[88px] rounded-xl"
            value={values.reason}
            onChange={(event) => update('reason', event.target.value)}
            placeholder="Why do you need rescue team access?"
          />
        </div>
      </div>

      {error ? <p className="mt-3 text-xs font-medium text-sev-critical">{error}</p> : null}

      <Button
        type="submit"
        disabled={submitting}
        className="mt-4 h-11 w-full rounded-xl bg-coral text-sm font-semibold text-white hover:bg-[#D9614A] disabled:opacity-70"
      >
        {submitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
            Sending…
          </>
        ) : (
          <>
            <Send className="mr-2 h-4 w-4" aria-hidden="true" />
            Send request
          </>
        )}
      </Button>
    </form>
  );
}
