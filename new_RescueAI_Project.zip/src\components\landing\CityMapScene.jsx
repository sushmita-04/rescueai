import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * 3D Emergency City Map Scene for RescueAI.
 * Meets exact color & style requirements:
 * - Medium slate-blue base: #C7D3E3 for terrain, #A9BBD1 for buildings, #8FA3BC for shadows/depth
 * - Roads: clean white or light blue #E8F0F8
 * - One emergency incident marker: controlled red-orange #E5484D with soft amber halo #FFB86B
 * - Response routes: trustworthy blue #2563EB and teal #0E9F8A
 * - Responder markers: clean professional pins in blue, teal, and amber
 * - Soft daylight lighting, gentle depth, realistic clean shadows
 * - No floating particles, no roaming small objects, no neon cyberpunk effects
 * - Minimal motion: gentle incident pulse and slow radar ring
 */
export default function CityMapScene() {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const width = mount.clientWidth || 640;
    const height = mount.clientHeight || 520;

    // 1. Scene & Isometric Perspective Camera Setup
    const scene = new THREE.Scene();
    scene.background = null; // Transparent so subtle page gradient shows through

    const aspect = width / height;
    const camera = new THREE.PerspectiveCamera(36, aspect, 0.1, 100);
    // Positioned in an elegant architectural isometric angle
    camera.position.set(14, 18, 16);
    camera.lookAt(0, 0, 0);

    // 2. High-Performance WebGL Renderer with Clean Soft Shadows
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    mount.appendChild(renderer.domElement);

    // 3. Soft Realistic Daylight Lighting
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xdde5ef, 1.25);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.6);
    dirLight.position.set(16, 26, 12);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 60;
    dirLight.shadow.camera.left = -15;
    dirLight.shadow.camera.right = 15;
    dirLight.shadow.camera.top = 15;
    dirLight.shadow.camera.bottom = -15;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // Soft sky fill light
    const fillLight = new THREE.DirectionalLight(0xc7d3e3, 0.65);
    fillLight.position.set(-10, 12, -8);
    scene.add(fillLight);

    // 4. Map Group Container (Rotated for architectural perspective)
    const cityGroup = new THREE.Group();
    scene.add(cityGroup);

    // 5. Terrain Base Plane (#C7D3E3)
    const terrainGeo = new THREE.BoxGeometry(18, 0.6, 18);
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0xc7d3e3,
      roughness: 0.65,
      metalness: 0.05
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.position.y = -0.3;
    terrainMesh.receiveShadow = true;
    cityGroup.add(terrainMesh);

    // 6. City Road Grid (#E8F0F8)
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0xe8f0f8,
      roughness: 0.8,
      metalness: 0.02
    });

    const createRoad = (w, h, d, x, z) => {
      const roadGeo = new THREE.BoxGeometry(w, h, d);
      const road = new THREE.Mesh(roadGeo, roadMat);
      road.position.set(x, 0.015, z);
      road.receiveShadow = true;
      cityGroup.add(road);
    };

    // Major Avenues & Cross Streets
    createRoad(17.6, 0.02, 1.4, 0, 0);       // Central Avenue (E-W)
    createRoad(17.6, 0.02, 1.1, 0, -4.5);   // North Boulevard
    createRoad(17.6, 0.02, 1.1, 0, 4.5);    // South Boulevard
    createRoad(1.4, 0.02, 17.6, 0, 0);      // Central Highway (N-S)
    createRoad(1.1, 0.02, 17.6, -4.5, 0);   // West Parkway
    createRoad(1.1, 0.02, 17.6, 4.5, 0);    // East Parkway

    // Secondary connector streets
    createRoad(17.6, 0.02, 0.6, 0, -2.25);
    createRoad(17.6, 0.02, 0.6, 0, 2.25);
    createRoad(0.6, 0.02, 17.6, -2.25, 0);
    createRoad(0.6, 0.02, 17.6, 2.25, 0);

    // 7. Architectural Buildings (#A9BBD1 with #8FA3BC shadows)
    const buildingMat = new THREE.MeshStandardMaterial({
      color: 0xa9bbd1,
      roughness: 0.45,
      metalness: 0.1
    });

    const buildingAccMat = new THREE.MeshStandardMaterial({
      color: 0x98adc4,
      roughness: 0.4,
      metalness: 0.12
    });

    // Curated building grid blocks across the sectors
    const blocks = [
      // Northwest Sector
      { x: -3.35, z: -3.35, w: 1.6, d: 1.6, h: 2.8 },
      { x: -1.35, z: -3.35, w: 1.0, d: 1.6, h: 1.6 },
      { x: -3.35, z: -1.35, w: 1.6, d: 1.0, h: 2.1 },
      { x: -1.35, z: -1.35, w: 1.0, d: 1.0, h: 3.6, acc: true }, // High-rise
      { x: -6.0, z: -3.35, w: 1.4, d: 1.6, h: 1.4 },
      { x: -6.0, z: -1.35, w: 1.4, d: 1.0, h: 1.8 },
      { x: -3.35, z: -6.0, w: 1.6, d: 1.4, h: 1.5 },

      // Northeast Sector
      { x: 3.35, z: -3.35, w: 1.6, d: 1.6, h: 2.4 },
      { x: 1.35, z: -3.35, w: 1.0, d: 1.6, h: 3.2, acc: true },
      { x: 3.35, z: -1.35, w: 1.6, d: 1.0, h: 1.9 },
      { x: 1.35, z: -1.35, w: 1.0, d: 1.0, h: 2.2 },
      { x: 6.0, z: -3.35, w: 1.4, d: 1.6, h: 1.7 },
      { x: 6.0, z: -1.35, w: 1.4, d: 1.0, h: 2.5 },

      // Southwest Sector (Hospital / Command Center Hub)
      { x: -3.35, z: 3.35, w: 1.6, d: 1.6, h: 2.0 },
      { x: -1.35, z: 3.35, w: 1.0, d: 1.6, h: 1.7 },
      { x: -3.35, z: 1.35, w: 1.6, d: 1.0, h: 2.6 },
      { x: -1.35, z: 1.35, w: 1.0, d: 1.0, h: 1.5 },
      { x: -6.0, z: 3.35, w: 1.4, d: 1.6, h: 1.9 },

      // Southeast Sector (Near Emergency Incident Site)
      { x: 3.35, z: 3.35, w: 1.6, d: 1.6, h: 1.6 },
      { x: 1.35, z: 3.35, w: 1.0, d: 1.6, h: 2.8, acc: true },
      { x: 3.35, z: 1.35, w: 1.6, d: 1.0, h: 2.2 },
      { x: 1.35, z: 1.35, w: 1.0, d: 1.0, h: 1.8 },
      { x: 6.0, z: 3.35, w: 1.4, d: 1.6, h: 1.4 },
      { x: 6.0, z: 1.35, w: 1.4, d: 1.0, h: 2.0 }
    ];

    blocks.forEach((b) => {
      const geo = new THREE.BoxGeometry(b.w, b.h, b.d);
      const mesh = new THREE.Mesh(geo, b.acc ? buildingAccMat : buildingMat);
      mesh.position.set(b.x, b.h / 2, b.z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      cityGroup.add(mesh);

      // Subtle rooftop edge detailing
      const roofGeo = new THREE.BoxGeometry(b.w * 0.75, 0.1, b.d * 0.75);
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x8fa3bc, roughness: 0.5 });
      const roofMesh = new THREE.Mesh(roofGeo, roofMat);
      roofMesh.position.set(b.x, b.h + 0.05, b.z);
      roofMesh.castShadow = true;
      cityGroup.add(roofMesh);
    });

    // 8. One Emergency Incident Marker (#E5484D with #FFB86B soft amber halo)
    // Positioned at East Intersection (4.5, 0, 2.25)
    const incidentX = 4.5;
    const incidentZ = 2.25;

    const incidentGroup = new THREE.Group();
    incidentGroup.position.set(incidentX, 0, incidentZ);
    cityGroup.add(incidentGroup);

    // Vertical Incident Pin (#E5484D)
    const pinStemGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.4, 12);
    const pinMat = new THREE.MeshStandardMaterial({
      color: 0xe5484d,
      roughness: 0.25,
      metalness: 0.1
    });
    const pinStem = new THREE.Mesh(pinStemGeo, pinMat);
    pinStem.position.y = 0.7;
    pinStem.castShadow = true;
    incidentGroup.add(pinStem);

    // Glowing Pin Head Sphere
    const pinHeadGeo = new THREE.SphereGeometry(0.32, 24, 24);
    const pinHead = new THREE.Mesh(pinHeadGeo, pinMat);
    pinHead.position.y = 1.4;
    pinHead.castShadow = true;
    incidentGroup.add(pinHead);

    // Soft Amber Halo (#FFB86B)
    const haloGeo = new THREE.RingGeometry(0.15, 0.65, 32);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0xffb86b,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.65
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    haloMesh.rotation.x = -Math.PI / 2;
    haloMesh.position.y = 0.04;
    incidentGroup.add(haloMesh);

    // Slow Radar Pulse Ring
    const radarGeo = new THREE.RingGeometry(0.5, 0.62, 32);
    const radarMat = new THREE.MeshBasicMaterial({
      color: 0xe5484d,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8
    });
    const radarRing = new THREE.Mesh(radarGeo, radarMat);
    radarRing.rotation.x = -Math.PI / 2;
    radarRing.position.y = 0.045;
    incidentGroup.add(radarRing);

    // 9. Response Routes (Trustworthy Blue #2563EB & Teal #0E9F8A)
    // Dispatch Route from Central Command/Hospital (-4.5, 0, -2.25) -> Incident (4.5, 0, 2.25)
    const routePoints = [
      new THREE.Vector3(-4.5, 0.05, -2.25), // Rescue Squad Station
      new THREE.Vector3(0, 0.05, -2.25),    // Junction A
      new THREE.Vector3(0, 0.05, 0),        // Central Crossing
      new THREE.Vector3(2.25, 0.05, 0),     // Intermediate Turn
      new THREE.Vector3(2.25, 0.05, 2.25),  // Approach Avenue
      new THREE.Vector3(4.5, 0.05, 2.25)    // Incident Location
    ];

    const routeCurve = new THREE.CatmullRomCurve3(routePoints, false, 'catmullrom', 0.15);
    const routeTubeGeo = new THREE.TubeGeometry(routeCurve, 64, 0.09, 8, false);
    const routeMat = new THREE.MeshStandardMaterial({
      color: 0x2563eb,
      roughness: 0.3,
      metalness: 0.1
    });
    const routeMesh = new THREE.Mesh(routeTubeGeo, routeMat);
    routeMesh.castShadow = true;
    cityGroup.add(routeMesh);

    // Secondary Teal Route (#0E9F8A) - Trauma Med-Evac Route
    const tealPoints = [
      new THREE.Vector3(-2.25, 0.05, 4.5), // City General Hospital
      new THREE.Vector3(-2.25, 0.05, 2.25),
      new THREE.Vector3(0, 0.05, 2.25),
      new THREE.Vector3(4.5, 0.05, 2.25)   // Incident Location
    ];
    const tealCurve = new THREE.CatmullRomCurve3(tealPoints, false, 'catmullrom', 0.15);
    const tealTubeGeo = new THREE.TubeGeometry(tealCurve, 48, 0.07, 8, false);
    const tealMat = new THREE.MeshStandardMaterial({
      color: 0x0e9f8a,
      roughness: 0.3,
      metalness: 0.1
    });
    const tealMesh = new THREE.Mesh(tealTubeGeo, tealMat);
    tealMesh.castShadow = true;
    cityGroup.add(tealMesh);

    // 10. Responder Professional Markers
    // Unit Alpha Marker (#2563EB) en route
    const responderPos = routeCurve.getPoint(0.55);
    const respMarkerGeo = new THREE.ConeGeometry(0.22, 0.45, 16);
    const respMarkerMat = new THREE.MeshStandardMaterial({ color: 0x2563eb });
    const respMarker = new THREE.Mesh(respMarkerGeo, respMarkerMat);
    respMarker.position.set(responderPos.x, 0.35, responderPos.z);
    respMarker.rotation.x = Math.PI;
    respMarker.castShadow = true;
    cityGroup.add(respMarker);

    // Hospital Marker (#0E9F8A)
    const hospMarkerGeo = new THREE.BoxGeometry(0.35, 0.35, 0.35);
    const hospMat = new THREE.MeshStandardMaterial({ color: 0x0e9f8a });
    const hospMarker = new THREE.Mesh(hospMarkerGeo, hospMat);
    hospMarker.position.set(-2.25, 0.3, 4.5);
    hospMarker.castShadow = true;
    cityGroup.add(hospMarker);

    // 11. Minimal Motion: Gentle Radar Ring & Incident Pulse
    let radarScale = 1.0;
    let pulseTime = 0;

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      if (!prefersReducedMotion) {
        pulseTime += 0.025;

        // Slow radar ring expansion
        radarScale += 0.012;
        if (radarScale > 2.8) radarScale = 0.8;
        radarRing.scale.set(radarScale, radarScale, 1);
        radarMat.opacity = Math.max(0, 0.75 * (1 - (radarScale - 0.8) / 2.0));

        // Gentle breathing halo pulse
        haloMesh.scale.set(
          1 + Math.sin(pulseTime) * 0.08,
          1 + Math.sin(pulseTime) * 0.08,
          1
        );

        // Very subtle camera sway for architectural depth
        camera.position.x = 14 + Math.sin(pulseTime * 0.35) * 0.3;
        camera.position.z = 16 + Math.cos(pulseTime * 0.35) * 0.3;
        camera.lookAt(0, 0.5, 0);
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const onResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || 640;
      const h = mount.clientHeight || 520;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
      terrainGeo.dispose();
      terrainMat.dispose();
      roadMat.dispose();
      buildingMat.dispose();
      buildingAccMat.dispose();
      pinStemGeo.dispose();
      pinMat.dispose();
      pinHeadGeo.dispose();
      haloGeo.dispose();
      haloMat.dispose();
      radarGeo.dispose();
      radarMat.dispose();
      routeTubeGeo.dispose();
      routeMat.dispose();
      tealTubeGeo.dispose();
      tealMat.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="w-full h-full min-h-[380px] sm:min-h-[460px] lg:min-h-[540px] relative select-none pointer-events-none"
      aria-label="3D Emergency Command City Map"
    />
  );
}
