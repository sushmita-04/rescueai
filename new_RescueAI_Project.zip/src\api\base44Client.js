// RescueAI Custom Client replacing Base44 SDK

async function request(url, options = {}) {
  const config = {
    ...options,
    credentials: 'include',
    headers: {
      Accept: 'application/json',
      ...(options.headers || {})
    }
  };

  if (config.body && typeof config.body === 'object' && !(config.body instanceof FormData)) {
    config.headers['Content-Type'] = 'application/json';
    config.body = JSON.stringify(config.body);
  }

  const response = await fetch(url, config);
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!response.ok) {
    const error = new Error(data?.error || data?.message || `Request failed with status ${response.status}`);
    error.status = response.status;
    error.data = data;
    error.response = { status: response.status, data };
    throw error;
  }

  return data;
}

function createEntityHandler(entityName) {
  return {
    async filter(query = {}, options = {}) {
      const params = new URLSearchParams();
      if (query && Object.keys(query).length > 0) {
        params.set('query', JSON.stringify(query));
      }
      if (options.sort) params.set('sort', options.sort);
      if (options.limit) params.set('limit', String(options.limit));
      if (entityName.toLowerCase() === 'assessment') {
        params.set('filterStaff', 'true');
      }

      const q = params.toString();
      const url = `/api/entities/${entityName}${q ? '?' + q : ''}`;
      const res = await request(url, { method: 'GET' });
      return res || { items: [] };
    },

    async list(options = {}) {
      const params = new URLSearchParams();
      if (options.sort) params.set('sort', options.sort);
      if (options.limit) params.set('limit', String(options.limit));

      const q = params.toString();
      const url = `/api/entities/${entityName}${q ? '?' + q : ''}`;
      const res = await request(url, { method: 'GET' });
      return res || { items: [] };
    },

    async get(id) {
      return request(`/api/entities/${entityName}/${encodeURIComponent(id)}`, { method: 'GET' });
    },

    async create(data) {
      return request(`/api/entities/${entityName}`, {
        method: 'POST',
        body: data
      });
    },

    async update(id, data) {
      return request(`/api/entities/${entityName}/${encodeURIComponent(id)}`, {
        method: 'PUT',
        body: data
      });
    }
  };
}

const entityNames = ['SOSRequest', 'Assessment', 'TeamRequest', 'User', 'Guideline'];
const entities = {};
for (const name of entityNames) {
  entities[name] = createEntityHandler(name);
}

export const base44 = {
  entities,
  asServiceRole: {
    entities
  },

  functions: {
    async invoke(name, payload = {}) {
      const res = await request(`/api/functions/${name}`, {
        method: 'POST',
        body: payload
      });
      return res; // returns { data: ... }
    }
  },

  integrations: {
    Core: {
      async UploadPrivateFile({ file }) {
        const formData = new FormData();
        formData.append('file', file);
        return request('/api/integrations/core/upload-private-file', {
          method: 'POST',
          body: formData
        });
      },

      async CreateFileSignedUrl({ file_uri, expires_in }) {
        return request('/api/integrations/core/create-file-signed-url', {
          method: 'POST',
          body: { file_uri, expires_in }
        });
      }
    }
  },

  auth: {
    async me() {
      return request('/api/auth/me', { method: 'GET' });
    },

    async loginViaEmailPassword(identifier, password, portal) {
      const res = await request('/api/auth/login', {
        method: 'POST',
        body: {
          identifier,
          email: identifier,
          gov_id: identifier,
          password,
          portal
        }
      });
      return res?.user;
    },

    async register({ email, password, full_name }) {
      const res = await request('/api/auth/register', {
        method: 'POST',
        body: { email, password, full_name }
      });
      return res?.user;
    },

    async logout(redirectUrl) {
      try {
        await request('/api/auth/logout', { method: 'POST' });
      } catch {
        // ignore
      }
      if (redirectUrl) {
        window.location.href = redirectUrl;
      }
    },

    redirectToLogin(redirectUrl) {
      let returnPath = '/';
      try {
        if (redirectUrl) {
          const parsed = new URL(redirectUrl, window.location.origin);
          returnPath = parsed.pathname + parsed.search;
        } else {
          returnPath = window.location.pathname + window.location.search;
        }
      } catch {
        returnPath = window.location.pathname;
      }
      window.location.href = `/login?returnTo=${encodeURIComponent(returnPath)}`;
    },

    setToken() {
      // Session cookie is automatically stored and sent with credentials: 'include'
    },

    async changePassword(currentPassword, newPassword) {
      return request('/api/auth/change-password', {
        method: 'POST',
        body: { currentPassword, newPassword }
      });
    },

    async resetPasswordRequest(email) {
      return request('/api/auth/reset-password-request', {
        method: 'POST',
        body: { email }
      });
    },

    async resetPassword({ resetToken, newPassword }) {
      return request('/api/auth/reset-password', {
        method: 'POST',
        body: { resetToken, newPassword }
      });
    }
  },

  app: {
    async getPublicSettings() {
      try {
        return await request('/api/app/public-settings', { method: 'GET' });
      } catch {
        return {
          id: 'rescueai',
          public_settings: {
            smtp_configured: false
          }
        };
      }
    }
  }
};
