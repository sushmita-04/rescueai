import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export default function GuidelineList({ items = [] }) {
  if (!items.length) {
    return <p className="text-sm text-graphite">No guidelines matched this situation yet.</p>;
  }

  return (
    <Accordion type="multiple" className="w-full">
      {items.map((item, index) => (
        <AccordionItem
          key={`${item.title}-${index}`}
          value={`guideline-${index}`}
          className="border-b border-ink/5 last:border-b-0"
        >
          <AccordionTrigger className="py-3 text-left text-sm font-medium text-ink hover:no-underline">
            <span className="flex-1 pr-3">{item.title}</span>
          </AccordionTrigger>
          <AccordionContent className="pb-4 text-sm leading-relaxed text-graphite">
            {item.text}
            <span className="mt-2 block text-[11px] uppercase tracking-wider text-graphite/60">
              {item.disaster_type} guideline
            </span>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
