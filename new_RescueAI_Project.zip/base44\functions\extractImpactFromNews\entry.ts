import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const SCHEMA = {
  type: 'object',
  properties: {
    affected: { type: ['number', 'null'] },
    injured: { type: ['number', 'null'] },
    dead: { type: ['number', 'null'] },
    missing: { type: ['number', 'null'] },
    confidence: { type: 'string', enum: ['low', 'medium', 'high'] },
    evidence: { type: 'string' }
  },
  required: ['affected', 'injured', 'dead', 'missing', 'confidence', 'evidence']
};

const UNIT_MULTIPLIER: Record<string, number> = {
  lakh: 100000,
  'lakhs': 100000,
  thousand: 1000,
  million: 1000000,
  crore: 10000000
};

function parseNumber(raw: string, unit?: string) {
  const base = Number(String(raw).replace(/,/g, ''));
  if (!Number.isFinite(base)) return null;
  const multiplier = unit ? UNIT_MULTIPLIER[unit.toLowerCase()] || 1 : 1;
  return Math.round(base * multiplier);
}

function regexFallback(headlines: string[]) {
  const text = headlines.join(' \n ');
  let affected: number | null = null;
  let injured: number | null = null;

  const affectedPattern =
    /(\d[\d,\.]*)\s*(lakh|lakhs|thousand|million|crore)?\s*(?:people|residents|villagers|families|persons)[^.]{0,60}?(affected|displaced|evacuated|stranded|marooned)/i;
  const affectedMatch = text.match(affectedPattern);
  if (affectedMatch) affected = parseNumber(affectedMatch[1], affectedMatch[2]);

  const injuredPattern = /(\d[\d,\.]*)\s*(?:people\s*)?(injured|hurt)/i;
  const injuredMatch = text.match(injuredPattern);
  if (injuredMatch) injured = parseNumber(injuredMatch[1]);

  const evidenceParts = [affectedMatch?.[0], injuredMatch?.[0]].filter(Boolean);

  return {
    affected,
    injured,
    dead: null,
    missing: null,
    confidence: 'low',
    evidence: evidenceParts.join(' · ').slice(0, 220),
    fallback: true
  };
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const headlines = (Array.isArray(body?.headlines) ? body.headlines : [])
      .map((item: any) => String(item || '').trim())
      .filter(Boolean)
      .slice(0, 12);

    if (headlines.length === 0) {
      return Response.json({ affected: null, injured: null, dead: null, missing: null, confidence: 'low', evidence: '', fallback: true });
    }

    try {
      const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `You extract casualty and displacement numbers from news headlines about a disaster.

Headlines:
${headlines.map((title: string, index: number) => `${index + 1}. ${title}`).join('\n')}

Rules:
- Use ONLY numbers explicitly stated in these headlines. Never estimate, infer or invent a number.
- If a figure is not stated, return null for it.
- "affected" means people affected, displaced, evacuated, stranded or marooned.
- "confidence" reflects how explicit the numbers are: high when a headline states exact figures, medium when a range or partial figure, low when only vague wording.
- "evidence" is the exact headline text the numbers came from, or an empty string.`,
        response_json_schema: SCHEMA
      });

      const clean = (value: any) => {
        const n = Number(value);
        return Number.isFinite(n) && n >= 0 ? Math.round(n) : null;
      };

      const confidence = ['low', 'medium', 'high'].includes(result?.confidence) ? result.confidence : 'low';
      const extracted = {
        affected: clean(result?.affected),
        injured: clean(result?.injured),
        dead: clean(result?.dead),
        missing: clean(result?.missing),
        confidence,
        evidence: String(result?.evidence || '').slice(0, 300),
        fallback: false
      };

      if (extracted.affected === null && extracted.injured === null) {
        const reg = regexFallback(headlines);
        if (reg.affected !== null || reg.injured !== null) return Response.json(reg);
      }

      return Response.json(extracted);
    } catch {
      return Response.json(regexFallback(headlines));
    }
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Could not read the news headlines.' }, { status: 500 });
  }
}
