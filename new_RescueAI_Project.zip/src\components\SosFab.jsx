import { Link } from 'react-router-dom';
import { Mic } from 'lucide-react';

export default function SosFab() {
  return (
    <Link
      to="/sos"
      className="fixed bottom-5 right-4 z-30 inline-flex items-center gap-2 rounded-full bg-[#C1121F] px-4 py-3 text-sm font-semibold text-white shadow-lift transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#C1121F] sm:bottom-6 sm:right-6 sm:px-5"
    >
      <span className="relative flex h-5 w-5 items-center justify-center">
        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-white/50" aria-hidden="true" />
        <Mic className="relative h-4 w-4" aria-hidden="true" />
      </span>
      <span className="hidden sm:inline">Need help? Send voice SOS</span>
      <span className="sm:hidden">Send voice SOS</span>
    </Link>
  );
}
