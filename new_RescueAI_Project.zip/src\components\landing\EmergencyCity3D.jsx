import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

/**
 * EmergencyCity3D:
 * Premium 3D Isometric Miniature Emergency Response City Scene.
 *
 * Features:
 * - White & Pale-Pink buildings with architectural depth
 * - Hospital with rooftop helipad (marked with 'H')
 * - Curved dark asphalt roads with lane markings
 * - Green trees with pastel foliage
 * - Glossy coral SOS location pin with animated ground beacon rings
 * - Glowing coral emergency route ribbon
 * - White ambulance with red medical cross & flashing siren
 * - Smooth isometric camera with gentle mouse parallax
 * - Fully transparent background to blend into soft blush-pink hero
 */

function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

export default function EmergencyCity3D() {
  const mountRef = useRef(null);
  const [hasWebGL] = useState(() => isWebGLAvailable());

  useEffect(() => {
    if (!hasWebGL) return;
    const mount = mountRef.current;
    if (!mount) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let width = mount.clientWidth || 600;
    let height = mount.clientHeight || 560;

    // 1. Scene & Isometric Camera Setup
    const scene = new THREE.Scene();
    scene.background = null;

    const aspect = width / height;
    const camera = new THREE.PerspectiveCamera(34, aspect, 0.1, 100);
    // Classic isometric architectural perspective
    camera.position.set(16, 17, 16);
    camera.lookAt(0, 0.4, 0);

    // 2. High-Performance WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    mount.appendChild(renderer.domElement);

    // 3. Warm Ambient & Soft Sunlight
    const hemiLight = new THREE.HemisphereLight(0xfff8f5, 0xfce7e9, 1.4);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff5f0, 1.5);
    sunLight.position.set(14, 22, 10);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 45;
    sunLight.shadow.camera.left = -10;
    sunLight.shadow.camera.right = 10;
    sunLight.shadow.camera.top = 10;
    sunLight.shadow.camera.bottom = -10;
    sunLight.shadow.bias = -0.0003;
    scene.add(sunLight);

    const coralRimLight = new THREE.DirectionalLight(0xf472b6, 0.45);
    coralRimLight.position.set(-12, 8, -12);
    scene.add(coralRimLight);

    // 4. Materials Palette
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0xfff0f2, // Soft blush warm white
      roughness: 0.8,
      metalness: 0.05
    });

    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x475569, // Slate gray asphalt
      roughness: 0.65,
      metalness: 0.1
    });

    const roadMarkingMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.4
    });

    const buildingWhiteMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.35,
      metalness: 0.05
    });

    const buildingPinkMat = new THREE.MeshStandardMaterial({
      color: 0xfce7e9, // Delicate pale pink
      roughness: 0.4,
      metalness: 0.08
    });

    const buildingWarmMat = new THREE.MeshStandardMaterial({
      color: 0xfff5ed, // Warm cream
      roughness: 0.45,
      metalness: 0.05
    });

    const windowGlassMat = new THREE.MeshStandardMaterial({
      color: 0x93c5fd, // Sky blue tint
      roughness: 0.15,
      metalness: 0.35
    });

    const coralMat = new THREE.MeshStandardMaterial({
      color: 0xf2574b, // RescueAI Signature Coral
      roughness: 0.25,
      metalness: 0.15,
      emissive: 0xf2574b,
      emissiveIntensity: 0.1
    });

    const coralGlowMat = new THREE.MeshStandardMaterial({
      color: 0xf2574b,
      roughness: 0.2,
      emissive: 0xf2574b,
      emissiveIntensity: 0.7,
      transparent: true,
      opacity: 0.95
    });

    const treeLeavesMat = new THREE.MeshStandardMaterial({
      color: 0x10b981, // Vibrant emerald mint
      roughness: 0.7
    });

    const treeTrunkMat = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Warm wood trunk
      roughness: 0.8
    });

    const darkMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.3
    });

    // Root Group
    const cityGroup = new THREE.Group();
    scene.add(cityGroup);

    // 5. Isometric City Base (Rounded Island)
    const baseGeo = new THREE.CylinderGeometry(7.2, 7.6, 0.5, 48);
    const baseMesh = new THREE.Mesh(baseGeo, terrainMat);
    baseMesh.position.y = -0.25;
    baseMesh.receiveShadow = true;
    cityGroup.add(baseMesh);

    // Secondary sub-level island step
    const subBaseGeo = new THREE.CylinderGeometry(7.6, 8.0, 0.4, 48);
    const subBaseMesh = new THREE.Mesh(subBaseGeo, new THREE.MeshStandardMaterial({
      color: 0xffe4e8,
      roughness: 0.9
    }));
    subBaseMesh.position.y = -0.65;
    cityGroup.add(subBaseMesh);

    // 6. Curved Road Network
    // Main curving boulevard from Hospital (Top-Left) to SOS Site (Bottom-Right)
    const roadShape = new THREE.Shape();
    // Inner loop road layout
    const roadCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-4.5, 0.02, -3.2), // Hospital Exit
      new THREE.Vector3(-2.8, 0.02, -2.5),
      new THREE.Vector3(-1.0, 0.02, -1.8),
      new THREE.Vector3(0.4, 0.02, -0.6),
      new THREE.Vector3(1.2, 0.02, 0.8),
      new THREE.Vector3(2.6, 0.02, 1.8),
      new THREE.Vector3(3.8, 0.02, 2.6)  // Incident SOS Point
    ]);

    const roadGeo = new THREE.TubeGeometry(roadCurve, 64, 0.65, 8, false);
    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.scale.set(1, 0.08, 1);
    roadMesh.position.y = 0.01;
    roadMesh.receiveShadow = true;
    cityGroup.add(roadMesh);

    // Secondary connecting road
    const secRoadCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-3.0, 0.02, 2.5),
      new THREE.Vector3(-1.2, 0.02, 1.6),
      new THREE.Vector3(0.4, 0.02, -0.6), // Intersection
      new THREE.Vector3(2.2, 0.02, -2.2)
    ]);
    const secRoadGeo = new THREE.TubeGeometry(secRoadCurve, 48, 0.55, 8, false);
    const secRoadMesh = new THREE.Mesh(secRoadGeo, roadMat);
    secRoadMesh.scale.set(1, 0.08, 1);
    secRoadMesh.position.y = 0.01;
    secRoadMesh.receiveShadow = true;
    cityGroup.add(secRoadMesh);

    // 7. Glowing Coral Emergency Route Ribbon
    const routeGeo = new THREE.TubeGeometry(roadCurve, 64, 0.12, 8, false);
    const routeMesh = new THREE.Mesh(routeGeo, coralGlowMat);
    routeMesh.position.y = 0.08;
    cityGroup.add(routeMesh);

    // Animated light pulse on the route
    const pulseLight = new THREE.PointLight(0xf2574b, 2.0, 4);
    pulseLight.position.set(0, 0.3, 0);
    cityGroup.add(pulseLight);

    // 8. Buildings
    function createBuilding(w, h, d, x, z, mat, hasHelipad = false) {
      const bGroup = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      body.position.y = h / 2;
      body.castShadow = true;
      body.receiveShadow = true;
      bGroup.add(body);

      // Rooftop terrace / border
      const roofBorder = new THREE.Mesh(new THREE.BoxGeometry(w * 0.92, 0.12, d * 0.92), darkMat);
      roofBorder.position.y = h + 0.06;
      bGroup.add(roofBorder);

      // Windows
      const winCols = Math.max(1, Math.floor(w / 0.5));
      const winRows = Math.max(1, Math.floor(h / 0.7));
      for (let r = 0; r < winRows; r++) {
        for (let c = 0; c < winCols; c++) {
          const win = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.32, 0.02), windowGlassMat);
          win.position.set(
            -w / 2 + 0.3 + c * (w / winCols),
            0.5 + r * 0.65,
            d / 2 + 0.01
          );
          bGroup.add(win);
        }
      }

      // Hospital Helipad Feature
      if (hasHelipad) {
        // Red cross on front
        const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.65, 0.04), coralMat);
        crossV.position.set(0, h * 0.65, d / 2 + 0.02);
        const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.18, 0.04), coralMat);
        crossH.position.set(0, h * 0.65, d / 2 + 0.02);
        bGroup.add(crossV, crossH);

        // Helipad circle on roof
        const helipad = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.05, 24), darkMat);
        helipad.position.set(0, h + 0.12, 0);
        // Yellow/coral circle ring
        const heliRing = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.05, 8, 24), coralMat);
        heliRing.rotation.x = Math.PI / 2;
        heliRing.position.set(0, h + 0.16, 0);
        // Letter 'H'
        const hBarL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.6), buildingWhiteMat);
        hBarL.position.set(-0.25, h + 0.16, 0);
        const hBarR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.6), buildingWhiteMat);
        hBarR.position.set(0.25, h + 0.16, 0);
        const hBarC = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.1), buildingWhiteMat);
        hBarC.position.set(0, h + 0.16, 0);

        bGroup.add(helipad, heliRing, hBarL, hBarR, hBarC);
      }

      bGroup.position.set(x, 0, z);
      cityGroup.add(bGroup);
      return bGroup;
    }

    // A. Main Hospital with Helipad (Top-Left)
    createBuilding(2.4, 2.6, 2.2, -4.5, -3.4, buildingWhiteMat, true);

    // B. Pale Pink Tower (Back-Center)
    createBuilding(1.8, 4.2, 1.8, -0.6, -4.2, buildingPinkMat);
    // Tower top architectural spire
    const spire = new THREE.Mesh(new THREE.ConeGeometry(0.25, 1.2, 8), coralMat);
    spire.position.set(-0.6, 4.8, -4.2);
    cityGroup.add(spire);

    // C. Modern White Residential Blocks
    createBuilding(1.6, 2.2, 1.8, 2.4, -3.8, buildingWhiteMat);
    createBuilding(1.8, 3.2, 1.6, 4.4, -1.8, buildingPinkMat);
    createBuilding(1.6, 1.8, 1.6, 4.6, 0.4, buildingWarmMat);

    // D. Left & Lower Urban Blocks
    createBuilding(2.0, 2.0, 1.5, -4.8, -0.4, buildingWarmMat);
    createBuilding(1.8, 2.8, 1.6, -4.2, 2.2, buildingWhiteMat);
    createBuilding(1.6, 1.6, 1.8, -1.8, 3.8, buildingPinkMat);
    createBuilding(1.6, 2.4, 1.5, 0.8, 3.8, buildingWhiteMat);

    // 9. Low-Poly Green Trees
    function createTree(x, z, scale = 1.0) {
      const tGroup = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.6, 8), treeTrunkMat);
      trunk.position.y = 0.3;
      trunk.castShadow = true;

      // Foliage layers
      const c1 = new THREE.Mesh(new THREE.ConeGeometry(0.48, 0.7, 8), treeLeavesMat);
      c1.position.y = 0.75;
      c1.castShadow = true;
      const c2 = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.6, 8), treeLeavesMat);
      c2.position.y = 1.15;
      c2.castShadow = true;

      tGroup.add(trunk, c1, c2);
      tGroup.scale.set(scale, scale, scale);
      tGroup.position.set(x, 0, z);
      cityGroup.add(tGroup);
    }

    const treePositions = [
      [-3.0, -1.5, 1.1], [-2.4, -0.6, 0.9], [-1.6, -3.2, 1.2],
      [-0.2, -1.8, 1.0], [0.8, -2.4, 0.85], [1.6, -1.2, 1.1],
      [3.2, -0.8, 0.9], [3.4, 0.8, 1.0], [2.2, 2.8, 0.95],
      [-0.4, 2.2, 1.2], [-2.8, 1.2, 0.9], [-3.8, 3.8, 1.0],
      [1.4, 2.4, 0.85], [4.6, 2.2, 0.9]
    ];
    treePositions.forEach(([x, z, s]) => createTree(x, z, s));

    // 10. White Ambulance with Red Medical Markings
    const ambulanceGroup = new THREE.Group();
    // Body
    const ambBody = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.52, 0.46), buildingWhiteMat);
    ambBody.position.y = 0.32;
    ambBody.castShadow = true;
    // Cab windshield
    const ambGlass = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.28, 0.42), darkMat);
    ambGlass.position.set(0.38, 0.38, 0);
    // Red side stripes & crosses
    const ambStripeL = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 0.48), coralMat);
    ambStripeL.position.set(-0.06, 0.32, 0);
    const ambCrossV = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.24, 0.49), coralMat);
    ambCrossV.position.set(-0.06, 0.32, 0);
    // Siren beacon on roof
    const ambSiren = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 12), coralGlowMat);
    ambSiren.position.set(0.15, 0.62, 0);
    // Wheels
    const wheelGeo = new THREE.CylinderGeometry(0.11, 0.11, 0.52, 12);
    wheelGeo.rotateX(Math.PI / 2);
    const wFront = new THREE.Mesh(wheelGeo, darkMat);
    wFront.position.set(0.28, 0.12, 0);
    const wBack = new THREE.Mesh(wheelGeo, darkMat);
    wBack.position.set(-0.32, 0.12, 0);

    ambulanceGroup.add(ambBody, ambGlass, ambStripeL, ambCrossV, ambSiren, wFront, wBack);
    // Place ambulance on the road heading toward incident
    ambulanceGroup.position.set(0.8, 0.05, 0.2);
    ambulanceGroup.rotation.y = -Math.PI / 3.8;
    cityGroup.add(ambulanceGroup);

    // 11. Glossy Coral SOS Location Pin & Ground Pulse Rings
    const pinGroup = new THREE.Group();
    const pinHead = new THREE.Mesh(new THREE.SphereGeometry(0.48, 20, 20), coralMat);
    pinHead.position.y = 1.25;
    pinHead.castShadow = true;
    const pinHole = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.35, 16), darkMat);
    pinHole.rotation.x = Math.PI / 2;
    pinHole.position.y = 1.25;
    const pinCone = new THREE.Mesh(new THREE.ConeGeometry(0.44, 0.85, 20), coralMat);
    pinCone.rotation.x = Math.PI;
    pinCone.position.y = 0.8;
    pinCone.castShadow = true;

    // Ground target ring
    const groundRing1 = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.55, 32),
      new THREE.MeshBasicMaterial({ color: 0xf2574b, side: THREE.DoubleSide, transparent: true, opacity: 0.8 })
    );
    groundRing1.rotation.x = Math.PI / 2;
    groundRing1.position.y = 0.05;

    const groundRing2 = new THREE.Mesh(
      new THREE.RingGeometry(0.65, 0.75, 32),
      new THREE.MeshBasicMaterial({ color: 0xf2574b, side: THREE.DoubleSide, transparent: true, opacity: 0.4 })
    );
    groundRing2.rotation.x = Math.PI / 2;
    groundRing2.position.y = 0.04;

    pinGroup.add(pinHead, pinHole, pinCone, groundRing1, groundRing2);
    pinGroup.position.set(3.8, 0, 2.6); // Destination incident site
    cityGroup.add(pinGroup);

    // 12. Gentle Mouse Parallax & Dynamic Sizing
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (e) => {
      if (prefersReducedMotion) return;
      const rect = mount.getBoundingClientRect();
      const normX = (e.clientX - rect.left) / rect.width - 0.5;
      const normY = (e.clientY - rect.top) / rect.height - 0.5;
      targetX = normX * 0.45;
      targetY = -normY * 0.35;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    const handleResize = () => {
      if (!mount) return;
      width = mount.clientWidth || 600;
      height = mount.clientHeight || 560;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // 13. Visibility Observer (Pause off-screen)
    let isVisible = true;
    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
      },
      { threshold: 0.02 }
    );
    observer.observe(mount);

    // 14. Animation Loop
    let animationFrameId;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (!isVisible) return;

      const elapsed = clock.getElapsedTime();

      if (!prefersReducedMotion) {
        // Smooth mouse parallax
        mouseX += (targetX - mouseX) * 0.05;
        mouseY += (targetY - mouseY) * 0.05;

        cityGroup.rotation.y = mouseX * 0.3;
        cityGroup.rotation.x = -mouseY * 0.2;

        // Pin gentle floating bob
        pinHead.position.y = 1.25 + Math.sin(elapsed * 2.2) * 0.08;
        pinCone.position.y = 0.8 + Math.sin(elapsed * 2.2) * 0.08;

        // Ground ring pulse
        const pulse = 1 + (Math.sin(elapsed * 2.5) * 0.5 + 0.5) * 0.35;
        groundRing1.scale.set(pulse, pulse, 1);
        groundRing2.scale.set(pulse * 1.15, pulse * 1.15, 1);

        // Ambulance flashing siren
        const sirenFlash = Math.sin(elapsed * 8) > 0;
        ambSiren.material.emissiveIntensity = sirenFlash ? 1.5 : 0.2;

        // Pulse light moving along the route
        const progress = (elapsed * 0.22) % 1;
        const point = roadCurve.getPointAt(progress);
        pulseLight.position.set(point.x, point.y + 0.3, point.z);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      observer.disconnect();
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [hasWebGL]);

  if (!hasWebGL) {
    return (
      <div className="w-full h-full flex items-center justify-center p-8 bg-rose-50/60 rounded-3xl border border-rose-100">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-500 mx-auto flex items-center justify-center mb-3">
            <span className="text-2xl font-bold">🚑</span>
          </div>
          <p className="text-sm font-semibold text-slate-800">Rescue Response Active</p>
          <p className="text-xs text-slate-500 mt-1">Live dispatch & GPS route mapping</p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className="w-full h-full min-h-[440px] sm:min-h-[520px] lg:min-h-[580px] pointer-events-auto cursor-grab active:cursor-grabbing"
      aria-label="3D Isometric Emergency Response City Map"
    />
  );
}
