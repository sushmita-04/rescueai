import jsPDFPkg from 'jspdf/dist/jspdf.umd.min.js';
const jsPDF = jsPDFPkg.jsPDF || jsPDFPkg;

/**
 * generatePlanPdf:
 * Generates an official, publication-ready Incident Action Plan (IAP) PDF
 * for Rescue Teams and Field Commanders.
 */
export function generatePlanPdf(result) {
  if (!result || !result.plan) return;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const plan = result.plan;
  const input = result.input || {};
  const disasterType = (input.disaster_type || 'Emergency').toUpperCase();
  const location = input.location || 'Unknown Location';
  const severity = (result.severity || 'Normal').toUpperCase();
  const timestamp = new Date().toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short'
  });

  const pageWidth = 210;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;
  let y = 14;

  const checkPageBreak = (neededHeight) => {
    if (y + neededHeight > 280) {
      doc.addPage();
      y = 15;
      drawHeader(true);
    }
  };

  const drawHeader = (isContinuation = false) => {
    // Top banner bar
    doc.setFillColor(23, 43, 69); // #172B45 Deep Navy
    doc.rect(0, 0, pageWidth, 18, 'F');

    // Accent line
    doc.setFillColor(242, 87, 75); // #F2574B Coral
    doc.rect(0, 18, pageWidth, 1.5, 'F');

    // Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(255, 255, 255);
    doc.text('RESCUEAI — INCIDENT ACTION PLAN (IAP)', margin, 11);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(220, 225, 235);
    const rightText = isContinuation ? 'CONTINUED' : `GENERATED: ${timestamp}`;
    doc.text(rightText, pageWidth - margin, 11, { align: 'right' });

    y = 26;
  };

  drawHeader(false);

  // 1. Incident Overview Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, y, contentWidth, 32, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(23, 43, 69);
  doc.text(`${disasterType} EMERGENCY — ${location}`, margin + 4, y + 7);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('SEVERITY LEVEL:', margin + 4, y + 14);

  // Severity Tag Color
  let sevBg = [239, 68, 68]; // Red
  let sevText = [255, 255, 255];
  if (severity.includes('LOW')) sevBg = [16, 185, 129];
  else if (severity.includes('MED')) sevBg = [245, 158, 11];

  doc.setFillColor(...sevBg);
  doc.roundedRect(margin + 33, y + 10.5, 22, 5, 1, 1, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(...sevText);
  doc.text(severity, margin + 44, y + 14, { align: 'center' });

  // Risk Score & Location
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.text(`Risk Score: ${result.score || '—'} / 10`, margin + 60, y + 14);
  if (input.lat && input.lng) {
    doc.text(`Coordinates: ${input.lat}, ${input.lng}`, margin + 100, y + 14);
  }

  // Summary
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  const summaryLines = doc.splitTextToSize(result.summary || 'Immediate deployment advisory active.', contentWidth - 8);
  doc.text(summaryLines, margin + 4, y + 21);

  y += 37;

  // 2. Verified Rescue Team Allocation
  if (plan.recommended_team) {
    checkPageBreak(34);
    const team = plan.recommended_team;
    doc.setFillColor(239, 246, 255); // Light blue
    doc.setDrawColor(191, 219, 254);
    doc.roundedRect(margin, y, contentWidth, 28, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 58, 138); // Deep Blue
    doc.text(`DEPLOYED UNIT: ${team.name || 'NDRF Rescue Unit'}`, margin + 4, y + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(`Lead Officer: ${team.lead_officer || '—'}  |  Contact: ${team.contact_phone || 'Emergency Direct'}`, margin + 4, y + 12);
    doc.text(`Base Location: ${team.base_location || 'Regional Disaster Center'}  |  Personnel: ${team.personnel_count || 'Active Force'}`, margin + 4, y + 17);

    if (team.equipment) {
      const eqLines = doc.splitTextToSize(`Equipment: ${team.equipment}`, contentWidth - 8);
      doc.text(eqLines, margin + 4, y + 22);
    }
    y += 33;
  }

  // 3. Action Timeline
  if (plan.timeline?.length) {
    checkPageBreak(15);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(23, 43, 69);
    doc.text('OPERATIONAL ACTION TIMELINE', margin, y);
    y += 4;

    plan.timeline.forEach((phase) => {
      checkPageBreak(12);
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentWidth, 5.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(phase.phase.toUpperCase(), margin + 3, y + 4);
      y += 8;

      (phase.actions || []).forEach((act) => {
        checkPageBreak(10);
        doc.setFillColor(242, 87, 75);
        doc.circle(margin + 2, y + 1.5, 0.8, 'F');

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(30, 41, 59);

        const actLines = doc.splitTextToSize(act.action, contentWidth - 36);
        doc.text(actLines, margin + 5, y + 2.5);

        // Owner & priority tag on right
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(100, 116, 139);
        const ownerTag = `[${(act.owner || 'Rescue Team').toUpperCase()}]`;
        doc.text(ownerTag, pageWidth - margin, y + 2.5, { align: 'right' });

        y += (actLines.length * 4) + 1.5;
      });
      y += 2;
    });
    y += 4;
  }

  // 4. Team Deployment Zones & Hospital Routing
  if (plan.team_deployment?.length || plan.hospital_routing?.length) {
    checkPageBreak(25);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(23, 43, 69);
    doc.text('DEPLOYMENT ZONES & CASUALTY TRIAGE', margin, y);
    y += 5;

    if (plan.team_deployment?.length) {
      plan.team_deployment.forEach((row) => {
        checkPageBreak(8);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);
        doc.text(`• ${row.zone_or_task}:`, margin + 2, y);

        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        const detail = `${row.teams_assigned || ''} ${row.team_name ? '— ' + row.team_name : ''}`;
        doc.text(detail, margin + 45, y);
        y += 4.5;
      });
      y += 2;
    }

    if (plan.hospital_routing?.length) {
      plan.hospital_routing.forEach((hosp) => {
        checkPageBreak(8);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(225, 29, 72);
        doc.text(`+ Hospital Triage:`, margin + 2, y);

        doc.setFont('helvetica', 'normal');
        doc.setTextColor(51, 65, 85);
        doc.text(`${hosp.hospital_name} (${hosp.role})`, margin + 45, y);
        y += 4.5;
      });
      y += 2;
    }
  }

  // 5. Public Advice & Critical Rations
  if (plan.evacuation_advice || plan.public_message || plan.resources) {
    checkPageBreak(25);
    y += 2;
    doc.setFillColor(254, 242, 242); // Light red
    doc.setDrawColor(254, 202, 202);
    doc.roundedRect(margin, y, contentWidth, 22, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(153, 27, 27);
    doc.text('PUBLIC WARNING & EVACUATION DIRECTIVE:', margin + 4, y + 5.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(69, 10, 10);
    const pubLines = doc.splitTextToSize(plan.evacuation_advice || plan.public_message || 'Remain indoors on high ground.', contentWidth - 8);
    doc.text(pubLines, margin + 4, y + 10.5);

    if (plan.resources) {
      const resText = `Recommended daily supplies: ${Number(plan.resources.water_litres_per_day || 0).toLocaleString()} L potable water / day  |  ${Number(plan.resources.food_packets_per_day || 0).toLocaleString()} emergency rations / day`;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(120, 53, 15);
      doc.text(resText, margin + 4, y + 18);
    }
    y += 28;
  }

  // Footer on all pages
  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('RescueAI Automated Emergency Response System — Official Confidential Action Plan', margin, 292);
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, 292, { align: 'right' });
  }

  // Sanitize file name
  const cleanLoc = location.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 20);
  const fileName = `RescuePlan_${disasterType}_${cleanLoc}.pdf`;
  doc.save(fileName);
}

/**
 * generatePlanText:
 * Exports the rescue plan as clean formatted text/markdown.
 */
export function generatePlanText(result) {
  if (!result || !result.plan) return;

  const plan = result.plan;
  const input = result.input || {};
  const disasterType = (input.disaster_type || 'Emergency').toUpperCase();
  const location = input.location || 'Unknown Location';
  const severity = (result.severity || 'Normal').toUpperCase();
  const timestamp = new Date().toLocaleString('en-IN');

  let text = `==========================================================\n`;
  text += `RESCUEAI INCIDENT ACTION PLAN (IAP)\n`;
  text += `DISASTER TYPE: ${disasterType}\n`;
  text += `LOCATION:      ${location}\n`;
  if (input.lat && input.lng) text += `COORDINATES:   ${input.lat}, ${input.lng}\n`;
  text += `SEVERITY:      ${severity} (Risk Score: ${result.score}/10)\n`;
  text += `GENERATED:     ${timestamp}\n`;
  text += `==========================================================\n\n`;

  text += `EXECUTIVE SUMMARY:\n${result.summary || 'None'}\n\n`;

  if (plan.recommended_team) {
    const t = plan.recommended_team;
    text += `----------------------------------------------------------\n`;
    text += `PRIMARY ASSIGNED RESCUE TEAM (DB VERIFIED):\n`;
    text += `----------------------------------------------------------\n`;
    text += `Unit Name:     ${t.name}\n`;
    text += `Lead Officer:  ${t.lead_officer}\n`;
    text += `Contact Phone: ${t.contact_phone}\n`;
    text += `Base Station:  ${t.base_location}\n`;
    if (t.equipment) text += `Equipment:     ${t.equipment}\n`;
    if (plan.team_selection_reason) text += `Selection:     ${plan.team_selection_reason}\n`;
    text += `\n`;
  }

  if (plan.timeline?.length) {
    text += `----------------------------------------------------------\n`;
    text += `ACTION TIMELINE:\n`;
    text += `----------------------------------------------------------\n`;
    plan.timeline.forEach((phase) => {
      text += `\n[${phase.phase.toUpperCase()}]\n`;
      (phase.actions || []).forEach((act, idx) => {
        text += `  ${idx + 1}. [${act.priority || 'NORMAL'}] ${act.action} (${act.owner})\n`;
      });
    });
    text += `\n`;
  }

  if (plan.team_deployment?.length) {
    text += `----------------------------------------------------------\n`;
    text += `TEAM DEPLOYMENT ZONES:\n`;
    text += `----------------------------------------------------------\n`;
    plan.team_deployment.forEach((row) => {
      text += `• ${row.zone_or_task}: ${row.teams_assigned} ${row.team_name ? '— ' + row.team_name : ''}\n`;
    });
    text += `\n`;
  }

  if (plan.hospital_routing?.length) {
    text += `----------------------------------------------------------\n`;
    text += `HOSPITAL ROUTING & CASUALTY TRIAGE:\n`;
    text += `----------------------------------------------------------\n`;
    plan.hospital_routing.forEach((h) => {
      text += `• ${h.hospital_name} (${h.role}): ${h.reason || 'Primary casualty receipt'}\n`;
    });
    text += `\n`;
  }

  if (plan.evacuation_advice || plan.public_message) {
    text += `----------------------------------------------------------\n`;
    text += `PUBLIC ADVISORY & EVACUATION DIRECTIVE:\n`;
    text += `----------------------------------------------------------\n`;
    if (plan.evacuation_advice) text += `Evacuation Advice: ${plan.evacuation_advice}\n`;
    if (plan.public_message) text += `Public Broadcast: ${plan.public_message}\n`;
    text += `\n`;
  }

  if (plan.resources) {
    text += `----------------------------------------------------------\n`;
    text += `RESOURCE ESTIMATES (DAILY):\n`;
    text += `----------------------------------------------------------\n`;
    text += `• Water: ${Number(plan.resources.water_litres_per_day || 0).toLocaleString()} Litres/day\n`;
    text += `• Food:  ${Number(plan.resources.food_packets_per_day || 0).toLocaleString()} Packets/day\n\n`;
  }

  text += `==========================================================\n`;
  text += `Generated automatically by RescueAI Advanced Incident Planner\n`;

  // Trigger download as .txt
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const cleanLoc = location.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 20);
  a.href = url;
  a.download = `RescuePlan_${disasterType}_${cleanLoc}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
