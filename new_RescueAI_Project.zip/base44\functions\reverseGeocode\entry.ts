import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { reversePlace } from '../../shared/live.ts';

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const lat = Number(body?.lat);
    const lng = Number(body?.lng);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return Response.json({ error: 'Valid coordinates are required.' }, { status: 400 });
    }

    const place = await reversePlace(base44, lat, lng);
    return Response.json(place);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Could not look up this location.' }, { status: 502 });
  }
}
