import { AlertTriangle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-ink/5 bg-white/60">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div className="flex items-start gap-2.5 text-sm text-graphite">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-coral" aria-hidden="true" />
          <p className="max-w-xl leading-relaxed">
            This is a prototype. In a real emergency call 112 (India) or your local emergency number.
          </p>
        </div>
        <p className="text-xs text-graphite/80">RescueAI · disaster severity prediction &amp; rescue planning</p>
      </div>
    </footer>
  );
}
