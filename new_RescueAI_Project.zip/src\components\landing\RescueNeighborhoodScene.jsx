import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

/**
 * RescueNeighborhoodScene:
 * "HELP FINDING ITS WAY"
 *
 * A cohesive, purposeful 3D isometric emergency-response scene:
 * - Uncluttered isometric neighborhood with muted slate-blue & warm off-white buildings
 * - Connected medium-slate roads with markings
 * - Emergency-services dispatch station
 * - Recognizable ambulance on the road heading toward the incident
 * - One incident location marked by a restrained red emergency beacon (#E5484D)
 * - Continuous blue-teal route (#2563EB / #0EA5E9) connecting the ambulance to the incident
 * - An animated gentle light pulse traveling along the route
 * - Grounded shadows, soft daylight lighting, steady isometric camera
 * - Blends into the page background (#DFE8F2) with a soft terrain edge
 */

function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

export default function RescueNeighborhoodScene() {
  const mountRef = useRef(null);
  const [hasWebGL] = useState(() => isWebGLAvailable());

  useEffect(() => {
    if (!hasWebGL) return;
    const mount = mountRef.current;
    if (!mount) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let width = mount.clientWidth || 640;
    let height = mount.clientHeight || 520;

    // 1. Scene & Isometric Perspective Camera
    const scene = new THREE.Scene();
    scene.background = null; // Transparent to blend seamlessly into #DFE8F2

    const aspect = width / height;
    const camera = new THREE.PerspectiveCamera(34, aspect, 0.1, 100);
    // Classical architectural isometric angle
    camera.position.set(16, 18, 16);
    camera.lookAt(0.2, 0.2, -0.2);

    // 2. WebGL Renderer with Soft Shadows
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    mount.appendChild(renderer.domElement);

    // 3. Daylight Lighting (Soft, realistic, good contrast)
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xc8d6e5, 1.35);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.45);
    sunLight.position.set(15, 24, 12);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 50;
    sunLight.shadow.camera.left = -12;
    sunLight.shadow.camera.right = 12;
    sunLight.shadow.camera.top = 12;
    sunLight.shadow.camera.bottom = -12;
    sunLight.shadow.bias = -0.0004;
    scene.add(sunLight);

    // Soft sky fill
    const fillLight = new THREE.DirectionalLight(0xcde0f2, 0.55);
    fillLight.position.set(-10, 14, -8);
    scene.add(fillLight);

    // Main Group Container
    const root = new THREE.Group();
    scene.add(root);

    // Materials Palette
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0xc8d6e5,
      roughness: 0.75,
      metalness: 0.05
    });

    const parkMat = new THREE.MeshStandardMaterial({
      color: 0xb4cbba, // soft muted park green
      roughness: 0.8,
      metalness: 0.02
    });

    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x4a5868, // medium slate asphalt
      roughness: 0.65,
      metalness: 0.08
    });

    const roadMarkMat = new THREE.MeshBasicMaterial({
      color: 0xe2e8f0
    });

    const offWhiteBuildingMat = new THREE.MeshStandardMaterial({
      color: 0xf5f7fa, // warm off-white
      roughness: 0.45,
      metalness: 0.08
    });

    const slateBuildingMat = new THREE.MeshStandardMaterial({
      color: 0x6b829e, // muted slate-blue
      roughness: 0.4,
      metalness: 0.12
    });

    const darkSlateRoofMat = new THREE.MeshStandardMaterial({
      color: 0x4f647c,
      roughness: 0.5,
      metalness: 0.1
    });

    const windowGlassMat = new THREE.MeshStandardMaterial({
      color: 0x33475b,
      roughness: 0.2,
      metalness: 0.4
    });

    const treeFoliageMat1 = new THREE.MeshStandardMaterial({
      color: 0x6b8f72,
      roughness: 0.75,
      metalness: 0.02
    });

    const treeFoliageMat2 = new THREE.MeshStandardMaterial({
      color: 0x7e9f84,
      roughness: 0.75,
      metalness: 0.02
    });

    const treeTrunkMat = new THREE.MeshStandardMaterial({
      color: 0x6e5647,
      roughness: 0.85
    });

    // 4. Ground Terrain Base (Beveled soft edge that blends into #DFE8F2)
    const baseGeo = new THREE.CylinderGeometry(9.2, 9.8, 0.4, 48);
    const baseMesh = new THREE.Mesh(baseGeo, terrainMat);
    baseMesh.position.y = -0.2;
    baseMesh.receiveShadow = true;
    root.add(baseMesh);

    // Park greenery patches
    const park1Geo = new THREE.BoxGeometry(3.6, 0.03, 3.2);
    const park1 = new THREE.Mesh(park1Geo, parkMat);
    park1.position.set(-4.2, 0.01, 2.8);
    park1.receiveShadow = true;
    root.add(park1);

    const park2Geo = new THREE.BoxGeometry(2.8, 0.03, 2.6);
    const park2 = new THREE.Mesh(park2Geo, parkMat);
    park2.position.set(4.4, 0.01, -3.8);
    park2.receiveShadow = true;
    root.add(park2);

    // 5. Connected Roads System (Medium Slate #4A5868)
    const roadsGroup = new THREE.Group();
    root.add(roadsGroup);

    const makeRoad = (w, d, x, z) => {
      const geo = new THREE.BoxGeometry(w, 0.025, d);
      const mesh = new THREE.Mesh(geo, roadMat);
      mesh.position.set(x, 0.0125, z);
      mesh.receiveShadow = true;
      roadsGroup.add(mesh);
      return mesh;
    };

    // Main Avenue East-West
    makeRoad(16.0, 1.5, 0, -1.0);
    // Cross Avenue North-South
    makeRoad(1.5, 15.0, 1.5, 0);
    // Residential Lane connecting to Incident
    makeRoad(8.0, 1.3, 2.5, 2.5);
    // Station Service Spur
    makeRoad(4.0, 1.3, -4.5, -2.5);

    // White dashed road markings
    const dashGeo = new THREE.BoxGeometry(0.5, 0.03, 0.08);
    for (let x = -7; x <= 7; x += 1.4) {
      if (Math.abs(x - 1.5) > 0.9) {
        const dash = new THREE.Mesh(dashGeo, roadMarkMat);
        dash.position.set(x, 0.027, -1.0);
        roadsGroup.add(dash);
      }
    }
    const dashZGeo = new THREE.BoxGeometry(0.08, 0.03, 0.5);
    for (let z = -6.5; z <= 6.5; z += 1.4) {
      if (Math.abs(z + 1.0) > 0.9) {
        const dash = new THREE.Mesh(dashZGeo, roadMarkMat);
        dash.position.set(1.5, 0.027, z);
        roadsGroup.add(dash);
      }
    }

    // 6. Emergency Services Station (West Sector, near road origin)
    const stationGroup = new THREE.Group();
    stationGroup.position.set(-5.0, 0, -3.8);
    root.add(stationGroup);

    // Station Main Structure (Off-white with slate-blue accents)
    const stationMainGeo = new THREE.BoxGeometry(3.0, 1.8, 2.4);
    const stationMain = new THREE.Mesh(stationMainGeo, offWhiteBuildingMat);
    stationMain.position.set(0, 0.9, 0);
    stationMain.castShadow = true;
    stationMain.receiveShadow = true;
    stationGroup.add(stationMain);

    // Station Garage Bay (Vehicle exit)
    const bayGeo = new THREE.BoxGeometry(1.6, 1.1, 0.08);
    const bayMat = new THREE.MeshStandardMaterial({ color: 0x3d4f63, roughness: 0.6 });
    const bayDoor = new THREE.Mesh(bayGeo, bayMat);
    bayDoor.position.set(0, 0.55, 1.21);
    stationGroup.add(bayDoor);

    // Emergency Station Red Cross Emblem above bay
    const crossMat = new THREE.MeshBasicMaterial({ color: 0xe5484d });
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.32, 0.02), crossMat);
    crossV.position.set(0, 1.35, 1.22);
    stationGroup.add(crossV);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.09, 0.02), crossMat);
    crossH.position.set(0, 1.35, 1.22);
    stationGroup.add(crossH);

    // Roof parapet
    const stationRoof = new THREE.Mesh(
      new THREE.BoxGeometry(3.1, 0.12, 2.5),
      darkSlateRoofMat
    );
    stationRoof.position.set(0, 1.86, 0);
    stationRoof.castShadow = true;
    stationGroup.add(stationRoof);

    // Radio Dispatch Antenna
    const mastGeo = new THREE.CylinderGeometry(0.03, 0.03, 1.2, 8);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x8a9ba8, metalness: 0.5 });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.set(-1.0, 2.46, -0.6);
    stationGroup.add(mast);

    const mastBeacon = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0x2563eb })
    );
    mastBeacon.position.set(-1.0, 3.1, -0.6);
    stationGroup.add(mastBeacon);

    // 7. Neighborhood Buildings (Muted Slate-Blue & Warm Off-White)
    const buildings = [
      // Incident House / Building (Southeast Sector, near incident marker)
      {
        x: 4.8,
        z: 3.8,
        w: 2.2,
        d: 2.0,
        h: 2.2,
        mat: offWhiteBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      },
      // Adjacent Townhouse
      {
        x: 2.2,
        z: 4.2,
        w: 1.8,
        d: 1.8,
        h: 1.7,
        mat: slateBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      },
      // Northeast Mid-rise
      {
        x: 4.2,
        z: -2.8,
        w: 2.4,
        d: 2.2,
        h: 3.2,
        mat: slateBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      },
      // Center-North Commercial Block
      {
        x: -1.2,
        z: -3.6,
        w: 2.2,
        d: 2.2,
        h: 2.4,
        mat: offWhiteBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      },
      // Southwest Residential
      {
        x: -1.6,
        z: 2.8,
        w: 2.0,
        d: 2.2,
        h: 2.0,
        mat: slateBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      },
      // West Edge Quiet Block
      {
        x: -5.2,
        z: 0.8,
        w: 1.8,
        d: 1.8,
        h: 1.5,
        mat: offWhiteBuildingMat,
        roof: darkSlateRoofMat,
        windows: true
      }
    ];

    buildings.forEach((b) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(b.x, 0, b.z);
      root.add(bGroup);

      // Main structure
      const bMesh = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), b.mat);
      bMesh.position.y = b.h / 2;
      bMesh.castShadow = true;
      bMesh.receiveShadow = true;
      bGroup.add(bMesh);

      // Roof rim
      const rMesh = new THREE.Mesh(new THREE.BoxGeometry(b.w + 0.1, 0.1, b.d + 0.1), b.roof);
      rMesh.position.y = b.h + 0.05;
      rMesh.castShadow = true;
      bGroup.add(rMesh);

      // Architectural window rows
      if (b.windows) {
        const winGeo = new THREE.BoxGeometry(0.32, 0.38, 0.02);
        const floors = Math.floor(b.h / 0.8);
        for (let f = 1; f <= floors; f++) {
          const y = f * 0.72;
          // Front windows
          const w1 = new THREE.Mesh(winGeo, windowGlassMat);
          w1.position.set(-b.w * 0.25, y, b.d / 2 + 0.015);
          bGroup.add(w1);

          const w2 = new THREE.Mesh(winGeo, windowGlassMat);
          w2.position.set(b.w * 0.25, y, b.d / 2 + 0.015);
          bGroup.add(w2);
        }
      }
    });

    // 8. Low-Poly Trees along streets and parks
    const treePositions = [
      { x: -3.2, z: 2.2, scale: 1.0, mat: treeFoliageMat1 },
      { x: -4.8, z: 3.6, scale: 1.2, mat: treeFoliageMat2 },
      { x: -3.8, z: 1.5, scale: 0.9, mat: treeFoliageMat1 },
      { x: 3.2, z: -4.2, scale: 1.1, mat: treeFoliageMat2 },
      { x: 5.2, z: -4.6, scale: 1.0, mat: treeFoliageMat1 },
      { x: 0.3, z: 2.4, scale: 0.9, mat: treeFoliageMat1 },
      { x: 2.8, z: 0.2, scale: 1.0, mat: treeFoliageMat2 },
      { x: -0.2, z: -2.0, scale: 1.1, mat: treeFoliageMat1 },
      { x: 3.4, z: 2.0, scale: 0.85, mat: treeFoliageMat2 }
    ];

    treePositions.forEach((tp) => {
      const tree = new THREE.Group();
      tree.position.set(tp.x, 0, tp.z);
      tree.scale.set(tp.scale, tp.scale, tp.scale);

      // Trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.5, 8), treeTrunkMat);
      trunk.position.y = 0.25;
      trunk.castShadow = true;
      tree.add(trunk);

      // Dual foliage cones
      const f1 = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.7, 8), tp.mat);
      f1.position.y = 0.65;
      f1.castShadow = true;
      tree.add(f1);

      const f2 = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.55, 8), tp.mat);
      f2.position.y = 1.0;
      f2.castShadow = true;
      tree.add(f2);

      root.add(tree);
    });

    // 9. Clearly Recognizable AMBULANCE
    // Positioned on the main avenue, heading east toward the turn
    const ambulance = new THREE.Group();
    ambulance.position.set(-1.8, 0.02, -1.0);
    ambulance.rotation.y = -Math.PI / 2; // Facing +X (east along road)
    root.add(ambulance);

    // Chassis / Lower Body
    const chassisMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.12, 1.7), chassisMat);
    chassis.position.y = 0.12;
    ambulance.add(chassis);

    // Main Ambulance Box (Crisp Emergency White)
    const ambWhiteMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.35,
      metalness: 0.08
    });
    const ambBody = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.65, 1.1), ambWhiteMat);
    ambBody.position.set(0, 0.48, -0.22);
    ambBody.castShadow = true;
    ambulance.add(ambBody);

    // Front Cab
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.48, 0.55), ambWhiteMat);
    cab.position.set(0, 0.4, 0.58);
    cab.castShadow = true;
    ambulance.add(cab);

    // Windshield & Side Windows
    const ambGlassMat = new THREE.MeshStandardMaterial({ color: 0x1e3a5f, roughness: 0.2, metalness: 0.5 });
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.26, 0.03), ambGlassMat);
    windshield.position.set(0, 0.48, 0.86);
    windshield.rotation.x = 0.15;
    ambulance.add(windshield);

    // Red Emergency Stripe along flank (#E5484D)
    const ambStripeMat = new THREE.MeshBasicMaterial({ color: 0xe5484d });
    const stripeL = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.12, 1.3), ambStripeMat);
    stripeL.position.set(-0.385, 0.42, 0.05);
    ambulance.add(stripeL);

    const stripeR = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.12, 1.3), ambStripeMat);
    stripeR.position.set(0.385, 0.42, 0.05);
    ambulance.add(stripeR);

    // Red Cross Decals on flanks
    const makeDecalCross = (x, rotY) => {
      const cross = new THREE.Group();
      cross.position.set(x, 0.58, -0.22);
      cross.rotation.y = rotY;
      const v = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.01), ambStripeMat);
      const h = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.06, 0.01), ambStripeMat);
      cross.add(v, h);
      return cross;
    };
    ambulance.add(makeDecalCross(-0.385, -Math.PI / 2));
    ambulance.add(makeDecalCross(0.385, Math.PI / 2));

    // Wheels (4 grounded dark rubber tires)
    const wheelGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.1, 16);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });
    const wFL = new THREE.Mesh(wheelGeo, wheelMat);
    wFL.position.set(-0.38, 0.14, 0.52);
    const wFR = new THREE.Mesh(wheelGeo, wheelMat);
    wFR.position.set(0.38, 0.14, 0.52);
    const wBL = new THREE.Mesh(wheelGeo, wheelMat);
    wBL.position.set(-0.38, 0.14, -0.52);
    const wBR = new THREE.Mesh(wheelGeo, wheelMat);
    wBR.position.set(0.38, 0.14, -0.52);
    ambulance.add(wFL, wFR, wBL, wBR);

    // Emergency Roof Light Bar (Restrained Blue & Red)
    const lightBar = new THREE.Group();
    lightBar.position.set(0, 0.84, 0.35);
    ambulance.add(lightBar);

    const lightBase = new THREE.Mesh(
      new THREE.BoxGeometry(0.44, 0.05, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x334155 })
    );
    lightBar.add(lightBase);

    const redLight = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.08, 0.08),
      new THREE.MeshBasicMaterial({ color: 0xe5484d })
    );
    redLight.position.x = -0.11;
    lightBar.add(redLight);

    const blueLight = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.08, 0.08),
      new THREE.MeshBasicMaterial({ color: 0x2563eb })
    );
    blueLight.position.x = 0.11;
    lightBar.add(blueLight);

    // 10. INCIDENT BEACON (#E5484D - Restrained, slow pulse)
    // Positioned at the residential house destination
    const incidentPos = new THREE.Vector3(4.8, 0.03, 2.5);
    const incidentGroup = new THREE.Group();
    incidentGroup.position.copy(incidentPos);
    root.add(incidentGroup);

    // Pin stem & sphere
    const pinStem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 0.9, 12),
      new THREE.MeshStandardMaterial({ color: 0xe5484d, roughness: 0.3 })
    );
    pinStem.position.y = 0.45;
    incidentGroup.add(pinStem);

    const pinHead = new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 16, 16),
      new THREE.MeshStandardMaterial({
        color: 0xe5484d,
        roughness: 0.2,
        emissive: 0xe5484d,
        emissiveIntensity: 0.3
      })
    );
    pinHead.position.y = 0.95;
    pinHead.castShadow = true;
    incidentGroup.add(pinHead);

    // Concentric ground pulse rings
    const ringGeo1 = new THREE.RingGeometry(0.25, 0.35, 32);
    ringGeo1.rotateX(-Math.PI / 2);
    const ringMat1 = new THREE.MeshBasicMaterial({
      color: 0xe5484d,
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.position.y = 0.01;
    incidentGroup.add(ring1);

    const ringGeo2 = new THREE.RingGeometry(0.5, 0.62, 32);
    ringGeo2.rotateX(-Math.PI / 2);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0xe5484d,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.position.y = 0.01;
    incidentGroup.add(ring2);

    // 11. CONTINUOUS BLUE-TEAL RESPONSE ROUTE
    // Path connecting Ambulance to Incident along the road:
    // From (-1.8, -1.0) -> (1.5, -1.0) -> (1.5, 2.5) -> (4.8, 2.5)
    const curvePoints = [
      new THREE.Vector3(-1.0, 0.04, -1.0),
      new THREE.Vector3(0.5, 0.04, -1.0),
      new THREE.Vector3(1.2, 0.04, -0.7),
      new THREE.Vector3(1.5, 0.04, 0.0),
      new THREE.Vector3(1.5, 0.04, 1.8),
      new THREE.Vector3(1.8, 0.04, 2.3),
      new THREE.Vector3(2.5, 0.04, 2.5),
      new THREE.Vector3(4.5, 0.04, 2.5)
    ];

    const routeCurve = new THREE.CatmullRomCurve3(curvePoints);
    const routeGeo = new THREE.TubeGeometry(routeCurve, 64, 0.065, 8, false);
    const routeMat = new THREE.MeshStandardMaterial({
      color: 0x2563eb,
      emissive: 0x0ea5e9,
      emissiveIntensity: 0.55,
      roughness: 0.25,
      metalness: 0.2
    });
    const routeMesh = new THREE.Mesh(routeGeo, routeMat);
    root.add(routeMesh);

    // Route Outer Glow / Ribbon underlay
    const ribbonGeo = new THREE.TubeGeometry(routeCurve, 64, 0.12, 8, false);
    const ribbonMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.25
    });
    const ribbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
    ribbonMesh.position.y = -0.01;
    root.add(ribbonMesh);

    // Traveling Light Pulse along the route
    const pulseLightGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const pulseLightMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8
    });
    const pulseLight = new THREE.Mesh(pulseLightGeo, pulseLightMat);
    pulseLight.position.copy(curvePoints[0]);
    root.add(pulseLight);

    // 12. Gentle Parallax & Steady Animation Loop
    let mouseX = 0;
    let mouseY = 0;
    let targetRotX = 0;
    let targetRotY = 0;

    const handleMouseMove = (e) => {
      if (prefersReducedMotion) return;
      const rect = mount.getBoundingClientRect();
      const normX = (e.clientX - rect.left) / rect.width - 0.5;
      const normY = (e.clientY - rect.top) / rect.height - 0.5;
      targetRotY = normX * 0.05;
      targetRotX = normY * 0.04;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Handle Window Resize
    const handleResize = () => {
      if (!mount) return;
      width = mount.clientWidth || 640;
      height = mount.clientHeight || 520;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    let animationFrameId;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Subtle mouse parallax (smooth dampening)
      if (!prefersReducedMotion) {
        root.rotation.y += (targetRotY - root.rotation.y) * 0.05;
        root.rotation.x += (targetRotX - root.rotation.x) * 0.05;

        // 1. Gentle traveling light pulse along the response route
        const routeProgress = (elapsedTime * 0.28) % 1.0;
        const pulsePos = routeCurve.getPointAt(routeProgress);
        pulseLight.position.copy(pulsePos);
        pulseLight.position.y = 0.08;

        // 2. Restrained, slow beacon pulse
        const pulseFactor = (Math.sin(elapsedTime * 2.2) + 1) / 2;
        pinHead.position.y = 0.95 + pulseFactor * 0.06;
        ring1.scale.setScalar(1.0 + pulseFactor * 0.25);
        ringMat1.opacity = 0.45 + (1 - pulseFactor) * 0.35;
        ring2.scale.setScalar(1.0 + pulseFactor * 0.4);
        ringMat2.opacity = 0.15 + (1 - pulseFactor) * 0.25;

        // 3. Ambulance emergency light bar gentle flash
        const flash = Math.sin(elapsedTime * 4.0) > 0;
        redLight.visible = flash;
        blueLight.visible = !flash;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);

      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();

      // Clean geometry disposals
      baseGeo.dispose();
      terrainMat.dispose();
      roadMat.dispose();
      offWhiteBuildingMat.dispose();
      slateBuildingMat.dispose();
      darkSlateRoofMat.dispose();
      routeGeo.dispose();
      routeMat.dispose();
      ribbonGeo.dispose();
      ribbonMat.dispose();
    };
  }, [hasWebGL]);

  if (!hasWebGL) {
    return (
      <div className="rescue-scene-svg-fallback" aria-label="Rescue illustration">
        {/* Cohesive Isometric SVG Fallback if WebGL is unavailable */}
        <svg
          viewBox="0 0 600 500"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Soft Ground Terrain */}
          <polygon points="300,80 540,210 300,380 60,250" fill="#C8D6E5" />
          <polygon points="300,380 540,210 540,230 300,400" fill="#B2C2D4" />
          <polygon points="300,380 60,250 60,270 300,400" fill="#9FB2C6" />

          {/* Roads */}
          <polygon points="120,225 240,160 480,290 360,355" fill="#4A5868" />
          <polygon points="240,160 380,85 440,118 300,192" fill="#4A5868" />

          {/* Emergency Station */}
          <polygon points="210,140 270,105 270,165 210,200" fill="#E2E8F0" />
          <polygon points="270,105 320,135 320,195 270,165" fill="#CBD5E1" />
          <polygon points="210,140 260,110 320,135 270,165" fill="#F8FAFC" />
          {/* Station Red Cross */}
          <rect x="235" y="150" width="8" height="22" fill="#E5484D" />
          <rect x="228" y="157" width="22" height="8" fill="#E5484D" />

          {/* Residential Buildings */}
          <polygon points="380,260 430,230 430,280 380,310" fill="#6B829E" />
          <polygon points="430,230 470,252 470,302 430,280" fill="#52667A" />
          <polygon points="380,260 420,238 470,252 430,280" fill="#8FA3BC" />

          {/* Ambulance on road */}
          <g transform="translate(260, 220)">
            <rect x="0" y="0" width="48" height="26" rx="4" fill="#FFFFFF" />
            <rect x="0" y="12" width="48" height="6" fill="#E5484D" />
            <circle cx="12" cy="26" r="6" fill="#1E293B" />
            <circle cx="36" cy="26" r="6" fill="#1E293B" />
            <rect x="20" y="-4" width="8" height="4" fill="#2563EB" />
          </g>

          {/* Continuous Blue Route */}
          <path
            d="M 290 232 C 340 260, 360 270, 420 305"
            stroke="#2563EB"
            strokeWidth="6"
            strokeLinecap="round"
          />
          <path
            d="M 290 232 C 340 260, 360 270, 420 305"
            stroke="#38BDF8"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Incident Beacon */}
          <circle cx="430" cy="305" r="16" fill="#E5484D" fillOpacity="0.25" />
          <circle cx="430" cy="305" r="8" fill="#E5484D" fillOpacity="0.6" />
          <circle cx="430" cy="305" r="4" fill="#E5484D" />
        </svg>
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className="rescue-neighborhood-canvas-container"
      aria-label="3D Emergency Assistance Scene"
      role="img"
    />
  );
}
