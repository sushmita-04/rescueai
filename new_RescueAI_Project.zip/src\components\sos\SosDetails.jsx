import { Loader2, MapPin, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { MAX_NOTE_LENGTH, SITUATIONS } from '@/lib/sos';

export default function SosDetails({ values, onChange, errors = {}, geoState, onShareLocation }) {
  const update = (key, value) => onChange({ ...values, [key]: value });

  return (
    <div className="rounded-[16px] bg-white p-5 shadow-soft ring-1 ring-black/5 sm:p-7">
      <h2 className="font-heading text-xl text-ink sm:text-2xl">Details for the team</h2>
      <p className="mt-1 text-sm text-graphite">All optional, but every detail helps them find you.</p>

      <div className="mt-5">
        <p className="text-sm font-medium text-ink">Situation</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {SITUATIONS.map((situation) => {
            const active = values.situation === situation.value;
            return (
              <button
                key={situation.value}
                type="button"
                aria-pressed={active}
                onClick={() => update('situation', active ? '' : situation.value)}
                className={cn(
                  'rounded-full border px-3 py-1.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral/40',
                  active
                    ? 'border-coral bg-coral/10 text-coral'
                    : 'border-ink/10 bg-white text-steel hover:border-steel/40'
                )}
              >
                {situation.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="sos-name" className="text-sm font-medium text-ink">
            Your name
          </Label>
          <Input
            id="sos-name"
            value={values.name}
            onChange={(event) => update('name', event.target.value)}
            className="mt-1.5 h-11 rounded-xl"
            placeholder="Optional"
            autoComplete="name"
          />
        </div>

        <div>
          <Label htmlFor="sos-phone" className="text-sm font-medium text-ink">
            Phone
          </Label>
          <Input
            id="sos-phone"
            value={values.phone}
            onChange={(event) => update('phone', event.target.value)}
            className={cn('mt-1.5 h-11 rounded-xl', errors.phone && 'border-sev-critical')}
            placeholder="Call-back number"
            inputMode="tel"
            autoComplete="tel"
            aria-invalid={Boolean(errors.phone)}
          />
          {errors.phone ? (
            <p className="mt-1 text-xs font-medium text-sev-critical">{errors.phone}</p>
          ) : null}
        </div>
      </div>

      <div className="mt-4">
        <Label htmlFor="sos-people" className="text-sm font-medium text-ink">
          People with you
        </Label>
        <Input
          id="sos-people"
          type="number"
          min={0}
          inputMode="numeric"
          value={values.people_count}
          onChange={(event) => update('people_count', event.target.value)}
          className={cn('mt-1.5 h-11 rounded-xl', errors.people_count && 'border-sev-critical')}
          placeholder="0"
          aria-invalid={Boolean(errors.people_count)}
        />
        {errors.people_count ? (
          <p className="mt-1 text-xs font-medium text-sev-critical">{errors.people_count}</p>
        ) : null}
      </div>

      <div className="mt-4">
        <p className="text-sm font-medium text-ink">Your location</p>
        <Button
          type="button"
          variant="outline"
          onClick={onShareLocation}
          disabled={geoState === 'loading'}
          className="mt-1.5 h-11 w-full justify-start rounded-xl border-ink/10 text-steel hover:bg-canvas"
        >
          {geoState === 'loading' ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
          ) : values.lat !== null && values.lat !== undefined ? (
            <Navigation className="mr-2 h-4 w-4 text-sev-low" aria-hidden="true" />
          ) : (
            <MapPin className="mr-2 h-4 w-4" aria-hidden="true" />
          )}
          {geoState === 'loading'
            ? 'Finding your location…'
            : values.lat !== null && values.lat !== undefined
              ? `Location shared (${Number(values.lat).toFixed(4)}, ${Number(values.lng).toFixed(4)})`
              : 'Share my location'}
        </Button>
        {geoState === 'error' ? (
          <p className="mt-1 text-xs font-medium text-sev-critical">
            Location unavailable. Type a landmark below instead.
          </p>
        ) : null}
      </div>

      <div className="mt-4">
        <Label htmlFor="sos-location" className="text-sm font-medium text-ink">
          Location or landmark
        </Label>
        <Input
          id="sos-location"
          value={values.location_text}
          onChange={(event) => update('location_text', event.target.value)}
          className="mt-1.5 h-11 rounded-xl"
          placeholder="Building, street, floor or landmark"
        />
      </div>

      <div className="mt-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="sos-note" className="text-sm font-medium text-ink">
            Extra note
          </Label>
          <span className="text-[11px] text-graphite">
            {values.note.length}/{MAX_NOTE_LENGTH}
          </span>
        </div>
        <Textarea
          id="sos-note"
          value={values.note}
          maxLength={MAX_NOTE_LENGTH}
          onChange={(event) => update('note', event.target.value.slice(0, MAX_NOTE_LENGTH))}
          className="mt-1.5 min-h-[88px] rounded-xl"
          placeholder="Injuries, water level, access route, anything the team should know."
        />
      </div>
    </div>
  );
}
