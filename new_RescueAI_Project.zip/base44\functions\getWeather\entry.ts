import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cached, cacheKey, fetchJson, roundCoord } from '../../shared/live.ts';

function conditionFor(code: number) {
  if (code === 0) return 'Clear sky';
  if (code <= 2) return 'Partly cloudy';
  if (code === 3) return 'Overcast';
  if (code <= 48) return 'Fog';
  if (code <= 57) return 'Drizzle';
  if (code <= 67) return 'Rain';
  if (code <= 77) return 'Snow';
  if (code <= 82) return 'Rain showers';
  if (code <= 86) return 'Snow showers';
  return 'Thunderstorm';
}

function riskFor(rainfall24: number) {
  if (rainfall24 < 20) return 'low';
  if (rainfall24 < 100) return 'moderate';
  if (rainfall24 < 250) return 'high';
  return 'extreme';
}

function finish(values: any) {
  const gusts = Number(values.wind_gusts ?? 0);
  const apparent = Number(values.apparent_temperature ?? 0);
  const flags: string[] = [];
  if (gusts > 60) flags.push('Strong winds');
  if (apparent > 40) flags.push('Heat');
  return {
    ...values,
    wind_gusts: gusts,
    apparent_temperature: apparent,
    flags,
    weather_risk: riskFor(Number(values.rainfall_last_24h ?? 0))
  };
}

async function fromOpenMeteo(lat: number, lng: number) {
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
    '&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m' +
    '&hourly=precipitation&past_days=1&forecast_days=2&timezone=auto';

  const payload = await fetchJson(url);
  const current = payload?.current || {};
  const hourly = payload?.hourly || {};
  const times: string[] = Array.isArray(hourly.time) ? hourly.time : [];
  const rain: number[] = Array.isArray(hourly.precipitation) ? hourly.precipitation : [];

  let index = times.findIndex((time) => time === current.time);
  if (index < 0) index = Math.min(23, Math.max(0, times.length - 25));

  const sum = (from: number, to: number) => {
    let total = 0;
    for (let i = from; i <= to; i += 1) {
      const value = Number(rain[i]);
      if (Number.isFinite(value)) total += value;
    }
    return Math.round(total * 10) / 10;
  };

  return finish({
    temperature: Number(current.temperature_2m ?? 0),
    apparent_temperature: Number(current.apparent_temperature ?? 0),
    humidity: Number(current.relative_humidity_2m ?? 0),
    precipitation: Number(current.precipitation ?? 0),
    wind_speed: Number(current.wind_speed_10m ?? 0),
    wind_gusts: Number(current.wind_gusts_10m ?? 0),
    weather_code: Number(current.weather_code ?? 0),
    condition: conditionFor(Number(current.weather_code ?? 0)),
    rainfall_last_24h: sum(Math.max(0, index - 23), index),
    rainfall_next_24h: sum(index + 1, Math.min(rain.length - 1, index + 24)),
    timezone: payload?.timezone || '',
    provider: 'Open-Meteo'
  });
}

async function fromWttr(lat: number, lng: number) {
  const payload = await fetchJson(`https://wttr.in/${lat},${lng}?format=j1`);
  const current = payload?.current_condition?.[0] || {};
  const days = Array.isArray(payload?.weather) ? payload.weather : [];

  const slots: { at: number; mm: number }[] = [];
  days.forEach((day: any) => {
    const date = String(day?.date || '');
    (Array.isArray(day?.hourly) ? day.hourly : []).forEach((hour: any) => {
      const minutes = Number(hour?.time || 0);
      const at = new Date(`${date}T00:00:00Z`).getTime() + minutes * 60 * 1000;
      slots.push({ at, mm: Number(hour?.precipMM || 0) });
    });
  });

  const observed = String(current?.observation_time || '12:00 PM');
  const match = observed.match(/(\d+):(\d+)\s*(AM|PM)/i);
  let hour = 12;
  if (match) {
    hour = Number(match[1]) % 12;
    if (match[3].toUpperCase() === 'PM') hour += 12;
  }
  const now = slots.length > 0 ? Date.now() : 0;
  const dayStart = slots.length > 0 ? new Date(slots[0].at).setUTCHours(0, 0, 0, 0) : 0;
  const approxNow = dayStart + hour * 3600 * 1000;

  const past = slots.filter((slot) => slot.at <= approxNow && slot.at > approxNow - 24 * 3600 * 1000);
  const next = slots.filter((slot) => slot.at > approxNow && slot.at <= approxNow + 24 * 3600 * 1000);

  const code = Number(current?.weatherCode ?? 0);
  return finish({
    temperature: Number(current?.temp_C ?? 0),
    apparent_temperature: Number(current?.FeelsLikeC ?? 0),
    humidity: Number(current?.humidity ?? 0),
    precipitation: Number(current?.precipMM ?? 0),
    wind_speed: Number(current?.windspeedKmph ?? 0),
    wind_gusts: Number(current?.WindGustKmph ?? 0),
    weather_code: code,
    condition: String(current?.weatherDesc?.[0]?.value || conditionFor(code)),
    rainfall_last_24h: Math.round(past.reduce((total, slot) => total + slot.mm, 0) * 10) / 10,
    rainfall_next_24h: Math.round(next.reduce((total, slot) => total + slot.mm, 0) * 10) / 10,
    timezone: String(payload?.nearest_area?.[0]?.region?.[0]?.value || ''),
    provider: now ? 'wttr.in' : 'wttr.in'
  });
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const lat = Number(body?.lat);
    const lng = Number(body?.lng);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return Response.json({ error: 'Valid coordinates are required.' }, { status: 400 });
    }

    const data = await cached(base44, cacheKey(['weather', roundCoord(lat), roundCoord(lng)]), async () => {
      try {
        return await fromOpenMeteo(lat, lng);
      } catch {
        return await fromWttr(lat, lng);
      }
    });

    return Response.json(data);
  } catch (error: any) {
    return Response.json({ error: error?.message || 'Weather service did not respond.' }, { status: 502 });
  }
}
