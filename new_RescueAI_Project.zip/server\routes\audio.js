import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import multer from 'multer';
import { requireStaff } from '../auth.js';

const router = express.Router();

const uploadsDir = path.resolve(process.cwd(), 'server', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.webm';
    const id = crypto.randomBytes(12).toString('hex');
    cb(null, `${id}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype.startsWith('audio/') ||
      file.mimetype.startsWith('image/') ||
      file.originalname.match(/\.(webm|mp4|m4a|ogg|wav|mp3|jpg|jpeg|png|webp|gif)$/i)
    ) {
      cb(null, true);
    } else {
      cb(new Error('Audio and image files only'));
    }
  }
});

function getSecret() {
  return process.env.SESSION_SECRET || 'rescueai-super-secret-key-123';
}

function signUri(uri, expiresAt) {
  return crypto
    .createHmac('sha256', getSecret())
    .update(`${uri}:${expiresAt}`)
    .digest('hex');
}

// POST /api/integrations/core/upload-private-file (Public SOS audio upload)
router.post('/integrations/core/upload-private-file', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No audio file uploaded or file exceeds 10MB' });
  }

  const fileUri = `uploads/${req.file.filename}`;
  return res.json({ file_uri: fileUri });
});

// POST /api/audio/transcribe (Transcribe audio via AI/Gemini fallback)
router.post('/audio/transcribe', upload.single('file'), async (req, res) => {
  try {
    let audioFilePath = '';
    if (req.file) {
      audioFilePath = path.join(uploadsDir, req.file.filename);
    } else if (req.body?.file_uri) {
      const safeFilename = path.basename(String(req.body.file_uri));
      audioFilePath = path.join(uploadsDir, safeFilename);
    }

    if (!audioFilePath || !fs.existsSync(audioFilePath)) {
      return res.status(400).json({ error: 'Audio file not found' });
    }

    let transcript = '';
    if (process.env.GEMINI_API_KEY) {
      try {
        const { GoogleGenAI } = await import('@google/genai');
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const fileBuffer = fs.readFileSync(audioFilePath);
        const base64Audio = fileBuffer.toString('base64');
        const ext = path.extname(audioFilePath).toLowerCase();
        const mime = ext === '.mp4' || ext === '.m4a' ? 'audio/mp4' : 'audio/webm';

        const aiRes = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [
            {
              inlineData: {
                mimeType: mime,
                data: base64Audio
              }
            },
            {
              text: 'Transcribe this emergency voice recording word for word into clear text. Do not add intro or commentary, output only the transcribed words.'
            }
          ]
        });
        transcript = aiRes?.text?.trim() || '';
      } catch (geminiErr) {
        console.warn('Gemini transcription warning:', geminiErr.message);
      }
    }

    return res.json({ transcript });
  } catch (err) {
    console.error('Error in /api/audio/transcribe:', err);
    return res.status(500).json({ error: 'Transcription failed' });
  }
});

// POST /api/integrations/core/create-file-signed-url (Staff only)
router.post('/integrations/core/create-file-signed-url', requireStaff, (req, res) => {
  const { file_uri, expires_in = 3600 } = req.body || {};
  if (!file_uri) {
    return res.status(400).json({ error: 'Missing file_uri' });
  }

  const expires = Date.now() + Number(expires_in) * 1000;
  const token = signUri(file_uri, expires);
  const signedUrl = `/api/audio/file?uri=${encodeURIComponent(file_uri)}&token=${token}&expires=${expires}`;

  return res.json({ signed_url: signedUrl });
});

// GET /api/audio/file (Playback stream)
router.get('/audio/file', (req, res) => {
  const { uri, token, expires } = req.query;

  if (!uri || !token || !expires) {
    return res.status(401).json({ error: 'Missing signature parameters' });
  }

  if (Date.now() > Number(expires)) {
    return res.status(403).json({ error: 'Playback link expired' });
  }

  const expected = signUri(uri, expires);
  if (!crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expected))) {
    return res.status(403).json({ error: 'Invalid playback signature' });
  }

  // Prevent path traversal
  const safeFilename = path.basename(String(uri));
  const fullPath = path.join(uploadsDir, safeFilename);

  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({ error: 'Audio file not found' });
  }

  const stat = fs.statSync(fullPath);
  const range = req.headers.range;

  const ext = path.extname(fullPath).toLowerCase();
  const mimeTypes = {
    '.webm': 'audio/webm',
    '.ogg': 'audio/ogg',
    '.wav': 'audio/wav',
    '.mp3': 'audio/mpeg',
    '.m4a': 'audio/mp4',
    '.mp4': 'audio/mp4'
  };
  const contentType = mimeTypes[ext] || 'audio/webm';

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
    const chunkSize = end - start + 1;
    const fileStream = fs.createReadStream(fullPath, { start, end });

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunkSize,
      'Content-Type': contentType
    });
    fileStream.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': stat.size,
      'Content-Type': contentType
    });
    fs.createReadStream(fullPath).pipe(res);
  }
});

export default router;
