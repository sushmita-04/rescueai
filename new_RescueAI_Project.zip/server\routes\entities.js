import express from 'express';
import { query, queryOne, newId } from '../db.js';
import { requireAuth, requireStaff, requireAdmin } from '../auth.js';
import { broadcastTeamEvent } from './sos.js';

const router = express.Router();

const TABLE_MAP = {
  sosrequest: 'sos_requests',
  assessment: 'assessments',
  teamrequest: 'team_requests',
  user: 'users',
  guideline: 'guidelines'
};

function getTable(name) {
  return TABLE_MAP[String(name).toLowerCase()];
}

// Convert DB row to entity format (parsing JSON strings for SQLite)
function formatRow(row, tableName) {
  if (!row) return null;
  const copy = { ...row };
  if (copy.password_hash) {
    delete copy.password_hash;
  }

  // Parse JSON fields if they are strings
  if (tableName === 'assessments') {
    const jsonFields = [
      'probabilities',
      'priority_actions',
      'plan',
      'weather',
      'data_sources',
      'news',
      'hospitals',
      'done_actions'
    ];
    for (const f of jsonFields) {
      if (typeof copy[f] === 'string') {
        try {
          copy[f] = JSON.parse(copy[f]);
        } catch {
          // keep string
        }
      }
    }
  }

  return copy;
}

// GET /api/entities/:entityName (List or Filter)
router.get('/entities/:entityName', async (req, res) => {
  const table = getTable(req.params.entityName);
  if (!table) return res.status(404).json({ error: 'Unknown entity' });

  const isStaff = req.user && (req.user.role === 'admin' || req.user.role === 'rescue_team' || req.user.staff_type === 'rescue_team');
  const isAdmin = req.user && req.user.role === 'admin';

  // Permission checks
  if (table === 'sos_requests') {
    if (!isStaff) return res.status(401).json({ error: 'Rescue team access required to list SOS requests' });
  }

  if (table === 'users') {
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required to list users' });
  }

  if (table === 'assessments' && req.query.filterStaff) {
    if (!isStaff) return res.status(401).json({ error: 'Rescue team access required to list assessments' });
  }

  let filterQuery = {};
  if (req.query.query) {
    try {
      filterQuery = JSON.parse(req.query.query);
    } catch {}
  }

  let whereClauses = [];
  let params = [];

  // TeamRequest scoping
  if (table === 'team_requests') {
    if (!isAdmin) {
      if (!req.user) return res.status(401).json({ error: 'Authentication required' });
      whereClauses.push('created_by_id = ?');
      params.push(req.user.id);
    }
  }

  for (const [key, val] of Object.entries(filterQuery)) {
    if (val !== undefined && val !== null) {
      whereClauses.push(`${key} = ?`);
      params.push(val);
    }
  }

  let sql = `SELECT * FROM ${table}`;
  if (whereClauses.length > 0) {
    sql += ' WHERE ' + whereClauses.join(' AND ');
  }

  // Sorting
  const sort = req.query.sort;
  if (sort === '-created_date' || sort === 'desc') {
    sql += ' ORDER BY created_date DESC';
  } else if (sort === 'created_date' || sort === 'asc') {
    sql += ' ORDER BY created_date ASC';
  } else {
    sql += ' ORDER BY created_date DESC';
  }

  const limit = Math.min(Math.max(1, parseInt(req.query.limit, 10) || 100), 250);
  sql += ` LIMIT ${limit}`;

  try {
    const rows = await query(sql, params);
    const items = rows.map((r) => formatRow(r, table));
    return res.json({ items });
  } catch (err) {
    console.error(`Error querying ${table}:`, err);
    return res.status(500).json({ error: 'Query failed' });
  }
});

// GET /api/entities/:entityName/:id
router.get('/entities/:entityName/:id', async (req, res) => {
  const table = getTable(req.params.entityName);
  if (!table) return res.status(404).json({ error: 'Unknown entity' });

  const id = req.params.id;
  try {
    const row = await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    return res.json(formatRow(row, table));
  } catch (err) {
    console.error(`Error getting ${table}/${id}:`, err);
    return res.status(500).json({ error: 'Get failed' });
  }
});

// POST /api/entities/:entityName (Create)
router.post('/entities/:entityName', async (req, res) => {
  const table = getTable(req.params.entityName);
  if (!table) return res.status(404).json({ error: 'Unknown entity' });

  const data = req.body || {};
  const id = data.id || newId(req.params.entityName.toLowerCase().slice(0, 4));
  const now = new Date().toISOString();
  const created_by_id = req.user ? req.user.id : null;

  if (table === 'team_requests') {
    if (!req.user) return res.status(401).json({ error: 'Sign-in required to request team access' });
    data.created_by_id = req.user.id;
  }

  data.id = id;
  data.created_date = now;
  data.updated_date = now;
  if (!data.created_by_id && created_by_id) {
    data.created_by_id = created_by_id;
  }

  // Stringify JSON fields for SQLite compatibility
  const serialized = { ...data };
  if (table === 'assessments') {
    const jsonFields = [
      'probabilities',
      'priority_actions',
      'plan',
      'weather',
      'data_sources',
      'news',
      'hospitals',
      'done_actions'
    ];
    for (const f of jsonFields) {
      if (serialized[f] && typeof serialized[f] === 'object') {
        serialized[f] = JSON.stringify(serialized[f]);
      }
    }
  }

  const keys = Object.keys(serialized);
  const values = Object.values(serialized);
  const placeholders = keys.map(() => '?').join(', ');

  try {
    await query(`INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`, values);
    const created = await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]);

    if (table === 'sos_requests') {
      broadcastTeamEvent('sos_created', created);
    }

    return res.status(201).json(formatRow(created, table));
  } catch (err) {
    console.error(`Error creating ${table}:`, err);
    return res.status(500).json({ error: 'Create failed' });
  }
});

// PUT/PATCH /api/entities/:entityName/:id (Update)
router.put('/entities/:entityName/:id', updateEntity);
router.patch('/entities/:entityName/:id', updateEntity);

async function updateEntity(req, res) {
  const table = getTable(req.params.entityName);
  if (!table) return res.status(404).json({ error: 'Unknown entity' });

  const id = req.params.id;
  const updates = req.body || {};

  const isAdmin = req.user && req.user.role === 'admin';
  const isStaff = req.user && (req.user.role === 'admin' || req.user.role === 'rescue_team' || req.user.staff_type === 'rescue_team');

  // Security checks
  if (table === 'users') {
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required to update users' });
  }

  if (table === 'team_requests') {
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required to approve or reject requests' });
  }

  if (table === 'sos_requests') {
    if (!isStaff) return res.status(401).json({ error: 'Rescue team access required to update SOS' });
  }

  const existing = await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  const now = new Date().toISOString();
  updates.updated_date = now;
  delete updates.id;
  delete updates.created_date;

  const serialized = { ...updates };
  if (table === 'assessments') {
    const jsonFields = [
      'probabilities',
      'priority_actions',
      'plan',
      'weather',
      'data_sources',
      'news',
      'hospitals',
      'done_actions'
    ];
    for (const f of jsonFields) {
      if (serialized[f] && typeof serialized[f] === 'object') {
        serialized[f] = JSON.stringify(serialized[f]);
      }
    }
  }

  const keys = Object.keys(serialized);
  const values = Object.values(serialized);
  const setClauses = keys.map((k) => `${k} = ?`).join(', ');

  try {
    await query(`UPDATE ${table} SET ${setClauses} WHERE id = ?`, [...values, id]);
    const updated = await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]);

    if (table === 'sos_requests') {
      broadcastTeamEvent('sos_updated', updated);
    }

    return res.json(formatRow(updated, table));
  } catch (err) {
    console.error(`Error updating ${table}/${id}:`, err);
    return res.status(500).json({ error: 'Update failed' });
  }
}

export default router;
